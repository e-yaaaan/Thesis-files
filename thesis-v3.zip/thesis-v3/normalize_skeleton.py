"""
Skeleton Normalization for HRNet Pose Estimation Output
----------------------------------------------------------
Takes a per-video JSON file (HRNet output, 17 COCO keypoints per frame)
and produces a hip-centered, torso-scaled skeleton array, ready for
ST-GCN / AGCN / CTR-GCN input.

Usage:
    python normalize_skeleton.py

Input:
    predictions/<video_name>.json

Output:
    normalized/<video_name>.npy   -- shape (T, 17, 3) -> [x, y, confidence]
"""

import os
import json
import numpy as np

# ── CONFIG ──────────────────────────────────────────────────────────────────
PRED_DIR   = 'predictions'
OUT_DIR    = 'normalized'
NUM_KPTS   = 17

# COCO keypoint indices
LEFT_SHOULDER, RIGHT_SHOULDER = 5, 6
LEFT_HIP,      RIGHT_HIP      = 11, 12
# ─────────────────────────────────────────────────────────────────────────────


def load_video_json(json_path: str):
    """
    Load HRNet JSON output for one video.
    Returns:
        keypoints : (T, 17, 2) float32
        scores    : (T, 17)    float32
    """
    with open(json_path, 'r') as f:
        frames = json.load(f)

    keypoints_seq, scores_seq = [], []
    for frame in frames:
        kpts = frame.get('keypoints', [])
        scs  = frame.get('keypoint_scores', [])

        if len(kpts) == 0:
            # No person detected in this frame — fill with zeros
            kpts_arr = np.zeros((NUM_KPTS, 2), dtype=np.float32)
            scs_arr  = np.zeros(NUM_KPTS, dtype=np.float32)
        else:
            kpts_arr = np.array(kpts[0], dtype=np.float32)   # first detected person
            scs_arr  = np.array(scs[0],  dtype=np.float32)

        keypoints_seq.append(kpts_arr)
        scores_seq.append(scs_arr)

    keypoints = np.stack(keypoints_seq)   # (T, 17, 2)
    scores    = np.stack(scores_seq)      # (T, 17)
    return keypoints, scores


def normalize_skeleton(keypoints: np.ndarray, scores: np.ndarray) -> np.ndarray:
    """
    Hip-center each frame's skeleton, then scale by torso length
    (distance from shoulder-center to hip-center) to remove the
    effect of camera distance / runner height / video resolution.

    Returns:
        skeleton : (T, 17, 3) float32 -> [x_norm, y_norm, confidence]
    """
    T = keypoints.shape[0]
    normalized = np.zeros_like(keypoints)

    for t in range(T):
        kp = keypoints[t]

        hip_center      = (kp[LEFT_HIP]      + kp[RIGHT_HIP])      / 2.0
        shoulder_center = (kp[LEFT_SHOULDER] + kp[RIGHT_SHOULDER]) / 2.0

        torso_length = np.linalg.norm(shoulder_center - hip_center)
        if torso_length < 1e-6:
            # Degenerate frame (missing/duplicate keypoints) — avoid divide-by-zero
            torso_length = 1.0

        # Translate so hip-center is the origin, then scale by torso length
        normalized[t] = (kp - hip_center) / torso_length

    # Re-attach confidence scores as a third channel: (T, 17, 2) -> (T, 17, 3)
    skeleton = np.concatenate([normalized, scores[..., np.newaxis]], axis=-1)
    return skeleton.astype(np.float32)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    json_files = sorted(f for f in os.listdir(PRED_DIR) if f.endswith('.json'))
    print(f'Found {len(json_files)} JSON file(s) in "{PRED_DIR}/"\n')

    for fname in json_files:
        base_name = os.path.splitext(fname)[0]
        json_path = os.path.join(PRED_DIR, fname)

        keypoints, scores = load_video_json(json_path)
        skeleton = normalize_skeleton(keypoints, scores)

        out_path = os.path.join(OUT_DIR, base_name + '.npy')
        np.save(out_path, skeleton)

        print(f'{fname:30s} -> {skeleton.shape}  saved to {out_path}')

    print('\nDone!')


if __name__ == '__main__':
    main()