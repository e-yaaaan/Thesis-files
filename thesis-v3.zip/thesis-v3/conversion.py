import os
import csv

LABEL_DIR  = "labels"
OUTPUT_CSV = "labels.csv"

# The 3 active labels, in the order they appear line-by-line in each .txt file.
# Line 1 → heelstrike
# Line 2 → armswing
# Line 3 → backkick
COLUMNS = ["heelstrike", "armswing", "backkick"]

rows    = []
skipped = []

for fname in sorted(os.listdir(LABEL_DIR)):
    if not fname.endswith(".txt"):
        continue

    txt_path = os.path.join(LABEL_DIR, fname)

    with open(txt_path, "r") as f:
        values = [line.strip() for line in f if line.strip()]

    if len(values) != len(COLUMNS):
        print(f"[SKIP] {fname}: expected {len(COLUMNS)} labels "
              f"({', '.join(COLUMNS)}), got {len(values)}")
        skipped.append(fname)
        continue

    npy_name = os.path.splitext(fname)[0] + ".npy"
    rows.append([npy_name] + values)

with open(OUTPUT_CSV, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["filename"] + COLUMNS)
    writer.writerows(rows)

print(f"Created {OUTPUT_CSV} with {len(rows)} entries")

if skipped:
    print(f"Skipped {len(skipped)} files: {skipped}")

# Label summary
if rows:
    print("\nLabel counts (positives / total):")
    for i, col in enumerate(COLUMNS):
        count = sum(1 for r in rows if r[i + 1] == "1")
        print(f"  {col:15s}: {count:3d} / {len(rows)}")
