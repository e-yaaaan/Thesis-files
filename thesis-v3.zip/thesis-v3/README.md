# Running Posture Analysis — Thesis Project

GCN-based pipeline for detecting running posture deviations (Heel Strike, Poor Arm Swing, Excessive Back Kick) from treadmill video.

---

## Link to Dataset Normalized
Tabumpama, Ian Chester (2026), “Running Posture Analysis Dataset”, Mendeley Data, V1, doi: 10.17632/9cr3fjhrzy.1

## Setup

Restore the conda environment:

```bash
conda env create -f environment.yml
conda activate pose_env
```

Also install Gradio if it's not already there:

```bash
pip install gradio
```

---

## Running the Prototype (Main App)

This is the Gradio web UI. Upload a video and it runs the full pipeline — pose extraction → normalization → GCN inference → results.

```bash
python prototype.py
```

Open the local URL shown in the terminal. The default model is CTR-GCN (augmented).

---

## Training the Models

Runs 5-fold stratified cross-validation for a given architecture:

```bash
cd "GCN Pipeline"
python cross_validate.py --model stgcn
python cross_validate.py --model agcn
python cross_validate.py --model ctrgcn
```

To train a single fold instead:

```bash
python train.py --model ctrgcn --fold 0
```

---

## Evaluation and Analysis

After training, run these from inside `GCN Pipeline/`:

```bash
# Evaluate a trained model
python evaluate.py --model ctrgcn

# McNemar's test and pairwise comparison
python compare.py

# Gradient saliency maps
python saliency.py --model ctrgcn
```

---

## Data Pipeline (if starting from raw video)

1. **Extract pose keypoints** from videos using HRNet:
   ```bash
   python video_demo.py
   ```

2. **Normalize skeletons** (hip-center + torso scale):
   ```bash
   python normalize_skeleton.py
   ```

3. **Label videos** using the annotation tool:
   ```bash
   python labeler.py
   ```

Raw videos are in `videos/`. Normalized outputs go to `videos_norm/`.

---

## Key Files

| File | What it does |
|------|-------------|
| `prototype.py` | Gradio demo app |
| `GCN Pipeline/cross_validate.py` | 5-fold CV training |
| `GCN Pipeline/train.py` | Single-model training |
| `GCN Pipeline/evaluate.py` | Metrics + evaluation |
| `GCN Pipeline/compare.py` | McNemar's test |
| `GCN Pipeline/saliency.py` | Gradient saliency |
| `normalize_skeleton.py` | Skeleton normalization |
| `labeler.py` | Video annotation tool |
| `environment.yml` | Conda environment |
| `td-hm_hrnet-w48_*.pth` | HRNet pretrained weights |

---

## Requirements

- Python 3.8
- PyTorch 2.1 + CUDA 12.1
- mmpose 1.3.2, mmcv 2.1.0
- See `environment.yml` for the full list
