# Copyright (c) OpenMMLab. All rights reserved.
import os
import json
import cv2
import mmcv
from mmpose.apis import inference_topdown, init_model
from mmpose.registry import VISUALIZERS
from mmpose.structures import merge_data_samples

# ── CONFIG ──────────────────────────────────────────────────────────────────
CONFIG     = 'td-hm_hrnet-w48_8xb32-210e_coco-256x192.py'
CHECKPOINT = 'td-hm_hrnet-w48_8xb32-210e_coco-256x192-0e67c616_20220913.pth'
DEVICE     = 'cuda:0'
VIDEO_DIR  = 'videos_norm/'
PRED_DIR   = 'predictions/'
VIS_DIR    = 'visualizations/'
KPT_THR    = 0.3
RADIUS     = 3
THICKNESS  = 1
ALPHA      = 0.8
# ────────────────────────────────────────────────────────────────────────────

os.makedirs(PRED_DIR, exist_ok=True)
os.makedirs(VIS_DIR,  exist_ok=True)

# Build model
model = init_model(CONFIG, CHECKPOINT, device=DEVICE)

# Build visualizer
model.cfg.visualizer.radius     = RADIUS
model.cfg.visualizer.alpha      = ALPHA
model.cfg.visualizer.line_width = THICKNESS
visualizer = VISUALIZERS.build(model.cfg.visualizer)
visualizer.set_dataset_meta(model.dataset_meta, skeleton_style='mmpose')

#Get all .MOV files
video_files = [f for f in os.listdir(VIDEO_DIR)
               if f.lower().endswith('.mov')]

print(f'Found {len(video_files)} videos to process')

for video_name in video_files:
    video_path = os.path.join(VIDEO_DIR, video_name)
    base_name  = os.path.splitext(video_name)[0]
    out_video  = os.path.join(VIS_DIR,  base_name + '.mp4')
    out_json   = os.path.join(PRED_DIR, base_name + '.json')

    # Skip if visualization already exists
    if os.path.exists(out_video):
        print(f'Skipping: {video_name} (Video already processed)')
        continue

    print(f'\nProcessing: {video_name}')

    # Use cv2 directly to read video
    cap          = cv2.VideoCapture(video_path)
    fps          = cap.get(cv2.CAP_PROP_FPS)
    width        = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height       = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    print(f'  FPS: {fps} | Resolution: {width}x{height} | Frames: {total_frames}')

    # Use cv2.VideoWriter with mp4v codec
    fourcc       = cv2.VideoWriter_fourcc(*'mp4v')
    video_writer = cv2.VideoWriter(out_video, fourcc, fps, (width, height))

    all_predictions = []

    frame_idx = 0
    while cap.isOpened():
        ret, frame_bgr = cap.read()
        if not ret:
            break

        # Convert BGR to RGB for MMPose
        frame_rgb = mmcv.bgr2rgb(frame_bgr)

        # Run HRNet inference
        batch_results = inference_topdown(model, frame_rgb)
        results       = merge_data_samples(batch_results)

        # Save predictions
        if results.pred_instances is not None:
            keypoints = results.pred_instances.keypoints
            scores    = results.pred_instances.keypoint_scores
            frame_pred = {
                'frame_id': frame_idx,
                'keypoints': keypoints.tolist(),
                'keypoint_scores': scores.tolist()
            }
        else:
            frame_pred = {
                'frame_id': frame_idx,
                'keypoints': [],
                'keypoint_scores': []
            }
        all_predictions.append(frame_pred)

        # Draw skeleton overlay
        visualizer.add_datasample(
            'frame',
            frame_rgb,
            data_sample=results,
            draw_gt=False,
            draw_bbox=False,
            kpt_thr=KPT_THR,
            draw_heatmap=False,
            show=False,
            out_file=None
        )

        # Get visualized frame and write to video
        vis_frame_rgb = visualizer.get_image()
        vis_frame_bgr = mmcv.rgb2bgr(vis_frame_rgb)
        video_writer.write(vis_frame_bgr)

        frame_idx += 1
        if frame_idx % 30 == 0:
            print(f'  Processed {frame_idx}/{total_frames} frames')

    cap.release()
    video_writer.release()

    # Save JSON predictions
    with open(out_json, 'w') as f:
        json.dump(all_predictions, f, indent=2)

    print(f'  Saved video → {out_video}')
    print(f'  Saved JSON  → {out_json}')

print('\nAll videos processed!')