"""
Running Posture Video Labeler
-------------------------------
Folder structure expected:
    videos_norm/   <- normalized .MOV / .mp4 videos
    labels/        <- created automatically, stores .txt labels + state.json
"""

import tkinter as tk
from tkinter import ttk
import cv2
from PIL import Image, ImageTk
import os
import json
import time

# ── CONFIG ────────────────────────────────────────────────────────────────────
VIDEO_DIR  = 'videos_norm'
LABELS_DIR = 'labels'
STATE_FILE = os.path.join(LABELS_DIR, 'state.json')

LABEL_NAMES = [
    'Poor Arm Swing',
    'Excessive Back Kick',
    'Heel Strike',
]

BG_DARK    = '#141414'
BG_PLAYER  = '#0a0a0a'
BG_PANEL   = '#1e1e1e'
BG_CARD    = '#2a2a2a'
ACCENT     = '#3b82f6'
YES_COLOR  = '#22c55e'
NO_COLOR   = '#ef4444'
WARN_COLOR = '#f59e0b'
TEXT_PRI   = '#f1f5f9'
TEXT_SEC   = '#94a3b8'
TEXT_DIM   = '#475569'
BORDER     = '#2d2d2d'

SPEEDS = [0.25, 0.5, 0.75, 1.0]
# ─────────────────────────────────────────────────────────────────────────────


class VideoLabeler:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title('Running Posture Labeler')
        self.root.configure(bg=BG_DARK)
        self.root.state('zoomed')
        self.root.minsize(1024, 600)

        os.makedirs(LABELS_DIR, exist_ok=True)

        exts = ('.mov', '.mp4', '.avi', '.m4v', '.mkv')
        self.videos = sorted(
            f for f in os.listdir(VIDEO_DIR)
            if f.lower().endswith(exts)
        )
        self.total = len(self.videos)
        if self.total == 0:
            raise FileNotFoundError(f'No videos found in "{VIDEO_DIR}"')

        self.state       = self._load_state()
        self.current_idx = max(0, min(self.state.get('current_idx', 0), self.total - 1))

        # Playback state
        self.cap           = None
        self.photo         = None
        self.after_id      = None
        self.fps           = 30.0
        self.total_frames  = 0
        self.current_frame = 0
        self.playing       = True
        self.loop          = True
        self.speed         = 1.0
        self.is_scrubbing  = False
        self.was_playing   = False

        self._build_ui()
        self._load_video(self.current_idx)

    # ── STATE ─────────────────────────────────────────────────────────────────

    def _load_state(self) -> dict:
        if os.path.exists(STATE_FILE):
            try:
                with open(STATE_FILE, 'r') as f:
                    return json.load(f)
            except Exception:
                pass
        return {'current_idx': 0, 'labels': {}}

    def _save_state(self):
        self.state['current_idx'] = self.current_idx
        try:
            with open(STATE_FILE, 'w') as f:
                json.dump(self.state, f, indent=2)
        except Exception as e:
            print(f'Warning: could not save state — {e}')

    # ── UI BUILD ──────────────────────────────────────────────────────────────

    def _build_ui(self):
        self.root.columnconfigure(0, weight=1)
        self.root.columnconfigure(1, weight=0)
        self.root.rowconfigure(0, weight=1)

        # ── Left: video player ──────────────────────────────────────────────
        left_frame = tk.Frame(self.root, bg=BG_PLAYER)
        left_frame.grid(row=0, column=0, sticky='nsew')
        left_frame.rowconfigure(0, weight=1)
        left_frame.rowconfigure(1, weight=0)
        left_frame.columnconfigure(0, weight=1)

        self.canvas = tk.Canvas(left_frame, bg='#000000', highlightthickness=0)
        self.canvas.grid(row=0, column=0, sticky='nsew')

        self._build_player_controls(left_frame)

        # ── Right: label panel ──────────────────────────────────────────────
        panel_outer = tk.Frame(self.root, bg=BG_PANEL, width=340)
        panel_outer.grid(row=0, column=1, sticky='ns')
        panel_outer.grid_propagate(False)
        panel_outer.columnconfigure(0, weight=1)
        panel_outer.rowconfigure(0, weight=1)

        self.panel_canvas = tk.Canvas(panel_outer, bg=BG_PANEL,
                                      highlightthickness=0, width=320)
        scrollbar = ttk.Scrollbar(panel_outer, orient='vertical',
                                  command=self.panel_canvas.yview)
        self.inner = tk.Frame(self.panel_canvas, bg=BG_PANEL)

        self.inner.bind('<Configure>', lambda e: self.panel_canvas.configure(
            scrollregion=self.panel_canvas.bbox('all')))

        self.panel_canvas.create_window((0, 0), window=self.inner,
                                        anchor='nw', width=320)
        self.panel_canvas.configure(yscrollcommand=scrollbar.set)
        self.panel_canvas.grid(row=0, column=0, sticky='nsew')
        scrollbar.grid(row=0, column=1, sticky='ns')
        panel_outer.columnconfigure(0, weight=1)

        self.panel_canvas.bind('<Enter>',
            lambda e: self.panel_canvas.bind_all('<MouseWheel>', self._on_scroll))
        self.panel_canvas.bind('<Leave>',
            lambda e: self.panel_canvas.unbind_all('<MouseWheel>'))

        self._build_panel_contents()

        # Keyboard shortcuts
        self.root.bind('<space>',  lambda e: self._toggle_play()
                       if self.root.focus_get() is not self.counter_entry else None)
        self.root.bind('<Left>',   lambda e: self._prev_video()
                       if self.root.focus_get() is not self.counter_entry else None)
        self.root.bind('<Right>',  lambda e: self._next_video()
                       if self.root.focus_get() is not self.counter_entry else None)
        self.root.bind('<Escape>', lambda e: self._on_close())

    # ── PLAYER CONTROLS ───────────────────────────────────────────────────────

    def _build_player_controls(self, parent):
        ctrl_outer = tk.Frame(parent, bg=BG_PLAYER)
        ctrl_outer.grid(row=1, column=0, sticky='ew')

        # Scrubber bar
        self.scrub = tk.Canvas(ctrl_outer, bg=BG_PLAYER,
                               height=30, highlightthickness=0, cursor='hand2')
        self.scrub.pack(fill='x', padx=14, pady=(10, 2))
        self.scrub.bind('<Button-1>',        self._scrub_click)
        self.scrub.bind('<B1-Motion>',       self._scrub_drag)
        self.scrub.bind('<ButtonRelease-1>', self._scrub_release)
        self.scrub.bind('<Configure>',       lambda e: self._draw_scrub())

        # Controls row
        ctrl_row = tk.Frame(ctrl_outer, bg=BG_PLAYER, pady=8)
        ctrl_row.pack(fill='x', padx=14)

        # Play / Pause
        self.play_btn = tk.Button(
            ctrl_row, text='⏸', command=self._toggle_play,
            bg=BG_PLAYER, fg=TEXT_PRI, font=('Helvetica', 20),
            relief='flat', bd=0, cursor='hand2', padx=2, pady=0,
            activebackground=BG_PLAYER, activeforeground=ACCENT
        )
        self.play_btn.pack(side='left')

        # Time display
        self.time_label = tk.Label(
            ctrl_row, text='0:00 / 0:00',
            bg=BG_PLAYER, fg=TEXT_SEC, font=('Helvetica', 10)
        )
        self.time_label.pack(side='left', padx=(10, 0))

        # Right-side controls
        right = tk.Frame(ctrl_row, bg=BG_PLAYER)
        right.pack(side='right')

        # Loop toggle
        self.loop_btn = tk.Button(
            right, text='🔁 Loop', command=self._toggle_loop,
            bg=ACCENT, fg='white', font=('Helvetica', 9, 'bold'),
            relief='flat', bd=0, cursor='hand2', padx=8, pady=4,
            activebackground=ACCENT, activeforeground='white'
        )
        self.loop_btn.pack(side='right', padx=(8, 0))

        # Speed label
        tk.Label(right, text='SPEED', bg=BG_PLAYER, fg=TEXT_DIM,
                 font=('Helvetica', 8, 'bold')).pack(side='left', padx=(0, 6))

        # Speed buttons
        self.speed_btns = {}
        for spd in SPEEDS:
            lbl = f'{int(spd)}x' if spd == 1.0 else f'{spd}x'
            btn = tk.Button(
                right, text=lbl,
                command=lambda s=spd: self._set_speed(s),
                bg=ACCENT if spd == 1.0 else BG_CARD,
                fg='white', font=('Helvetica', 9, 'bold'),
                relief='flat', bd=0, cursor='hand2',
                padx=7, pady=4,
                activebackground=ACCENT, activeforeground='white'
            )
            btn.pack(side='left', padx=2)
            self.speed_btns[spd] = btn

    # ── PANEL CONTENTS ────────────────────────────────────────────────────────

    def _build_panel_contents(self):
        p = self.inner

        # Header
        header = tk.Frame(p, bg=BG_PANEL)
        header.pack(fill='x', padx=20, pady=(22, 4))
        tk.Label(header, text='RUNNING POSTURE', bg=BG_PANEL, fg=ACCENT,
                 font=('Helvetica', 9, 'bold')).pack(anchor='w')
        tk.Label(header, text='Label Tool', bg=BG_PANEL, fg=TEXT_PRI,
                 font=('Helvetica', 18, 'bold')).pack(anchor='w')

        self._divider(p)

        # Video counter card
        counter_card = tk.Frame(p, bg=BG_CARD, pady=14)
        counter_card.pack(fill='x', padx=20, pady=(10, 4))
        tk.Label(counter_card, text='VIDEO', bg=BG_CARD, fg=TEXT_DIM,
                 font=('Helvetica', 8, 'bold')).pack(anchor='center')

        counter_row = tk.Frame(counter_card, bg=BG_CARD)
        counter_row.pack()

        self.counter_var   = tk.StringVar()
        self.counter_entry = tk.Entry(
            counter_row, textvariable=self.counter_var,
            width=4, font=('Helvetica', 22, 'bold'),
            justify='center', bg=BG_CARD, fg=TEXT_PRI,
            insertbackground=ACCENT, relief='flat',
            highlightthickness=1, highlightcolor=ACCENT,
            highlightbackground=BG_CARD
        )
        self.counter_entry.pack(side='left')
        self.counter_entry.bind('<Return>', self._on_counter_enter)
        self.counter_entry.bind('<FocusIn>',
            lambda e: self.counter_entry.select_range(0, 'end'))

        tk.Label(counter_row, text=f'/ {self.total}', bg=BG_CARD, fg=TEXT_SEC,
                 font=('Helvetica', 22)).pack(side='left')

        self.name_label = tk.Label(
            p, text='', bg=BG_PANEL, fg=TEXT_DIM,
            font=('Helvetica', 9), wraplength=290, justify='center'
        )
        self.name_label.pack(pady=(0, 8))

        # Overall labeling progress bar
        prog_frame = tk.Frame(p, bg=BG_PANEL)
        prog_frame.pack(fill='x', padx=20, pady=(0, 4))
        self.progress_bar_bg = tk.Frame(prog_frame, bg=BORDER, height=4)
        self.progress_bar_bg.pack(fill='x')
        self.progress_bar_fg = tk.Frame(self.progress_bar_bg, bg=ACCENT, height=4)
        self.progress_bar_fg.place(x=0, y=0, relheight=1, relwidth=0)

        self.status_label = tk.Label(p, text='', bg=BG_PANEL, font=('Helvetica', 10))
        self.status_label.pack(pady=(4, 0))

        self._divider(p)

        # Labels section
        tk.Label(p, text='POSTURE LABELS', bg=BG_PANEL, fg=TEXT_DIM,
                 font=('Helvetica', 8, 'bold')).pack(anchor='w', padx=20, pady=(6, 6))

        self.label_vars = []
        for name in LABEL_NAMES:
            self._build_label_card(p, name)

        self._divider(p)

        # Find unlabeled
        self._btn(p, '→  Go to Nearest Unlabeled', self._go_to_incomplete,
                  bg=WARN_COLOR, fg='#000000').pack(fill='x', padx=20, pady=(12, 4))

        # Prev / Next navigation
        nav = tk.Frame(p, bg=BG_PANEL)
        nav.pack(fill='x', padx=20, pady=(6, 24))
        nav.columnconfigure(0, weight=1)
        nav.columnconfigure(1, weight=1)

        self.prev_btn = self._btn(nav, '◀  Previous', self._prev_video,
                                  bg=BG_CARD, fg=TEXT_PRI)
        self.prev_btn.grid(row=0, column=0, sticky='ew', padx=(0, 4))

        self.next_btn = self._btn(nav, 'Next  ▶', self._next_video,
                                  bg=ACCENT, fg='white')
        self.next_btn.grid(row=0, column=1, sticky='ew', padx=(4, 0))

    def _build_label_card(self, parent, name: str):
        card = tk.Frame(parent, bg=BG_CARD, padx=14, pady=10)
        card.pack(fill='x', padx=20, pady=3)
        tk.Label(card, text=name, bg=BG_CARD, fg=TEXT_PRI,
                 font=('Helvetica', 11), anchor='w').pack(fill='x')
        radio_row = tk.Frame(card, bg=BG_CARD)
        radio_row.pack(anchor='w', pady=(6, 0))
        var = tk.IntVar(value=-1)
        self.label_vars.append(var)
        for text, val, color in [('Yes', 1, YES_COLOR), ('No', 0, NO_COLOR)]:
            tk.Radiobutton(
                radio_row, text=text, variable=var, value=val,
                bg=BG_CARD, fg=color, selectcolor=BG_CARD,
                activebackground=BG_CARD, activeforeground=color,
                font=('Helvetica', 11, 'bold'),
                command=self._on_label_change,
                relief='flat', bd=0, cursor='hand2'
            ).pack(side='left', padx=(0, 24))

    def _divider(self, parent):
        tk.Frame(parent, bg=BORDER, height=1).pack(fill='x', padx=20, pady=10)

    def _btn(self, parent, text, command, bg=BG_CARD, fg=TEXT_PRI):
        b = tk.Button(
            parent, text=text, command=command,
            bg=bg, fg=fg, activebackground=bg, activeforeground=fg,
            font=('Helvetica', 11), relief='flat', bd=0,
            padx=12, pady=10, cursor='hand2'
        )
        b.bind('<Enter>', lambda e: b.configure(bg=self._lighten(bg)))
        b.bind('<Leave>', lambda e: b.configure(bg=bg))
        return b

    @staticmethod
    def _lighten(hex_color: str) -> str:
        try:
            r = min(255, int(hex_color[1:3], 16) + 20)
            g = min(255, int(hex_color[3:5], 16) + 20)
            b = min(255, int(hex_color[5:7], 16) + 20)
            return f'#{r:02x}{g:02x}{b:02x}'
        except Exception:
            return hex_color

    # ── VIDEO PLAYBACK ────────────────────────────────────────────────────────

    def _load_video(self, idx: int):
        if self.after_id:
            self.root.after_cancel(self.after_id)
            self.after_id = None
        if self.cap:
            self.cap.release()

        self.current_idx   = idx
        self.playing       = True
        self.current_frame = 0

        name     = self.videos[idx]
        self.cap = cv2.VideoCapture(os.path.join(VIDEO_DIR, name))
        self.fps          = self.cap.get(cv2.CAP_PROP_FPS) or 30.0
        self.total_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT))

        self.play_btn.config(text='⏸')
        self.counter_var.set(str(idx + 1))
        self.name_label.config(text=name)
        self.prev_btn.config(state='normal' if idx > 0             else 'disabled')
        self.next_btn.config(state='normal' if idx < self.total - 1 else 'disabled')

        self._load_labels(name)
        self._update_status()
        self._update_panel_progress()
        self._save_state()
        self._tick()

    def _tick(self):
        if not self.cap or self.is_scrubbing or not self.playing:
            return

        t_start = time.perf_counter()          # start timer

        ret, frame = self.cap.read()
        if not ret:
            if self.loop:
                self.cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                self.current_frame = 0
                ret, frame = self.cap.read()
                if not ret:
                    return
            else:
                self.playing = False
                self.play_btn.config(text='▶')
                return

        self.current_frame = int(self.cap.get(cv2.CAP_PROP_POS_FRAMES))
        self._display_frame(frame)
        self._draw_scrub()
        self._update_time_label()

        # Subtract processing time from the target delay
        target_ms   = 1000 / (self.fps * self.speed)
        elapsed_ms  = (time.perf_counter() - t_start) * 1000
        actual_delay = max(1, int(target_ms - elapsed_ms))  # never go below 1ms

        self.after_id = self.root.after(actual_delay, self._tick)

    def _display_frame(self, frame):
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw < 2 or ch < 2:
            return
        fh, fw = frame.shape[:2]
        scale  = min(cw / fw, ch / fh)
        nw, nh = int(fw * scale), int(fh * scale)
        frame      = cv2.resize(frame, (nw, nh), interpolation=cv2.INTER_LINEAR)
        frame      = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img        = Image.fromarray(frame)
        self.photo = ImageTk.PhotoImage(img)
        self.canvas.delete('all')
        self.canvas.create_image(cw // 2, ch // 2, anchor='center', image=self.photo)

    # ── SCRUBBER ──────────────────────────────────────────────────────────────

    def _draw_scrub(self):
        self.scrub.delete('all')
        w   = self.scrub.winfo_width()
        h   = self.scrub.winfo_height()
        if w < 2:
            return
        pad = 10
        cy  = h // 2
        tw  = w - 2 * pad
        pct = (self.current_frame / self.total_frames) if self.total_frames > 0 else 0
        fx  = pad + pct * tw

        # Track background
        self.scrub.create_line(pad, cy, w - pad, cy,
                               fill='#333333', width=4, capstyle='round')
        # Filled portion
        if pct > 0:
            self.scrub.create_line(pad, cy, fx, cy,
                                   fill=ACCENT, width=4, capstyle='round')
        # Thumb circle
        r = 7
        self.scrub.create_oval(fx - r, cy - r, fx + r, cy + r,
                               fill=ACCENT, outline='#ffffff', width=1.5)

    def _seek_to_x(self, x: int):
        """Seek video to the frame at canvas x-coordinate."""
        w   = self.scrub.winfo_width()
        pad = 10
        pct = max(0.0, min(1.0, (x - pad) / (w - 2 * pad)))
        target = int(pct * self.total_frames)
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, target)
        self.current_frame = target
        ret, frame = self.cap.read()
        if ret:
            self._display_frame(frame)
        self._draw_scrub()
        self._update_time_label()

    def _scrub_click(self, event):
        self.was_playing = self.playing
        self.playing     = False
        if self.after_id:
            self.root.after_cancel(self.after_id)
            self.after_id = None
        self.is_scrubbing = True
        self._seek_to_x(event.x)

    def _scrub_drag(self, event):
        self._seek_to_x(event.x)

    def _scrub_release(self, event):
        self._seek_to_x(event.x)
        self.is_scrubbing = False
        if self.was_playing:
            self.playing = True
            self.play_btn.config(text='⏸')
            self._tick()

    def _update_time_label(self):
        def fmt(secs: float) -> str:
            s = int(secs)
            return f'{s // 60}:{s % 60:02d}'
        cur = self.current_frame / self.fps if self.fps else 0
        tot = self.total_frames  / self.fps if self.fps else 0
        self.time_label.config(text=f'{fmt(cur)} / {fmt(tot)}')

    # ── PLAYER CONTROLS ───────────────────────────────────────────────────────

    def _toggle_play(self):
        self.playing = not self.playing
        self.play_btn.config(text='⏸' if self.playing else '▶')
        if self.playing:
            self._tick()

    def _toggle_loop(self):
        self.loop = not self.loop
        self.loop_btn.config(bg=ACCENT if self.loop else BG_CARD)

    def _set_speed(self, speed: float):
        self.speed = speed
        for spd, btn in self.speed_btns.items():
            btn.config(bg=ACCENT if spd == speed else BG_CARD)

    # ── LABELS ────────────────────────────────────────────────────────────────

    def _load_labels(self, video_name: str):
        saved = self.state.get('labels', {}).get(video_name)
        for i, var in enumerate(self.label_vars):
            var.set(saved[i] if (saved and i < len(saved)) else -1)

    def _persist_labels(self, video_name: str):
        values = [v.get() for v in self.label_vars]
        self.state.setdefault('labels', {})[video_name] = values
        self._save_state()
        if all(v != -1 for v in values):
            base = os.path.splitext(video_name)[0]
            with open(os.path.join(LABELS_DIR, base + '.txt'), 'w') as f:
                for v in values:
                    f.write(f'{v}\n')

    def _on_label_change(self):
        self._persist_labels(self.videos[self.current_idx])
        self._update_status()

    def _update_status(self):
        values = [v.get() for v in self.label_vars]
        filled = sum(1 for v in values if v != -1)
        total  = len(LABEL_NAMES)
        if filled == total:
            self.status_label.config(text=f'✓  Complete ({total}/{total})',
                                     fg=YES_COLOR, bg=BG_PANEL)
        elif filled == 0:
            self.status_label.config(text=f'○  Not started (0/{total})',
                                     fg=TEXT_DIM, bg=BG_PANEL)
        else:
            self.status_label.config(text=f'◐  In progress ({filled}/{total})',
                                     fg=WARN_COLOR, bg=BG_PANEL)

    def _update_panel_progress(self):
        labeled = sum(1 for name in self.videos if self._is_complete(name))
        pct     = labeled / self.total if self.total else 0
        self.progress_bar_bg.update_idletasks()
        self.progress_bar_fg.place(
            x=0, y=0, relheight=1,
            width=int(self.progress_bar_bg.winfo_width() * pct)
        )

    def _is_complete(self, video_name: str) -> bool:
        saved = self.state.get('labels', {}).get(video_name)
        return bool(saved and all(v != -1 for v in saved))

    # ── NAVIGATION ───────────────────────────────────────────────────────────

    def _prev_video(self):
        if self.current_idx > 0:
            self._persist_labels(self.videos[self.current_idx])
            self._load_video(self.current_idx - 1)

    def _next_video(self):
        if self.current_idx < self.total - 1:
            self._persist_labels(self.videos[self.current_idx])
            self._load_video(self.current_idx + 1)

    def _on_counter_enter(self, _event=None):
        try:
            new_idx = int(self.counter_var.get()) - 1
            if 0 <= new_idx < self.total and new_idx != self.current_idx:
                self._persist_labels(self.videos[self.current_idx])
                self._load_video(new_idx)
            else:
                self.counter_var.set(str(self.current_idx + 1))
        except ValueError:
            self.counter_var.set(str(self.current_idx + 1))

    def _go_to_incomplete(self):
        for offset in range(1, self.total + 1):
            idx  = (self.current_idx + offset) % self.total
            name = self.videos[idx]
            if not self._is_complete(name):
                self._persist_labels(self.videos[self.current_idx])
                self._load_video(idx)
                return
        self.status_label.config(text='✓  All videos labeled!',
                                 fg=YES_COLOR, bg=BG_PANEL)

    def _on_scroll(self, event):
        self.panel_canvas.yview_scroll(int(-1 * (event.delta / 120)), 'units')

    # ── CLEANUP ───────────────────────────────────────────────────────────────

    def _on_close(self):
        self._persist_labels(self.videos[self.current_idx])
        if self.after_id:
            self.root.after_cancel(self.after_id)
        if self.cap:
            self.cap.release()
        self.root.destroy()


# ── ENTRY POINT ───────────────────────────────────────────────────────────────

if __name__ == '__main__':
    root = tk.Tk()
    app  = VideoLabeler(root)
    root.protocol('WM_DELETE_WINDOW', app._on_close)
    root.mainloop()