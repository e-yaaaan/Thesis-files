"""
compare.py — Compare all three GCN models and generate final reports.

Two modes:

  Single-run mode (default):
    Loads trained checkpoints, evaluates on the held-out test set, prints a
    comparison table, and generates a bar chart.  Requires each model to have
    been trained with train.py first.

    python compare.py --data_dir data/normalized --csv data/labels.csv

  Cross-validation mode (--cv):
    Loads the cv_results.json files saved by cross_validate.py, displays the
    mean ± std comparison table, and re-runs McNemar's test.

    python compare.py --cv --out_dir results
"""

import os
import time
import json
import argparse
import numpy as np
import pandas as pd
import torch

from data.dataset    import (get_dataloaders, ACTIVE_LABEL_NAMES,
                             BINARY_LABEL_NAMES, BINARY_CSV_COLUMNS)
from models          import MODEL_REGISTRY
from utils.metrics   import (
    compute_metrics, logits_to_pred,
    aggregate_fold_metrics, print_cv_metrics,
    run_mcnemar_tests, print_mcnemar_results,
    get_confusion_matrices,
)
from utils.visualize import (
    build_comparison_table, save_comparison_table,
    plot_model_comparison,
    save_cv_summary, plot_cv_summary,
    save_mcnemar_table,
    plot_roc_curves, plot_pr_curves,
    plot_label_metric_heatmap, plot_radar_chart,
    plot_cm_summary, plot_mcnemar_table,
)


# ─── Argument parser ──────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="Compare GCN models")

    # Mode
    p.add_argument("--cv", action="store_true",
                   help="Cross-validation mode: load cv_results.json files "
                        "instead of evaluating checkpoints on a test set")

    # Single-run mode args
    p.add_argument("--data_dir",   type=str, default=None,
                   help="Path to normalized/ folder (single-run mode)")
    p.add_argument("--csv",        type=str, default=None,
                   help="Path to labels CSV (single-run mode)")
    p.add_argument("--max_frames", type=int, default=300)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--seed",       type=int, default=42)

    # Common
    p.add_argument("--models",  nargs="+",
                   choices=["stgcn", "agcn", "ctrgcn"],
                   default=["stgcn", "agcn", "ctrgcn"])
    p.add_argument("--out_dir", type=str, default="results")

    # Binary classification mode
    p.add_argument("--binary", action="store_true",
                   help="Binary mode: good posture vs bad posture")

    return p.parse_args()


# ─── Single-run evaluation ────────────────────────────────────────────────────

@torch.no_grad()
def _evaluate_model(model, loader, device, label_names=None):
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES
    model.eval()
    all_logits, all_labels = [], []
    _t0 = time.perf_counter()
    for bx, by, _ in loader:
        bx = bx.to(device)
        all_logits.append(model(bx).cpu().numpy())
        all_labels.append(by.numpy())
    _t1 = time.perf_counter()
    logits = np.concatenate(all_logits, 0)
    labels = np.concatenate(all_labels, 0)
    y_pred, y_prob = logits_to_pred(logits)
    metrics = compute_metrics(labels, y_pred, y_prob, label_names)
    metrics["inference_time_ms"] = (_t1 - _t0) / max(len(labels), 1) * 1000
    return metrics, y_pred, y_prob, labels


def run_single_mode(args):
    """Load checkpoints, evaluate on shared test set, produce comparison."""
    if not args.data_dir or not args.csv:
        raise ValueError(
            "Single-run mode requires --data_dir and --csv. "
            "Use --cv for cross-validation mode."
        )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[Device] {device}")

    if args.binary:
        label_names = BINARY_LABEL_NAMES
        label_cols  = BINARY_CSV_COLUMNS
        strat_col   = "bad_posture"
        print("[Mode] Binary classification: Good Posture vs Bad Posture")
    else:
        label_names = ACTIVE_LABEL_NAMES
        label_cols  = None
        strat_col   = "heelstrike"

    _, _, test_loader, _ = get_dataloaders(
        data_dir      = args.data_dir,
        csv_path      = args.csv,
        max_frames    = args.max_frames,
        batch_size    = args.batch_size,
        seed          = args.seed,
        label_columns = label_cols,
        strat_column  = strat_col,
    )

    MODEL_DISPLAY = {"stgcn": "ST-GCN", "agcn": "AGCN", "ctrgcn": "CTR-GCN"}
    all_results  = {}
    preds_dict   = {}
    probs_dict   = {}
    cms_dict     = {}
    y_true_ref   = None

    for model_key in args.models:
        ckpt_path = os.path.join(
            args.out_dir, "checkpoints", model_key, "best_model.pt"
        )
        if not os.path.isfile(ckpt_path):
            print(f"[SKIP] No checkpoint: {ckpt_path}")
            continue

        print(f"\n[Evaluating] {model_key.upper()} ...")
        ModelClass = MODEL_REGISTRY[model_key]
        model      = ModelClass(num_classes=len(label_names),
                                dropout=0.0).to(device)
        ckpt       = torch.load(ckpt_path, map_location=device)
        model.load_state_dict(ckpt["model_state_dict"])

        metrics, y_pred, y_prob, y_true = _evaluate_model(
            model, test_loader, device, label_names=label_names
        )
        display = MODEL_DISPLAY[model_key]
        all_results[display] = metrics
        preds_dict[display]  = y_pred
        probs_dict[display]  = y_prob
        cms_dict[display]    = get_confusion_matrices(y_true, y_pred, label_names)
        if y_true_ref is None:
            y_true_ref = y_true

        print(f"  Macro F1    : {metrics['macro']['f1']:.4f}")
        print(f"  Hamming Acc : {metrics['hamming_acc']:.4f}")
        mcc = metrics.get("macro", {}).get("mcc", float("nan"))
        if not np.isnan(mcc):
            print(f"  MCC (macro) : {mcc:.4f}")
        print(f"  Infer time  : {metrics.get('inference_time_ms', float('nan')):.2f} ms/sample")

    if not all_results:
        print("\n[Error] No trained models found — run train.py for each model first.")
        return

    # ── Output dirs ───────────────────────────────────────────────────────────
    reports_dir = os.path.join(args.out_dir, "reports")
    plots_dir   = os.path.join(args.out_dir, "plots")
    stats_dir   = os.path.join(args.out_dir, "statistics")
    for d in [reports_dir, plots_dir, stats_dir]:
        os.makedirs(d, exist_ok=True)

    # ── Comparison table + bar chart ──────────────────────────────────────────
    df = build_comparison_table(all_results, label_names)
    save_comparison_table(df, save_dir=reports_dir)
    plot_model_comparison(df, save_dir=plots_dir)

    # ── McNemar's test ────────────────────────────────────────────────────────
    mcnemar_results = []
    if len(preds_dict) >= 2 and y_true_ref is not None:
        mcnemar_results = run_mcnemar_tests(preds_dict, y_true_ref, label_names)
        print_mcnemar_results(mcnemar_results)
        save_mcnemar_table(mcnemar_results, save_dir=stats_dir)

    # ── Advanced visualizations ───────────────────────────────────────────────
    print(f"\n[Plots] Generating advanced visualizations ...")
    if len(probs_dict) >= 1 and y_true_ref is not None:
        plot_roc_curves(probs_dict, y_true_ref, label_names, save_dir=plots_dir)
        plot_pr_curves(probs_dict, y_true_ref, label_names, save_dir=plots_dir)
    plot_label_metric_heatmap(all_results, label_names, save_dir=plots_dir)
    plot_radar_chart(all_results, save_dir=plots_dir)
    if cms_dict:
        plot_cm_summary(cms_dict, label_names, save_dir=plots_dir)
    if mcnemar_results:
        plot_mcnemar_table(mcnemar_results, save_dir=plots_dir)

    print(f"\n[Done] All results saved to {args.out_dir}/")


# ─── Cross-validation mode ────────────────────────────────────────────────────

def run_cv_mode(args):
    """Load cv_results.json files and regenerate reports + McNemar's."""
    folds_root = os.path.join(args.out_dir, "folds")

    if not os.path.isdir(folds_root):
        print(
            f"[Error] CV results not found at {folds_root}\n"
            "Run cross_validate.py first."
        )
        return

    if args.binary:
        label_names = BINARY_LABEL_NAMES
        print("[Mode] Binary classification: Good Posture vs Bad Posture")
    else:
        label_names = ACTIVE_LABEL_NAMES

    MODEL_DISPLAY = {"stgcn": "ST-GCN", "agcn": "AGCN", "ctrgcn": "CTR-GCN"}
    agg_results   = {}
    preds_dict    = {}
    y_true_ref    = None
    ref_fnames    = None

    for model_key in args.models:
        cv_json = os.path.join(folds_root, model_key, "cv_results.json")
        if not os.path.isfile(cv_json):
            print(f"[SKIP] No CV results for {model_key}: {cv_json}")
            continue

        with open(cv_json, "r", encoding="utf-8") as f:
            data = json.load(f)

        display_name = data.get("display_name", MODEL_DISPLAY.get(model_key, model_key))
        print(f"\n[Loaded] {display_name} — {data['n_folds']}-fold CV results")

        # Re-aggregate from stored fold metrics
        # The stored agg_metrics already has the computed aggregation
        agg = data["agg_metrics"]
        agg_results[display_name] = agg
        print_cv_metrics(agg, model_name=display_name, label_names=label_names)

        # Rebuild predictions from per-fold CSVs for McNemar's
        fnames_ordered = data.get("all_fnames", [])
        if fnames_ordered:
            # Collect predictions from fold CSVs
            fold_pred_parts = []
            fold_true_parts = []
            for fold_idx in range(data["n_folds"]):
                fold_dir  = os.path.join(folds_root, model_key, f"fold_{fold_idx}")
                pred_csv  = os.path.join(fold_dir, "predictions.csv")
                true_csv  = os.path.join(fold_dir, "ground_truth.csv")
                if os.path.isfile(pred_csv) and os.path.isfile(true_csv):
                    pred_df = pd.read_csv(pred_csv)
                    true_df = pd.read_csv(true_csv)
                    fold_pred_parts.append(
                        pred_df[label_names].values.astype(np.int32)
                    )
                    fold_true_parts.append(
                        true_df[label_names].values.astype(np.int32)
                    )

            if fold_pred_parts:
                y_pred_all = np.concatenate(fold_pred_parts, axis=0)
                y_true_all = np.concatenate(fold_true_parts, axis=0)
                preds_dict[display_name] = y_pred_all
                if y_true_ref is None:
                    y_true_ref    = y_true_all
                    ref_fnames    = fnames_ordered

    if not agg_results:
        print("\n[Error] No CV results found — run cross_validate.py first.")
        return

    # ── Regenerate reports ────────────────────────────────────────────────────
    reports_dir = os.path.join(args.out_dir, "reports")
    plots_dir   = os.path.join(args.out_dir, "plots")
    stats_dir   = os.path.join(args.out_dir, "statistics")
    for d in [reports_dir, plots_dir, stats_dir]:
        os.makedirs(d, exist_ok=True)

    save_cv_summary(agg_results, save_dir=reports_dir, label_names=label_names)
    plot_cv_summary(agg_results, save_dir=plots_dir)

    # ── McNemar's test ─────────────────────────────────────────────────────────
    mcnemar_results = []
    if len(preds_dict) >= 2 and y_true_ref is not None:
        mcnemar_results = run_mcnemar_tests(preds_dict, y_true_ref, label_names)
        print_mcnemar_results(mcnemar_results)
        save_mcnemar_table(mcnemar_results, save_dir=stats_dir)
    else:
        print("\n[McNemar] Skipped — need at least 2 models with predictions.")

    # ── Advanced visualizations (from aggregated metrics — no probs needed) ───
    print(f"\n[Plots] Generating advanced visualizations ...")
    plot_label_metric_heatmap(agg_results, label_names, save_dir=plots_dir)
    plot_radar_chart(agg_results, save_dir=plots_dir)
    if len(preds_dict) >= 2 and y_true_ref is not None:
        plot_mcnemar_table(mcnemar_results, save_dir=plots_dir)

    print(f"\n[Done] Reports saved to {args.out_dir}/")


# ─── Entry point ──────────────────────────────────────────────────────────────

def main():
    args = parse_args()
    if args.cv:
        run_cv_mode(args)
    else:
        run_single_mode(args)


if __name__ == "__main__":
    main()
