"""
make_plots.py — Regenerate all evaluation plots from existing CV results.
No retraining needed. Reads cv_results.json and history.json from disk.

Usage (run from inside GCN Pipeline/):
    python make_plots.py --out_dir results_binary_no_aug
    python make_plots.py --out_dir results_binary_aug
    python make_plots.py --out_dir results_no_aug
    python make_plots.py --out_dir results_aug
"""

import os
import sys
import json
import argparse
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

from utils.visualize import (
    plot_cv_summary, save_cv_summary,
    plot_cv_individual_metrics,
    plot_training_curves_individual, plot_training_curves_combined,
    plot_label_metric_heatmap, plot_radar_chart,
)

MODEL_KEYS    = ["stgcn", "agcn", "ctrgcn"]
MODEL_DISPLAY = {"stgcn": "ST-GCN", "agcn": "AGCN", "ctrgcn": "CTR-GCN"}
_MODEL_COLORS = ["#2196F3", "#4CAF50", "#FF9800"]


# ─── Loaders ──────────────────────────────────────────────────────────────────

def load_agg_metrics(out_dir):
    """Return {display_name: agg_metrics_dict} from existing cv_results.json."""
    agg = {}
    for key in MODEL_KEYS:
        path = os.path.join(out_dir, "folds", key, "cv_results.json")
        if not os.path.isfile(path):
            continue
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        agg[MODEL_DISPLAY[key]] = data["agg_metrics"]
    return agg


def load_fold_histories(out_dir, n_folds=5):
    """Return {display_name: [fold_history_dict, ...]} from history.json files."""
    all_hists = {}
    for key in MODEL_KEYS:
        hists = []
        for fi in range(n_folds):
            path = os.path.join(out_dir, "folds", key, f"fold_{fi}", "history.json")
            if os.path.isfile(path):
                with open(path, encoding="utf-8") as f:
                    hists.append(json.load(f))
        if hists:
            all_hists[MODEL_DISPLAY[key]] = hists
    return all_hists


# ─── Metric reliability plot (Recommendation #2) ─────────────────────────────

def plot_metric_reliability(agg_results_dict, save_dir):
    """
    Grouped bar chart: Accuracy vs MCC (rescaled) vs AUC per model.
    Shows when accuracy diverges from MCC/AUC — a sign of class-imbalance gaming.
    MCC is rescaled from [-1, 1] → [0, 1] so all three metrics share the same axis.
    """
    model_names = list(agg_results_dict.keys())

    def _mv(agg, *keys):
        """Navigate nested dict and return (mean, std)."""
        obj = agg
        for k in keys:
            obj = obj.get(k, {}) if isinstance(obj, dict) else {}
        if isinstance(obj, dict):
            return float(obj.get("mean", float("nan"))), float(obj.get("std", 0.0))
        return float(obj), 0.0

    panels = [
        ("Accuracy\n(Hamming)",    ("hamming_acc",),   False),
        ("MCC*\n(rescaled 0–1)",   ("macro", "mcc"),   True),
        ("ROC-AUC",                ("auc_macro",),      False),
    ]

    x     = np.arange(len(panels))
    width = 0.22
    fig, ax = plt.subplots(figsize=(10, 5))

    for i, (model, color) in enumerate(zip(model_names, _MODEL_COLORS)):
        agg = agg_results_dict[model]
        means, errs = [], []
        for _, keys, is_mcc in panels:
            m, s = _mv(agg, *keys)
            if is_mcc:
                m = (m + 1) / 2 if not np.isnan(m) else float("nan")
                s = s / 2
            means.append(m)
            errs.append(s)

        offset = (i - len(model_names) / 2 + 0.5) * width
        bars = ax.bar(x + offset, means, width, yerr=errs,
                      label=model, color=color, alpha=0.85,
                      edgecolor="white", capsize=4,
                      error_kw={"elinewidth": 1.5, "ecolor": "black"})
        for bar, m, s in zip(bars, means, errs):
            if not np.isnan(m):
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + s + 0.012,
                        f"{m:.2f}", ha="center", va="bottom", fontsize=8.5)

    ax.set_xticks(x)
    ax.set_xticklabels([lbl for lbl, _, _ in panels], fontsize=11)
    ax.set_ylim(0, 1.18)
    ax.set_ylabel("Score")
    ax.set_title(
        "Accuracy vs MCC vs AUC  —  Why Accuracy Alone Is Insufficient\n"
        "(*MCC rescaled to [0, 1]: adj = (MCC + 1) / 2  |  bars = mean ± std across folds)",
        fontsize=11,
    )
    ax.legend(loc="upper right", fontsize=10)
    ax.grid(axis="y", alpha=0.3)
    ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))

    fig.tight_layout()
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "metric_reliability.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved metric reliability → {fname}")


# ─── Condition-specific CV summary (key metrics only) ─────────────────────────

def plot_cv_summary_condition(agg_results_dict, condition_label, save_dir):
    """
    Focused bar chart for a single experimental condition.
    Shows Hamming Accuracy, Macro F1, Micro F1, MCC_adj, and AUC
    for all three models side by side. MCC_adj is rescaled to [0,1].
    Saves as cv_summary_<condition_slug>.png
    """
    METRICS = [
        ("hamming_acc", "Hamming\nAccuracy"),
        ("macro.f1",    "Macro F1"),
        ("micro.f1",    "Micro F1"),
        ("macro.mcc",   "MCC_adj"),
        ("auc_macro",   "AUC"),
    ]

    def _get(agg, key):
        parts = key.split(".")
        obj = agg
        for p in parts:
            obj = obj.get(p, {}) if isinstance(obj, dict) else {}
        return obj

    model_names = list(agg_results_dict.keys())
    x      = np.arange(len(METRICS))
    width  = 0.22
    colors = _MODEL_COLORS

    fig, ax = plt.subplots(figsize=(12, 6))

    for i, (model, color) in enumerate(zip(model_names, colors)):
        agg = agg_results_dict[model]
        means, stds = [], []
        for key, _ in METRICS:
            d = _get(agg, key)
            m = float(d.get("mean", float("nan"))) if isinstance(d, dict) else float("nan")
            s = float(d.get("std",  0.0))          if isinstance(d, dict) else 0.0
            if key == "macro.mcc" and not np.isnan(m):
                m = (m + 1) / 2
                s = s / 2
            means.append(m)
            stds.append(s)

        offset = (i - len(model_names) / 2 + 0.5) * width
        bars = ax.bar(x + offset, means, width, yerr=stds,
                      label=model, color=color, alpha=0.85,
                      edgecolor="white", capsize=4,
                      error_kw={"elinewidth": 1.5, "ecolor": "black"})
        for bar, m, s in zip(bars, means, stds):
            if not np.isnan(m):
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + s + 0.010,
                        f"{m:.3f}", ha="center", va="bottom", fontsize=9)

    ax.axhline(0.5, color="gray", linestyle=":", lw=1.2, alpha=0.55)
    ax.annotate("MCC_adj = 0.5  (random)", xy=(len(METRICS) - 0.5, 0.5),
                xytext=(0, 4), textcoords="offset points",
                fontsize=8, color="gray", ha="right")

    ax.set_xticks(x)
    ax.set_xticklabels([lbl for _, lbl in METRICS], fontsize=12)
    ax.set_ylim(0, 1.18)
    ax.set_ylabel("Score", fontsize=11)
    ax.set_title(
        f"5-Fold CV Summary — {condition_label}\n"
        f"(bars = mean ± std across folds  |  MCC_adj = (MCC + 1) / 2)",
        fontsize=12,
    )
    ax.legend(loc="upper right", fontsize=11)
    ax.grid(axis="y", alpha=0.3)
    ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))

    fig.tight_layout()
    os.makedirs(save_dir, exist_ok=True)
    slug  = condition_label.lower().replace(" ", "_").replace("-", "")
    fname = os.path.join(save_dir, f"cv_summary_{slug}.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved condition summary → {fname}")


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(
        description="Regenerate plots from existing CV results (no retraining)"
    )
    p.add_argument("--out_dir",  required=True,
                   help="Existing results folder, e.g. results_binary_no_aug")
    p.add_argument("--n_folds",  type=int, default=5)
    p.add_argument("--condition_label", default=None,
                   help="Label for this condition, e.g. 'Augmented' or 'No Augmentation'")
    args = p.parse_args()

    plots_dir   = os.path.join(args.out_dir, "plots")
    reports_dir = os.path.join(args.out_dir, "reports")
    os.makedirs(plots_dir,   exist_ok=True)
    os.makedirs(reports_dir, exist_ok=True)

    # ── Load ──────────────────────────────────────────────────────────────────
    agg_results   = load_agg_metrics(args.out_dir)
    fold_histories = load_fold_histories(args.out_dir, n_folds=args.n_folds)

    if not agg_results:
        print(f"[Error] No cv_results.json found under {args.out_dir}/folds/")
        print("        Make sure --out_dir points to a completed CV run.")
        return

    sample_agg  = next(iter(agg_results.values()))
    label_names = list(sample_agg["per_label"].keys())
    print(f"[Info] Models found  : {list(agg_results.keys())}")
    print(f"[Info] Labels        : {label_names}")
    print(f"[Info] Saving plots  → {plots_dir}/")
    print()

    # ── Summary plots ─────────────────────────────────────────────────────────
    plot_cv_summary(agg_results, save_dir=plots_dir)
    plot_cv_individual_metrics(agg_results, save_dir=plots_dir)
    save_cv_summary(agg_results, save_dir=reports_dir, label_names=label_names)
    plot_label_metric_heatmap(agg_results, label_names, save_dir=plots_dir)
    plot_radar_chart(agg_results, save_dir=plots_dir)

    # ── Metric reliability (Rec #2) ───────────────────────────────────────────
    plot_metric_reliability(agg_results, save_dir=plots_dir)

    # ── Condition-specific summary (key metrics, labeled by condition) ─────────
    cond_label = args.condition_label
    if not cond_label:
        od = args.out_dir.lower()
        if "no_aug" in od:
            cond_label = "No Augmentation"
        elif "aug" in od:
            cond_label = "Augmented"
        else:
            cond_label = os.path.basename(args.out_dir)
    plot_cv_summary_condition(agg_results, cond_label, save_dir=plots_dir)

    # ── Training curves (from history.json) ───────────────────────────────────
    if fold_histories:
        for display_name, hists in fold_histories.items():
            plot_training_curves_individual(hists, display_name, save_dir=plots_dir)
        plot_training_curves_combined(fold_histories, save_dir=plots_dir)
    else:
        print("[Warning] No history.json files found — training curve plots skipped.")

    print(f"\n[Done] All plots saved to → {plots_dir}/")


if __name__ == "__main__":
    main()
