"""Dataset loader for skeleton-based running posture deviation detection."""

import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split, StratifiedKFold


ACTIVE_LABEL_NAMES = ["Heel Strike", "Poor Arm Swing", "Excessive Back Kick"]

CSV_COLUMNS = ["heelstrike", "armswing", "backkick"]

# Binary classification mode (good posture = 0, bad posture = 1)
BINARY_LABEL_NAMES = ["Bad Posture"]
BINARY_CSV_COLUMNS = ["bad_posture"]

NUM_JOINTS   = 17   # COCO keypoint count
NUM_CHANNELS = 3    # x, y, confidence
NUM_PERSONS  = 1    # single athlete per video


class GaitDataset(Dataset):
    """Loads skeleton .npy files and binary label vectors for CV training."""

    def __init__(self, file_list, labels_df, data_dir,
                 max_frames=300, active_only=True,
                 augment=False, aug_config=None, label_columns=None):
        self.file_list    = file_list
        self.labels_df    = labels_df
        self.data_dir     = data_dir
        self.max_frames   = max_frames
        self.active_only  = active_only
        self.augment      = augment
        self.aug_config   = aug_config or {}
        self.label_columns = label_columns if label_columns is not None else CSV_COLUMNS

    def __len__(self):
        return len(self.file_list)

    def __getitem__(self, idx):
        fname = self.file_list[idx]

        # ── Load skeleton ────────────────────────────────────────────────────
        path = os.path.join(self.data_dir, fname)
        skeleton = np.load(path).astype(np.float32)  # (T, 17, 3)

        # Validate shape
        if skeleton.ndim != 3 or skeleton.shape[1] != NUM_JOINTS or skeleton.shape[2] != NUM_CHANNELS:
            raise ValueError(
                f"{fname}: expected shape (T, {NUM_JOINTS}, {NUM_CHANNELS}), "
                f"got {skeleton.shape}"
            )

        T = skeleton.shape[0]

        if T >= self.max_frames:
            skeleton = skeleton[: self.max_frames]
        else:
            pad = np.zeros((self.max_frames - T, NUM_JOINTS, NUM_CHANNELS),
                           dtype=np.float32)
            skeleton = np.concatenate([skeleton, pad], axis=0)

        if self.augment:
            from utils.augmentations import apply_augmentations
            skeleton = apply_augmentations(
                skeleton,
                max_frames=self.max_frames,
                **self.aug_config,
            )

        skeleton = skeleton.transpose(2, 0, 1)
        skeleton = skeleton[:, :, :, np.newaxis]
        tensor   = torch.from_numpy(skeleton)

        row   = self.labels_df.loc[fname, self.label_columns].values.astype(np.float32)
        label = torch.from_numpy(row)

        return tensor, label, fname


def compute_pos_weights(labels_df, active_only=True,
                        label_columns=None, display_names=None):
    """
    Computes pos_weight for each label to handle class imbalance.
    pos_weight[i] = (number of negatives) / (number of positives)
    """
    cols  = label_columns   if label_columns  is not None else CSV_COLUMNS
    names = display_names   if display_names  is not None else ACTIVE_LABEL_NAMES
    values = labels_df[cols].values.astype(np.float32)

    n_samples  = values.shape[0]
    pos_counts = values.sum(axis=0)
    neg_counts = n_samples - pos_counts

    pos_counts_safe = np.where(pos_counts == 0, 1, pos_counts)
    weights = neg_counts / pos_counts_safe

    print("\n[Class Weights]")
    for name, w, p in zip(names, weights, pos_counts):
        print(f"  {name:30s}  positives={int(p):3d}  pos_weight={w:.2f}")

    return torch.tensor(weights, dtype=torch.float32)


# ─── Original single-split DataLoader factory (backward compatible) ──────────

def get_dataloaders(data_dir, csv_path, max_frames=300, batch_size=8,
                    val_size=0.15, test_size=0.15, seed=42,
                    active_only=True, num_workers=0,
                    augment=False, aug_config=None,
                    label_columns=None, strat_column="heelstrike"):
    """Load CSV, split filenames into train/val/test, return DataLoaders."""
    df = pd.read_csv(csv_path)
    df["filename"] = df["filename"].str.strip()
    df = df.set_index("filename")

    all_files = [f for f in df.index if os.path.isfile(os.path.join(data_dir, f))]
    missing   = set(df.index) - set(all_files)
    if missing:
        print(f"[WARNING] {len(missing)} CSV entries have no matching .npy file: {missing}")

    strat_vals = df.loc[all_files, strat_column].values

    train_files, temp_files, _, temp_strat = train_test_split(
        all_files, strat_vals,
        test_size=(val_size + test_size),
        random_state=seed,
        stratify=strat_vals,
    )

    val_files, test_files = train_test_split(
        temp_files,
        test_size=0.5,
        random_state=seed,
        stratify=temp_strat,
    )

    print(f"\n[Data Split]  seed={seed}")
    print(f"  Train : {len(train_files)} samples")
    print(f"  Val   : {len(val_files)} samples")
    print(f"  Test  : {len(test_files)} samples")
    print(f"  Total : {len(all_files)} samples")

    assert not set(train_files) & set(val_files),  "Leakage: train ∩ val"
    assert not set(train_files) & set(test_files), "Leakage: train ∩ test"
    assert not set(val_files)   & set(test_files), "Leakage: val ∩ test"

    pos_weights = compute_pos_weights(
        df.loc[train_files], active_only=active_only,
        label_columns=label_columns,
    )

    train_ds = GaitDataset(train_files, df, data_dir, max_frames, active_only,
                           augment=augment, aug_config=aug_config,
                           label_columns=label_columns)
    val_ds   = GaitDataset(val_files,   df, data_dir, max_frames, active_only,
                           augment=False, label_columns=label_columns)
    test_ds  = GaitDataset(test_files,  df, data_dir, max_frames, active_only,
                           augment=False, label_columns=label_columns)

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True,
                              num_workers=num_workers, pin_memory=True)
    val_loader   = DataLoader(val_ds,   batch_size=batch_size, shuffle=False,
                              num_workers=num_workers, pin_memory=True)
    test_loader  = DataLoader(test_ds,  batch_size=batch_size, shuffle=False,
                              num_workers=num_workers, pin_memory=True)

    return train_loader, val_loader, test_loader, pos_weights


def get_cv_fold_files(data_dir, csv_path, n_splits=5, seed=42, val_size=0.15,
                      label_columns=None, strat_column="heelstrike"):
    """Load dataset and return n_splits-fold cross-validation splits."""
    df = pd.read_csv(csv_path)
    df["filename"] = df["filename"].str.strip()
    df = df.set_index("filename")

    all_files = [f for f in df.index
                 if os.path.isfile(os.path.join(data_dir, f))]
    missing = set(df.index) - set(all_files)
    if missing:
        print(f"[WARNING] {len(missing)} CSV entries missing .npy files: {missing}")

    print(f"\n[CV Setup]  n_splits={n_splits}  seed={seed}")
    print(f"  Total valid files : {len(all_files)}")

    strat_vals = df.loc[all_files, strat_column].values
    kf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)

    folds = []
    for fold_idx, (tv_idx, test_idx) in enumerate(kf.split(all_files, strat_vals)):
        train_val_files = [all_files[i] for i in tv_idx]
        test_files      = [all_files[i] for i in test_idx]

        tv_strat = df.loc[train_val_files, strat_column].values
        try:
            train_files, val_files = train_test_split(
                train_val_files,
                test_size=val_size,
                random_state=seed,
                stratify=tv_strat,
            )
        except ValueError:
            print(f"  [Fold {fold_idx}] Stratified inner split failed — "
                  "using random split for val.")
            train_files, val_files = train_test_split(
                train_val_files,
                test_size=val_size,
                random_state=seed,
            )

        folds.append((train_files, val_files, test_files))

        strat_pos_test = df.loc[test_files, strat_column].sum()
        print(f"  Fold {fold_idx}: train={len(train_files)}  "
              f"val={len(val_files)}  test={len(test_files)}  "
              f"(strat_pos_in_test={int(strat_pos_test)})")

    return df, all_files, folds


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 3:
        print("Usage: python dataset.py <data_dir> <csv_path>")
        sys.exit(1)

    data_dir, csv_path = sys.argv[1], sys.argv[2]

    train_loader, val_loader, test_loader, pw = get_dataloaders(
        data_dir, csv_path, max_frames=300, batch_size=4
    )
    batch, labels, fnames = next(iter(train_loader))
    print(f"\nBatch tensor shape : {batch.shape}")   # (N, 3, 300, 17, 1)
    print(f"Label tensor shape : {labels.shape}")    # (N, 3)
    print(f"pos_weights        : {pw}")

    # Test CV fold files
    df, all_files, folds = get_cv_fold_files(data_dir, csv_path, n_splits=5)
    print(f"\n5-fold CV created: {len(folds)} folds over {len(all_files)} files")
