"""
cross_validate.py — 5-Fold Cross-Validation for ST-GCN, AGCN, and CTR-GCN.

Usage:
    python cross_validate.py \\
        --data_dir data/normalized \\
        --csv      data/labels.csv

    # With augmentations:
    python cross_validate.py \\
        --data_dir data/normalized \\
        --csv      data/labels.csv \\
        --aug_noise --aug_crop

    # Run only specific models:
    python cross_validate.py \\
        --data_dir data/normalized \\
        --csv      data/labels.csv \\
        --models stgcn ctrgcn
"""

import os
import sys
import json
import time
import argparse
import random
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data import DataLoader

from data.dataset import (
    GaitDataset, compute_pos_weights,
    get_cv_fold_files, ACTIVE_LABEL_NAMES,
    BINARY_LABEL_NAMES, BINARY_CSV_COLUMNS,
)
from models import MODEL_REGISTRY
from utils.metrics import (
    compute_metrics, print_metrics, logits_to_pred,
    aggregate_fold_metrics, print_cv_metrics,
    get_confusion_matrices, get_classification_report,
    run_mcnemar_tests, print_mcnemar_results,
)
from utils.visualize import (
    plot_loss_curves,
    plot_training_curves_individual, plot_training_curves_combined,
    plot_roc_per_model,
    plot_confusion_matrices, plot_cv_summary,
    save_cv_summary, save_mcnemar_table,
    plot_roc_curves, plot_pr_curves,
    plot_label_metric_heatmap, plot_radar_chart,
    plot_cm_summary, plot_mcnemar_table,
)


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark     = False


def parse_args():
    p = argparse.ArgumentParser(
        description="5-Fold Cross-Validation for GCN models"
    )

    p.add_argument("--data_dir", type=str, required=True,
                   help="Path to normalized/ folder containing .npy files")
    p.add_argument("--csv",      type=str, required=True,
                   help="Path to labels CSV file")
    p.add_argument("--models", nargs="+",
                   choices=["stgcn", "agcn", "ctrgcn"],
                   default=["stgcn", "agcn", "ctrgcn"],
                   help="Which models to train (default: all three)")
    p.add_argument("--n_folds",   type=int, default=5)
    p.add_argument("--val_size",  type=float, default=0.15,
                   help="Fraction of train_val used for inner validation")
    p.add_argument("--seed",      type=int, default=42)
    p.add_argument("--max_frames", type=int, default=300)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--num_workers",type=int, default=0,
                   help="DataLoader workers (use 0 on Windows)")
    p.add_argument("--epochs",      type=int,   default=100)
    p.add_argument("--lr",          type=float, default=1e-3)
    p.add_argument("--weight_decay",type=float, default=1e-4)
    p.add_argument("--dropout",     type=float, default=0.5)
    p.add_argument("--patience",    type=int,   default=20)
    p.add_argument("--aug_noise",    action="store_true",
                   help="Enable Gaussian noise on x,y (training only)")
    p.add_argument("--aug_crop",     action="store_true",
                   help="Enable random temporal crop (training only)")
    p.add_argument("--aug_mirror",   action="store_true",
                   help="Enable left-right skeleton mirror (training only)")
    p.add_argument("--aug_sigma",    type=float, default=0.01)
    p.add_argument("--aug_crop_pct", type=float, default=0.10)
    p.add_argument("--binary", action="store_true",
                   help="Binary mode: good posture vs bad posture (uses binary_labels.csv)")
    p.add_argument("--out_dir", type=str, default="results",
                   help="Root output directory")

    return p.parse_args()


def _train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    total_loss = 0.0
    all_preds, all_labels = [], []
    for bx, by, _ in loader:
        bx = bx.to(device, non_blocking=True)
        by = by.to(device, non_blocking=True)
        optimizer.zero_grad()
        logits = model(bx)
        loss   = criterion(logits, by)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()
        total_loss += loss.item() * bx.size(0)
        preds = (torch.sigmoid(logits) > 0.5).float()
        all_preds.append(preds.detach().cpu().numpy())
        all_labels.append(by.detach().cpu().numpy())
    all_preds  = np.concatenate(all_preds,  axis=0)
    all_labels = np.concatenate(all_labels, axis=0)
    train_acc  = float((all_preds == all_labels).mean())
    return total_loss / len(loader.dataset), train_acc


@torch.no_grad()
def _eval_loader(model, loader, criterion, device):
    """Return (avg_loss, all_logits, all_labels)."""
    model.eval()
    total_loss = 0.0
    logits_list, labels_list = [], []
    for bx, by, _ in loader:
        bx     = bx.to(device, non_blocking=True)
        by     = by.to(device, non_blocking=True)
        logits = model(bx)
        total_loss += criterion(logits, by).item() * bx.size(0)
        logits_list.append(logits.cpu().numpy())
        labels_list.append(by.cpu().numpy())
    avg_loss   = total_loss / len(loader.dataset)
    all_logits = np.concatenate(logits_list, axis=0)
    all_labels = np.concatenate(labels_list, axis=0)
    return avg_loss, all_logits, all_labels


@torch.no_grad()
def _run_inference(model, loader, device):
    """Collect logits, labels and filenames from a loader."""
    model.eval()
    logits_list, labels_list, fnames_all = [], [], []
    for bx, by, fnames in loader:
        bx = bx.to(device, non_blocking=True)
        logits_list.append(model(bx).cpu().numpy())
        labels_list.append(by.numpy())
        fnames_all.extend(fnames)
    return (
        np.concatenate(logits_list, axis=0),
        np.concatenate(labels_list, axis=0),
        fnames_all,
    )


def train_one_fold(model_key, train_ds, val_ds, pos_weights,
                   args, device, ckpt_path, fold_idx,
                   num_classes=None, label_names=None):
    """
    Train one model on one fold.  Returns (model, history_dict).
    """
    if num_classes is None:
        num_classes = len(ACTIVE_LABEL_NAMES)
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES
    ModelClass  = MODEL_REGISTRY[model_key]
    model       = ModelClass(num_classes=num_classes,
                             dropout=args.dropout).to(device)

    criterion = nn.BCEWithLogitsLoss(
        pos_weight=pos_weights.to(device)
    )
    optimizer = Adam(model.parameters(),
                     lr=args.lr, weight_decay=args.weight_decay)
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)

    train_loader = DataLoader(train_ds, batch_size=args.batch_size,
                              shuffle=True,  num_workers=args.num_workers,
                              pin_memory=True)
    val_loader   = DataLoader(val_ds,   batch_size=args.batch_size,
                              shuffle=False, num_workers=args.num_workers,
                              pin_memory=True)

    train_losses, val_losses = [], []
    train_accs, val_accs, val_f1s, lrs = [], [], [], []
    best_val_loss  = float("inf")
    best_val_f1    = 0.0
    best_epoch     = 1
    patience_count = 0

    print(f"\n  [Fold {fold_idx}] {model_key.upper()} — "
          f"{sum(p.numel() for p in model.parameters() if p.requires_grad):,} params")
    print(f"  {'Ep':>4}  {'Train':>9}  {'Val':>9}  {'MacroF1':>8}  {'LR':>8}")
    print(f"  {'-'*48}")

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()

        train_loss, train_acc = _train_one_epoch(
            model, train_loader, criterion, optimizer, device
        )
        val_loss, val_logits, val_labels = _eval_loader(
            model, val_loader, criterion, device
        )
        scheduler.step()

        val_pred, val_prob = logits_to_pred(val_logits)
        val_metrics = compute_metrics(val_labels, val_pred, val_prob, label_names)
        val_f1  = val_metrics["macro"]["f1"]
        val_acc = float((val_pred == val_labels).mean())
        cur_lr  = optimizer.param_groups[0]["lr"]

        train_losses.append(train_loss)
        val_losses.append(val_loss)
        train_accs.append(train_acc)
        val_accs.append(val_acc)
        val_f1s.append(float(val_f1))
        lrs.append(cur_lr)

        elapsed = time.time() - t0
        print(f"  {epoch:>4}  {train_loss:>9.5f}  {val_loss:>9.5f}  "
              f"{val_f1:>8.4f}  {cur_lr:>8.2e}  ({elapsed:.1f}s)")

        if val_loss < best_val_loss:
            best_val_loss  = val_loss
            best_val_f1    = val_f1
            best_epoch     = epoch
            patience_count = 0
            torch.save({
                "epoch":                epoch,
                "model_state_dict":     model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "val_loss":             val_loss,
                "val_f1":               val_f1,
                "fold":                 fold_idx,
                "model_key":            model_key,
            }, ckpt_path)
        else:
            patience_count += 1

        if patience_count >= args.patience:
            print(f"\n  [EarlyStopping] epoch={epoch}  "
                  f"best_val_loss={best_val_loss:.5f}")
            break

    history = {
        "train_loss": train_losses,
        "val_loss":   val_losses,
        "train_acc":  train_accs,
        "val_acc":    val_accs,
        "val_f1":     val_f1s,
        "lrs":        lrs,
        "best_epoch": best_epoch,
    }
    print(f"\n  Fold {fold_idx} done — "
          f"best val_loss={best_val_loss:.5f}  best_f1={best_val_f1:.4f}")
    return model, history


def main():
    args   = parse_args()
    set_seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\n[Device] {device}")

    any_aug    = args.aug_noise or args.aug_crop or args.aug_mirror
    aug_config = {
        "use_noise":  args.aug_noise,
        "use_crop":   args.aug_crop,
        "use_mirror": args.aug_mirror,
    } if any_aug else {}

    if any_aug:
        import utils.augmentations as _aug
        _aug.GAUSSIAN_SIGMA    = args.aug_sigma
        _aug.TEMPORAL_CROP_PCT = args.aug_crop_pct
        print(f"[Augmentation] noise={args.aug_noise}  "
              f"crop={args.aug_crop}  mirror={args.aug_mirror}  "
              f"(training only)")
    else:
        print("[Augmentation] All disabled")

    if args.binary:
        label_names = BINARY_LABEL_NAMES
        label_cols  = BINARY_CSV_COLUMNS
        strat_col   = "bad_posture"
        print("[Mode] Binary classification: Good Posture vs Bad Posture")
    else:
        label_names = ACTIVE_LABEL_NAMES
        label_cols  = None
        strat_col   = "heelstrike"
    num_classes = len(label_names)

    df, all_files, folds = get_cv_fold_files(
        data_dir      = args.data_dir,
        csv_path      = args.csv,
        n_splits      = args.n_folds,
        seed          = args.seed,
        val_size      = args.val_size,
        label_columns = label_cols,
        strat_column  = strat_col,
    )

    folds_root = os.path.join(args.out_dir, "folds")
    plots_dir  = os.path.join(args.out_dir, "plots")
    reports_dir= os.path.join(args.out_dir, "reports")
    stats_dir  = os.path.join(args.out_dir, "statistics")
    for d in [folds_root, plots_dir, reports_dir, stats_dir]:
        os.makedirs(d, exist_ok=True)

    MODEL_DISPLAY = {"stgcn": "ST-GCN", "agcn": "AGCN", "ctrgcn": "CTR-GCN"}

    all_model_data     = {}
    all_fold_histories = {}   # {display_name: [fold_history_dict, ...]}

    for model_key in args.models:
        display_name = MODEL_DISPLAY[model_key]
        print(f"\n{'═'*65}")
        print(f"  MODEL: {display_name}  ({args.n_folds}-fold CV)")
        print(f"{'═'*65}")

        model_fold_dir = os.path.join(folds_root, model_key)
        os.makedirs(model_fold_dir, exist_ok=True)

        fold_metrics    = []   # list of compute_metrics() dicts
        fold_preds      = []   # list of {filenames, y_true, y_pred, y_prob}
        fold_histories  = []   # list of {train_loss, val_loss}

        for fold_idx, (train_files, val_files, test_files) in enumerate(folds):
            fold_dir = os.path.join(model_fold_dir, f"fold_{fold_idx}")
            os.makedirs(fold_dir, exist_ok=True)
            ckpt_path = os.path.join(fold_dir, "best_model.pt")

            print(f"\n{'─'*55}")
            print(f"  Fold {fold_idx}/{args.n_folds - 1}  |  "
                  f"train={len(train_files)}  val={len(val_files)}  "
                  f"test={len(test_files)}")
            print(f"{'─'*55}")

            pos_weights = compute_pos_weights(
                df.loc[train_files], active_only=True,
                label_columns=label_cols,
                display_names=label_names,
            )

            train_ds = GaitDataset(
                train_files, df, args.data_dir, args.max_frames,
                active_only=True,
                augment=any_aug,
                aug_config=aug_config,
                label_columns=label_cols,
            )
            val_ds = GaitDataset(
                val_files, df, args.data_dir, args.max_frames,
                active_only=True, augment=False,
                label_columns=label_cols,
            )
            test_ds = GaitDataset(
                test_files, df, args.data_dir, args.max_frames,
                active_only=True, augment=False,
                label_columns=label_cols,
            )

            model, history = train_one_fold(
                model_key, train_ds, val_ds, pos_weights,
                args, device, ckpt_path, fold_idx,
                num_classes=num_classes, label_names=label_names,
            )

            hist_path = os.path.join(fold_dir, "history.json")
            with open(hist_path, "w") as f:
                json.dump(history, f, indent=2)
            fold_histories.append(history)

            ckpt = torch.load(ckpt_path, map_location=device)
            model.load_state_dict(ckpt["model_state_dict"])

            test_loader = DataLoader(
                test_ds, batch_size=args.batch_size, shuffle=False,
                num_workers=args.num_workers, pin_memory=True,
            )
            _t0 = time.perf_counter()
            test_logits, test_labels, test_fnames = _run_inference(
                model, test_loader, device
            )
            _t1 = time.perf_counter()
            test_pred, test_prob = logits_to_pred(test_logits)
            infer_ms = (_t1 - _t0) / max(len(test_fnames), 1) * 1000

            # ── Fold metrics ──────────────────────────────────────────────
            metrics = compute_metrics(
                test_labels, test_pred, test_prob, label_names
            )
            metrics["inference_time_ms"] = infer_ms
            fold_metrics.append(metrics)
            fold_preds.append({
                "filenames": test_fnames,
                "y_true":    test_labels,
                "y_pred":    test_pred,
                "y_prob":    test_prob,
            })

            print(f"\n  [Fold {fold_idx} Test]  "
                  f"Macro-F1={metrics['macro']['f1']:.4f}  "
                  f"Hamming={metrics['hamming_acc']:.4f}  "
                  f"AUC={metrics.get('auc_macro', float('nan')):.4f}  "
                  f"MCC={metrics['macro'].get('mcc', float('nan')):.4f}  "
                  f"Infer={infer_ms:.1f}ms/samp")

            # ── Per-fold confusion matrices ───────────────────────────────
            cms = get_confusion_matrices(test_labels, test_pred, label_names)
            plot_confusion_matrices(
                cms,
                f"{display_name} Fold {fold_idx}",
                save_dir=os.path.join(fold_dir),
            )

            # ── Per-fold predictions CSV ──────────────────────────────────
            pred_df = pd.DataFrame(test_pred, columns=label_names)
            pred_df.insert(0, "filename", test_fnames)
            gt_df   = pd.DataFrame(test_labels.astype(int), columns=label_names)
            gt_df.insert(0, "filename", test_fnames)
            pred_df.to_csv(os.path.join(fold_dir, "predictions.csv"), index=False)
            gt_df.to_csv(os.path.join(fold_dir, "ground_truth.csv"),  index=False)

            # ── Per-fold classification report ────────────────────────────
            reports = get_classification_report(test_labels, test_pred, label_names)
            rpt_path = os.path.join(fold_dir, "classification_report.txt")
            with open(rpt_path, "w", encoding="utf-8") as f:
                f.write(f"Model: {display_name}  |  Fold: {fold_idx}\n\n")
                for label, rpt in reports.items():
                    f.write(f"{'─'*40}\n{label}\n{'─'*40}\n{rpt}\n\n")

        # ── Per-fold training curves ──────────────────────────────────────
        plot_training_curves_individual(fold_histories, display_name,
                                        save_dir=plots_dir)
        all_fold_histories[display_name] = fold_histories

        # ── Aggregate metrics ─────────────────────────────────────────────
        agg = aggregate_fold_metrics(fold_metrics, label_names)
        print_cv_metrics(agg, model_name=display_name, label_names=label_names)

        # ── Save aggregated results JSON ──────────────────────────────────
        # Build serializable fold metrics list (convert numpy types → Python)
        def _sanitize(obj):
            """Recursively convert numpy types and NaN/Inf for JSON output."""
            if isinstance(obj, dict):
                return {k: _sanitize(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [_sanitize(v) for v in obj]
            if isinstance(obj, (np.ndarray,)):
                return _sanitize(obj.tolist())
            if isinstance(obj, (np.floating, np.float32, np.float64)):
                v = float(obj)
                return None if (np.isnan(v) or np.isinf(v)) else v
            if isinstance(obj, (np.integer, np.int32, np.int64)):
                return int(obj)
            if isinstance(obj, float) and (np.isnan(obj) or np.isinf(obj)):
                return None
            return obj

        serializable_fold_metrics = [_sanitize(fm) for fm in fold_metrics]

        # Collect full test predictions aligned by filename
        all_fnames_ordered = []
        all_y_true_parts   = []
        all_y_pred_parts   = []
        all_y_prob_parts   = []
        for fp in fold_preds:
            all_fnames_ordered.extend(fp["filenames"])
            all_y_true_parts.append(fp["y_true"])
            all_y_pred_parts.append(fp["y_pred"])
            all_y_prob_parts.append(fp["y_prob"])

        cv_results = {
            "model_key":     model_key,
            "display_name":  display_name,
            "n_folds":       args.n_folds,
            "seed":          args.seed,
            "fold_metrics":  serializable_fold_metrics,
            "agg_metrics":   _sanitize(agg),
            "all_fnames":    all_fnames_ordered,
        }
        cv_json_path = os.path.join(model_fold_dir, "cv_results.json")
        with open(cv_json_path, "w", encoding="utf-8") as f:
            json.dump(cv_results, f, indent=2)
        print(f"\n[CV Results] Saved → {cv_json_path}")

        # Store for McNemar's and final comparison
        all_model_data[model_key] = {
            "display_name":  display_name,
            "agg":           agg,
            "fold_preds":    fold_preds,
            "all_fnames":    all_fnames_ordered,
            "y_true_concat": np.concatenate(all_y_true_parts, axis=0),
            "y_pred_concat": np.concatenate(all_y_pred_parts, axis=0),
            "y_prob_concat": np.concatenate(all_y_prob_parts, axis=0),
        }

    # ══════════════════════════════════════════════════════════════════════════
    # PHASE 2: Final comparison + McNemar's test
    # ══════════════════════════════════════════════════════════════════════════

    print(f"\n\n{'═'*65}")
    print("  FINAL CROSS-VALIDATION SUMMARY")
    print(f"{'═'*65}")

    # ── Aggregated metrics comparison ──────────────────────────────────────────
    agg_results_display = {
        data["display_name"]: data["agg"]
        for data in all_model_data.values()
    }
    save_cv_summary(agg_results_display, save_dir=reports_dir,
                    label_names=label_names)
    plot_cv_summary(agg_results_display, save_dir=plots_dir)

    # ── McNemar's test ────────────────────────────────────────────────────────
    if len(all_model_data) >= 2:
        print(f"\n{'─'*55}")
        print("  McNemar's Test (pairwise statistical significance)")
        print(f"{'─'*55}")

        # Align predictions: all models must share the same filename order.
        # Since all folds are identical across models, we use the first model's
        # filename order as the reference and sort all others to match.
        ref_key = list(all_model_data.keys())[0]
        ref_fnames = all_model_data[ref_key]["all_fnames"]
        ref_index  = {fn: i for i, fn in enumerate(ref_fnames)}

        preds_for_mcnemar = {}
        y_true_ref        = None

        for model_key, data in all_model_data.items():
            fnames  = data["all_fnames"]
            y_pred  = data["y_pred_concat"]
            y_true  = data["y_true_concat"]

            # Re-order to match reference order
            order = [ref_index[fn] for fn in fnames]
            sort_idx = np.argsort(order)   # sort by position in ref order
            # Actually re-order so positions match ref
            # Build a mapping: ref_fname -> prediction
            fname_to_pred = {fn: y_pred[i] for i, fn in enumerate(fnames)}
            fname_to_true = {fn: y_true[i] for i, fn in enumerate(fnames)}

            aligned_pred = np.array([fname_to_pred[fn] for fn in ref_fnames])
            aligned_true = np.array([fname_to_true[fn] for fn in ref_fnames])

            preds_for_mcnemar[data["display_name"]] = aligned_pred
            if y_true_ref is None:
                y_true_ref = aligned_true

        mcnemar_results = run_mcnemar_tests(
            preds_for_mcnemar, y_true_ref, label_names
        )
        print_mcnemar_results(mcnemar_results)
        save_mcnemar_table(mcnemar_results, save_dir=stats_dir)

        # Also save to reports/ for convenience
        import shutil
        for ext in ("csv", "txt"):
            src = os.path.join(stats_dir, f"mcnemar_results.{ext}")
            dst = os.path.join(reports_dir, f"mcnemar_results.{ext}")
            if os.path.isfile(src):
                shutil.copy2(src, dst)
    else:
        print("\n[McNemar] Skipped — need at least 2 models to compare.")

    # ── Advanced visualizations ───────────────────────────────────────────────
    print(f"\n[Plots] Generating advanced visualizations ...")

    # Build aligned prob / pred / true arrays keyed by display name
    ref_key    = list(all_model_data.keys())[0]
    ref_fnames = all_model_data[ref_key]["all_fnames"]
    ref_index  = {fn: i for i, fn in enumerate(ref_fnames)}

    probs_aligned = {}
    preds_aligned = {}
    y_true_aligned = None

    for model_key, data in all_model_data.items():
        fnames = data["all_fnames"]
        fname_to_prob = {fn: data["y_prob_concat"][i] for i, fn in enumerate(fnames)}
        fname_to_pred = {fn: data["y_pred_concat"][i] for i, fn in enumerate(fnames)}
        fname_to_true = {fn: data["y_true_concat"][i] for i, fn in enumerate(fnames)}
        probs_aligned[data["display_name"]] = np.array(
            [fname_to_prob[fn] for fn in ref_fnames]
        )
        preds_aligned[data["display_name"]] = np.array(
            [fname_to_pred[fn] for fn in ref_fnames]
        )
        if y_true_aligned is None:
            y_true_aligned = np.array([fname_to_true[fn] for fn in ref_fnames])

    plot_training_curves_combined(all_fold_histories, save_dir=plots_dir)

    if y_true_aligned is not None:
        plot_roc_curves(probs_aligned, y_true_aligned, label_names, save_dir=plots_dir)
        plot_roc_per_model(probs_aligned, y_true_aligned, label_names, save_dir=plots_dir)
        plot_pr_curves(probs_aligned, y_true_aligned, label_names, save_dir=plots_dir)

        # Confusion matrices from concatenated predictions (all folds)
        cms_by_model = {
            name: get_confusion_matrices(y_true_aligned, preds_aligned[name], label_names)
            for name in preds_aligned
        }
        plot_cm_summary(cms_by_model, label_names, save_dir=plots_dir)

    plot_label_metric_heatmap(agg_results_display, label_names, save_dir=plots_dir)
    plot_radar_chart(agg_results_display, save_dir=plots_dir)
    if len(all_model_data) >= 2:
        plot_mcnemar_table(mcnemar_results, save_dir=plots_dir)

    # ── Final best model ──────────────────────────────────────────────────────
    print(f"\n{'═'*65}")
    best_name = max(
        all_model_data.items(),
        key=lambda kv: kv[1]["agg"]["macro"]["f1"]["mean"],
    )[1]["display_name"]
    best_f1   = max(
        data["agg"]["macro"]["f1"]["mean"]
        for data in all_model_data.values()
    )
    print(f"★  Best model by mean Macro F1: {best_name}  "
          f"(F1 = {best_f1:.3f})")
    print(f"{'═'*65}")

    print(f"\n[Done]  All outputs saved to → {args.out_dir}/")
    print(f"  Fold checkpoints : {folds_root}/")
    print(f"  Reports          : {reports_dir}/")
    print(f"  Plots            : {plots_dir}/")
    print(f"  Statistics       : {stats_dir}/")


if __name__ == "__main__":
    main()
