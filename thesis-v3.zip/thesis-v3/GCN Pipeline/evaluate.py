"""
evaluate.py — Load a trained checkpoint and evaluate on the held-out test set.

Usage:
    python evaluate.py --model stgcn  --data_dir normalized/ --csv labels.csv
    python evaluate.py --model agcn   --data_dir normalized/ --csv labels.csv
    python evaluate.py --model ctrgcn --data_dir normalized/ --csv labels.csv

Optional:
    --ckpt  path/to/custom_checkpoint.pt  (default: results/checkpoints/<model>/best_model.pt)
"""

import os
import time
import argparse
import numpy as np
import torch
import torch.nn as nn

from data.dataset    import get_dataloaders, ACTIVE_LABEL_NAMES
from models          import MODEL_REGISTRY
from utils.metrics   import (compute_metrics, print_metrics, logits_to_pred,
                              get_confusion_matrices, get_classification_report)
from utils.visualize import plot_confusion_matrices


def parse_args():
    p = argparse.ArgumentParser(description="Evaluate a trained GCN on the test set")
    p.add_argument("--model",    choices=["stgcn", "agcn", "ctrgcn"], required=True)
    p.add_argument("--data_dir", type=str, required=True)
    p.add_argument("--csv",      type=str, required=True)
    p.add_argument("--ckpt",     type=str, default=None,
                   help="Checkpoint path. Defaults to results/checkpoints/<model>/best_model.pt")
    p.add_argument("--max_frames", type=int, default=300)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--seed",       type=int, default=42)
    p.add_argument("--dropout",    type=float, default=0.0,
                   help="Set to 0.0 for evaluation (disables dropout)")
    p.add_argument("--out_dir",    type=str, default="results")
    return p.parse_args()


@torch.no_grad()
def run_inference(model, loader, device):
    """Run model on a loader and collect all logits and labels."""
    model.eval()
    all_logits, all_labels, all_fnames = [], [], []

    for batch_x, batch_y, fnames in loader:
        batch_x  = batch_x.to(device, non_blocking=True)
        logits   = model(batch_x)
        all_logits.append(logits.cpu().numpy())
        all_labels.append(batch_y.numpy())
        all_fnames.extend(fnames)

    all_logits = np.concatenate(all_logits, axis=0)
    all_labels = np.concatenate(all_labels, axis=0)
    return all_logits, all_labels, all_fnames


def main():
    args = parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[Device] {device}")

    # ── Data ──────────────────────────────────────────────────────────────────
    # We need the exact same split as training — same seed guarantees this
    train_loader, val_loader, test_loader, pos_weights = get_dataloaders(
        data_dir   = args.data_dir,
        csv_path   = args.csv,
        max_frames = args.max_frames,
        batch_size = args.batch_size,
        seed       = args.seed,
    )

    num_classes = len(ACTIVE_LABEL_NAMES)

    # ── Load model ─────────────────────────────────────────────────────────────
    ModelClass = MODEL_REGISTRY[args.model]
    model = ModelClass(num_classes=num_classes, dropout=args.dropout).to(device)

    ckpt_path = args.ckpt or os.path.join(
        args.out_dir, "checkpoints", args.model, "best_model.pt"
    )
    if not os.path.isfile(ckpt_path):
        raise FileNotFoundError(
            f"Checkpoint not found: {ckpt_path}\n"
            f"Did you run:  python train.py --model {args.model} ?"
        )

    ckpt = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])
    print(f"[Checkpoint] Loaded epoch={ckpt.get('epoch','?')}  "
          f"val_loss={ckpt.get('val_loss','?'):.5f}  "
          f"val_f1={ckpt.get('val_f1','?'):.4f}")

    # ── Evaluate on validation set ─────────────────────────────────────────────
    print("\n" + "─"*50)
    print("VALIDATION SET")
    val_logits, val_labels, val_fnames = run_inference(model, val_loader, device)
    val_pred, val_prob = logits_to_pred(val_logits)
    val_metrics = compute_metrics(val_labels, val_pred, val_prob, ACTIVE_LABEL_NAMES)
    print_metrics(val_metrics, ACTIVE_LABEL_NAMES)

    # ── Evaluate on test set ───────────────────────────────────────────────────
    print("\n" + "─"*50)
    print("TEST SET")
    _t0 = time.perf_counter()
    test_logits, test_labels, test_fnames = run_inference(model, test_loader, device)
    _t1 = time.perf_counter()
    test_pred, test_prob = logits_to_pred(test_logits)
    test_metrics = compute_metrics(test_labels, test_pred, test_prob, ACTIVE_LABEL_NAMES)
    n_test = len(test_fnames)
    test_metrics["inference_time_ms"] = (_t1 - _t0) / max(n_test, 1) * 1000
    print(f"  Inference: {_t1 - _t0:.3f}s total  "
          f"({test_metrics['inference_time_ms']:.2f} ms/sample, n={n_test})")
    print_metrics(test_metrics, ACTIVE_LABEL_NAMES)

    # ── Confusion matrices ─────────────────────────────────────────────────────
    cms = get_confusion_matrices(test_labels, test_pred, ACTIVE_LABEL_NAMES)
    plot_confusion_matrices(cms, args.model.upper(),
                            save_dir=os.path.join(args.out_dir, "plots"))

    # ── Classification reports ─────────────────────────────────────────────────
    reports = get_classification_report(test_labels, test_pred, ACTIVE_LABEL_NAMES)
    report_path = os.path.join(args.out_dir, "reports",
                               f"{args.model}_classification_report.txt")
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    with open(report_path, "w") as f:
        f.write(f"Model: {args.model.upper()}\n")
        f.write(f"Checkpoint: {ckpt_path}\n\n")
        for label, report in reports.items():
            f.write(f"{'─'*40}\n{label}\n{'─'*40}\n{report}\n\n")
    print(f"\n[Report] Saved → {report_path}")

    # ── Per-sample predictions ─────────────────────────────────────────────────
    import pandas as pd
    pred_df = pd.DataFrame(test_pred, columns=ACTIVE_LABEL_NAMES)
    pred_df.insert(0, "filename", test_fnames)
    gt_df = pd.DataFrame(test_labels.astype(int), columns=ACTIVE_LABEL_NAMES)
    gt_df.insert(0, "filename", test_fnames)
    pred_df.to_csv(os.path.join(args.out_dir, "reports",
                                f"{args.model}_predictions.csv"), index=False)
    print(f"[Predictions] Saved per-sample predictions CSV")

    # ── Return metrics dict for compare.py ────────────────────────────────────
    return test_metrics


if __name__ == "__main__":
    main()
