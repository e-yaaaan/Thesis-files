"""
saliency.py — Gradient-based saliency: what the model looks at.

Loads the best saved checkpoint for each model, runs inference on a set
of positive samples, and computes input gradients to show which joints
and time steps were most important for the prediction.

Produces three plot types per model:
  saliency_joints_{model}.png      — horizontal bar chart: joint importance
  saliency_skeleton_{model}.png    — skeleton drawn with heatmap-coloured nodes
  saliency_temporal_{model}.png    — time × joint heatmap grid

Usage (run from inside GCN Pipeline/):
    python saliency.py --out_dir results_binary_no_aug --data_dir ../normalized --csv data/binary_labels.csv --binary
    python saliency.py --out_dir results_no_aug        --data_dir ../normalized --csv data/labels.csv
"""

import os
import sys
import json
import argparse
import numpy as np
import pandas as pd
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.cm as mplcm
from matplotlib.colors import Normalize

from models import MODEL_REGISTRY
from data.dataset import (
    GaitDataset, ACTIVE_LABEL_NAMES,
    BINARY_LABEL_NAMES, BINARY_CSV_COLUMNS,
)


# ─── Constants ────────────────────────────────────────────────────────────────

MODEL_KEYS    = ["stgcn", "agcn", "ctrgcn"]
MODEL_DISPLAY = {"stgcn": "ST-GCN", "agcn": "AGCN", "ctrgcn": "CTR-GCN"}
MODEL_COLORS  = {"stgcn": "#2196F3", "agcn": "#4CAF50", "ctrgcn": "#FF9800"}

# COCO 17-keypoint names
JOINT_NAMES = [
    "Nose", "L.Eye", "R.Eye", "L.Ear", "R.Ear",
    "L.Shoulder", "R.Shoulder", "L.Elbow", "R.Elbow",
    "L.Wrist", "R.Wrist", "L.Hip", "R.Hip",
    "L.Knee", "R.Knee", "L.Ankle", "R.Ankle",
]

# COCO skeleton connectivity
SKELETON_EDGES = [
    (0,1),(0,2),(1,3),(2,4),
    (5,6),(5,7),(7,9),(6,8),(8,10),
    (5,11),(6,12),(11,12),
    (11,13),(13,15),(12,14),(14,16),
]


# ─── Saliency computation ─────────────────────────────────────────────────────

def compute_saliency(model, x_tensor, label_idx, device):
    """
    Gradient of sigmoid(logit[label_idx]) w.r.t. the input skeleton.

    Args:
        model     : GCN model in eval mode
        x_tensor  : (C, T, V, M) float tensor
        label_idx : which output class to differentiate
        device    : torch device

    Returns:
        saliency (T, V) — absolute gradient averaged over C and M
    """
    x = x_tensor.unsqueeze(0).float().to(device)   # (1, C, T, V, M)
    x.requires_grad_(True)
    model.eval()

    logit = model(x)                                # (1, n_classes)
    score = torch.sigmoid(logit)[0, label_idx]
    score.backward()

    grad = x.grad.abs().squeeze(0)                  # (C, T, V, M)
    saliency = grad.mean(dim=(0, 3))                # (T, V)
    return saliency.detach().cpu().numpy()


# ─── Checkpoint loader ────────────────────────────────────────────────────────

def find_best_checkpoint(out_dir, model_key, n_folds=5):
    """Return (fold_idx, ckpt_path) for the fold with highest saved val_f1."""
    best_f1, best_fold = -1.0, 0
    for fi in range(n_folds):
        path = os.path.join(out_dir, "folds", model_key,
                            f"fold_{fi}", "best_model.pt")
        if not os.path.isfile(path):
            continue
        ckpt = torch.load(path, map_location="cpu")
        vf1  = float(ckpt.get("val_f1", 0.0))
        if vf1 > best_f1:
            best_f1, best_fold = vf1, fi
    ckpt_path = os.path.join(out_dir, "folds", model_key,
                             f"fold_{best_fold}", "best_model.pt")
    return best_fold, ckpt_path


# ─── Visualisations ───────────────────────────────────────────────────────────

def plot_joint_bar(joint_importance_dict, model_name, save_path):
    """
    Horizontal bar chart: one panel per label, joints sorted by importance.
    joint_importance_dict: {label_name: (17,) array}
    """
    n = len(joint_importance_dict)
    fig, axes = plt.subplots(1, n, figsize=(max(6, 5 * n), 6), squeeze=False)

    for col, (lname, imp) in enumerate(joint_importance_dict.items()):
        ax   = axes[0][col]
        imp  = imp / (imp.max() + 1e-8)
        order = np.argsort(imp)           # ascending so most important is at top
        colors = mplcm.plasma(imp[order])

        ax.barh(range(17), imp[order], color=colors, edgecolor="white", lw=0.4)
        ax.set_yticks(range(17))
        ax.set_yticklabels([JOINT_NAMES[i] for i in order], fontsize=8)
        ax.set_xlabel("Relative Importance", fontsize=9)
        ax.set_xlim(0, 1.12)
        ax.set_title(lname, fontsize=11, fontweight="bold")
        ax.grid(axis="x", alpha=0.3)

        # Annotate value
        for y, v in enumerate(imp[order]):
            ax.text(v + 0.01, y, f"{v:.2f}", va="center", fontsize=7)

    fig.suptitle(f"{model_name} — Joint Importance  (gradient saliency)",
                 fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  [Plot] Joint importance → {save_path}")


def plot_skeleton_overlay(joint_importance_dict, mean_pose_dict,
                          model_name, save_path):
    """
    Skeleton drawn with nodes coloured by joint importance.
    One panel per label.
    mean_pose_dict: {label_name: (17, 2) mean xy}
    """
    n = len(joint_importance_dict)
    fig, axes = plt.subplots(1, n, figsize=(max(5, 4 * n), 6), squeeze=False)

    for col, lname in enumerate(joint_importance_dict):
        ax   = axes[0][col]
        imp  = joint_importance_dict[lname]
        imp  = imp / (imp.max() + 1e-8)
        pose = mean_pose_dict[lname]        # (17, 2)

        norm = Normalize(vmin=0, vmax=1)
        cmap = mplcm.plasma

        # Edges
        for i, j in SKELETON_EDGES:
            ax.plot([pose[i, 0], pose[j, 0]],
                    [pose[i, 1], pose[j, 1]],
                    color="#cccccc", lw=2, zorder=1)

        # Joints coloured by importance
        sc = ax.scatter(
            pose[:, 0], pose[:, 1],
            c=imp, cmap="plasma", norm=norm,
            s=140, zorder=2, edgecolors="black", linewidths=0.6,
        )

        # Label the top-3 most important joints
        top3 = np.argsort(imp)[-3:][::-1]
        for rank, ji in enumerate(top3):
            ax.annotate(
                JOINT_NAMES[ji],
                (pose[ji, 0], pose[ji, 1]),
                textcoords="offset points", xytext=(6, 4),
                fontsize=7, color="black",
                bbox=dict(fc="white", alpha=0.6, pad=1, ec="none"),
            )

        plt.colorbar(sc, ax=ax, label="Importance", shrink=0.55)
        ax.set_aspect("equal")
        ax.invert_yaxis()
        ax.axis("off")
        ax.set_title(lname, fontsize=11, fontweight="bold")

    fig.suptitle(f"{model_name} — Skeleton Saliency  (top-3 joints labelled)",
                 fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  [Plot] Skeleton heatmap → {save_path}")


def plot_temporal_heatmap(temporal_saliency_dict, model_name, save_path):
    """
    Heatmap of (time × joint) saliency — one panel per label.
    temporal_saliency_dict: {label_name: (T, 17) array}
    """
    n = len(temporal_saliency_dict)
    fig, axes = plt.subplots(1, n, figsize=(max(8, 6 * n), 5), squeeze=False)

    for col, (lname, sal) in enumerate(temporal_saliency_dict.items()):
        ax = axes[0][col]
        # Downsample time axis so the plot stays readable
        step   = max(1, sal.shape[0] // 60)
        sal_ds = sal[::step]                    # (≤60, 17)
        sal_ds = sal_ds / (sal_ds.max() + 1e-8)

        im = ax.imshow(sal_ds.T, aspect="auto", cmap="plasma",
                       origin="upper", vmin=0, vmax=1)
        ax.set_xlabel(f"Time (every {step} frame{'s' if step>1 else ''})",
                      fontsize=9)
        ax.set_ylabel("Joint", fontsize=9)
        ax.set_yticks(range(17))
        ax.set_yticklabels(JOINT_NAMES, fontsize=7)
        ax.set_title(lname, fontsize=11, fontweight="bold")
        plt.colorbar(im, ax=ax, label="Relative saliency", shrink=0.85)

    fig.suptitle(f"{model_name} — Temporal × Joint Saliency Heatmap",
                 fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  [Plot] Temporal heatmap → {save_path}")


# ─── All-model joint importance comparison ────────────────────────────────────

def plot_all_models_comparison(all_joint_imp, label_names, save_path):
    """
    One subplot per label — all three models overlaid as line plots of
    joint importance, so you can see which joints each model focuses on.
    """
    MODEL_PLOT_COLORS = ["#2196F3", "#4CAF50", "#FF9800"]
    n = len(label_names)
    fig, axes = plt.subplots(1, n, figsize=(max(8, 6 * n), 5), squeeze=False)

    x = np.arange(17)
    for col, lname in enumerate(label_names):
        ax = axes[0][col]
        for (model_display, imp_dict), color in zip(
                all_joint_imp.items(), MODEL_PLOT_COLORS):
            if lname not in imp_dict:
                continue
            imp = imp_dict[lname] / (imp_dict[lname].max() + 1e-8)
            ax.plot(x, imp, "o-", color=color, lw=2, markersize=5,
                    label=model_display)
        ax.set_xticks(x)
        ax.set_xticklabels(JOINT_NAMES, rotation=45, ha="right", fontsize=8)
        ax.set_ylabel("Relative Importance", fontsize=9)
        ax.set_ylim(0, 1.1)
        ax.set_title(lname, fontsize=11, fontweight="bold")
        ax.legend(fontsize=9)
        ax.grid(alpha=0.3)

    fig.suptitle("Joint Importance Comparison — All Models",
                 fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] All-model joint comparison → {save_path}")


# ─── Video frame overlay helpers ─────────────────────────────────────────────

def _find_video(video_dir, stem):
    """Return path to video file matching stem, trying common extensions."""
    for ext in (".MOV", ".mp4", ".mov", ".avi"):
        p = os.path.join(video_dir, stem + ext)
        if os.path.isfile(p):
            return p
    return None


def _extract_middle_frame(video_path):
    """
    Open video and return (RGB frame, frame_index) at the midpoint.
    Falls back to sequential read if random seek fails.
    """
    try:
        import cv2
    except ImportError:
        raise ImportError("opencv-python is required for video overlay: pip install opencv-python")

    cap = cv2.VideoCapture(video_path)
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    mid = max(0, total // 2)

    cap.set(cv2.CAP_PROP_POS_FRAMES, mid)
    ret, frame = cap.read()
    if not ret:
        # Seek failed — read sequentially
        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
        for _ in range(mid + 1):
            ret, frame = cap.read()
            if not ret:
                break
    cap.release()

    if not ret or frame is None:
        return None, mid

    import cv2 as _cv2
    return _cv2.cvtColor(frame, _cv2.COLOR_BGR2RGB), mid


def _load_raw_kpts(pred_dir, stem, frame_idx):
    """
    Return (17, 2) float32 pixel-space keypoints from predictions JSON
    at the given frame index.  Returns None if file or keypoints missing.
    """
    path = os.path.join(pred_dir, stem + ".json")
    if not os.path.isfile(path):
        return None
    with open(path, encoding="utf-8") as f:
        frames = json.load(f)
    frame_idx = min(frame_idx, len(frames) - 1)
    kpts = frames[frame_idx].get("keypoints", [])
    if not kpts:
        return None
    return np.array(kpts[0], dtype=np.float32)   # (17, 2) – pixel coords


def plot_frame_overlay(frame_rgb, raw_kpts, joint_imp_dict,
                       model_name, save_path):
    """
    Draw gradient-saliency heatmap overlay on a real video frame.

    frame_rgb      : (H, W, 3) uint8 RGB
    raw_kpts       : (17, 2) pixel coords, or None
    joint_imp_dict : {label_name: (17,) importance array}
    """
    n = len(joint_imp_dict)
    fig, axes = plt.subplots(1, n, figsize=(max(7, 6 * n), 6), squeeze=False)

    norm = Normalize(vmin=0, vmax=1)
    cmap = mplcm.plasma

    for col, (lname, imp) in enumerate(joint_imp_dict.items()):
        ax  = axes[0][col]
        imp = imp / (imp.max() + 1e-8)

        ax.imshow(frame_rgb)

        if raw_kpts is not None:
            H, W = frame_rgb.shape[:2]

            # Skeleton edges
            for i, j in SKELETON_EDGES:
                ax.plot([raw_kpts[i, 0], raw_kpts[j, 0]],
                        [raw_kpts[i, 1], raw_kpts[j, 1]],
                        color="white", lw=1.5, alpha=0.55, zorder=2)

            # Gaussian blobs (semi-transparent circles sized by importance)
            for ji in range(17):
                radius = 10 + imp[ji] * 55
                circle = plt.Circle(
                    (raw_kpts[ji, 0], raw_kpts[ji, 1]),
                    radius, color=cmap(norm(imp[ji])),
                    alpha=0.38, zorder=3,
                )
                ax.add_patch(circle)

            # Joint dots on top
            sc = ax.scatter(
                raw_kpts[:, 0], raw_kpts[:, 1],
                c=imp, cmap="plasma", norm=norm,
                s=60, zorder=4, edgecolors="white", linewidths=0.8,
            )
            plt.colorbar(sc, ax=ax, label="Joint Importance",
                         shrink=0.55, fraction=0.035)

            # Annotate top-3 joints
            top3 = np.argsort(imp)[-3:][::-1]
            for ji in top3:
                ax.annotate(
                    JOINT_NAMES[ji],
                    (raw_kpts[ji, 0], raw_kpts[ji, 1]),
                    textcoords="offset points", xytext=(8, 4),
                    fontsize=8, color="white", fontweight="bold",
                    bbox=dict(fc="black", alpha=0.55, pad=1.5, ec="none"),
                )

        ax.set_xlim(0, frame_rgb.shape[1])
        ax.set_ylim(frame_rgb.shape[0], 0)   # image y-axis
        ax.axis("off")
        ax.set_title(lname, fontsize=11, fontweight="bold")

    fig.suptitle(
        f"{model_name} — Saliency Overlay  (middle frame, top-3 joints labelled)",
        fontsize=12, fontweight="bold",
    )
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(save_path, dpi=120, bbox_inches="tight")
    plt.close(fig)


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser(
        description="Gradient saliency — what the GCN model looks at"
    )
    p.add_argument("--out_dir",   required=True,
                   help="Results directory, e.g. results_binary_no_aug")
    p.add_argument("--data_dir",  required=True,
                   help="Path to normalized/ folder containing .npy files")
    p.add_argument("--csv",       required=True,
                   help="Path to labels CSV")
    p.add_argument("--binary",    action="store_true",
                   help="Binary classification mode")
    p.add_argument("--n_folds",   type=int, default=5)
    p.add_argument("--n_samples", type=int, default=5,
                   help="Positive samples per label to average saliency over")
    p.add_argument("--video_dir", default=None,
                   help="Path to videos_norm/ folder for frame overlay (optional)")
    p.add_argument("--pred_dir",  default=None,
                   help="Path to predictions/ folder (default: ../predictions)")
    p.add_argument("--all_videos", action="store_true",
                   help="Overlay saliency on every video (per-video gradients); "
                        "default: only the --n_samples positive examples")
    args = p.parse_args()

    if args.pred_dir is None:
        args.pred_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "..", "predictions"
        )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[Device] {device}")

    plots_dir = os.path.join(args.out_dir, "plots")
    os.makedirs(plots_dir, exist_ok=True)

    # ── Label setup ───────────────────────────────────────────────────────────
    if args.binary:
        label_names = BINARY_LABEL_NAMES
        label_cols  = BINARY_CSV_COLUMNS
    else:
        label_names = ACTIVE_LABEL_NAMES
        label_cols  = None
    num_classes = len(label_names)

    # ── Load CSV and find valid files ─────────────────────────────────────────
    df = pd.read_csv(args.csv, index_col=0)
    if label_cols:
        df = df[label_cols]

    valid_files = [
        f for f in df.index
        if os.path.isfile(os.path.join(args.data_dir, f))
    ]
    df = df.loc[valid_files]
    print(f"[Info] Valid samples : {len(valid_files)}")
    print(f"[Info] Labels        : {label_names}")

    # ── Collect per-label positive sample indices ─────────────────────────────
    label_pos_indices = {}
    for li, lname in enumerate(label_names):
        col_vals = df.values[:, li]
        label_pos_indices[lname] = [
            i for i, v in enumerate(col_vals) if v == 1
        ][:args.n_samples]
        print(f"  {lname}: {len(label_pos_indices[lname])} positive samples used")

    # Build dataset once (no augmentation)
    ds = GaitDataset(
        valid_files, df, args.data_dir, max_frames=300,
        active_only=True, augment=False,
        label_columns=label_cols,
    )

    # ── Per-model saliency ────────────────────────────────────────────────────
    all_joint_imp  = {}   # {display_name: {label_name: (17,) array}}
    loaded_models  = {}   # {model_key: model} — kept for video overlay phase

    for model_key in MODEL_KEYS:
        display  = MODEL_DISPLAY[model_key]
        fold_idx, ckpt_path = find_best_checkpoint(
            args.out_dir, model_key, args.n_folds
        )
        if not os.path.isfile(ckpt_path):
            print(f"\n[Skip] No checkpoint found for {display}")
            continue

        print(f"\n{'─'*55}")
        print(f"  {display}  — best fold={fold_idx}")

        # Load model
        ModelClass = MODEL_REGISTRY[model_key]
        model      = ModelClass(num_classes=num_classes, dropout=0.0).to(device)
        ckpt       = torch.load(ckpt_path, map_location=device)
        model.load_state_dict(ckpt["model_state_dict"])
        loaded_models[model_key] = model

        joint_importance = {}   # {label_name: (17,)}
        temporal_sal     = {}   # {label_name: (T, 17)}
        mean_poses       = {}   # {label_name: (17, 2)}

        for li, lname in enumerate(label_names):
            indices = label_pos_indices[lname]
            if not indices:
                print(f"  [Skip] {lname} — no positive samples")
                continue

            sal_list, xy_list = [], []
            for idx in indices:
                x_t, _, _ = ds[idx]            # torch Tensor (C, T, V, M)
                sal = compute_saliency(model, x_t, li, device)   # (T, V)
                sal_list.append(sal)

                # Extract xy coordinates for skeleton overlay
                x_np = x_t.numpy()             # (C, T, V, M)
                xy   = x_np[:2, :, :, 0].transpose(1, 2, 0)  # (T, V, 2)
                t    = xy.shape[0]
                mean_xy = xy[t//4 : 3*t//4].mean(axis=0)     # (V, 2)
                xy_list.append(mean_xy)

            avg_sal  = np.mean(sal_list, axis=0)              # (T, 17)
            avg_pose = np.mean(xy_list,  axis=0)              # (17, 2)

            joint_importance[lname] = avg_sal.mean(axis=0)   # (17,)
            temporal_sal[lname]     = avg_sal
            mean_poses[lname]       = avg_pose

        if not joint_importance:
            print(f"  [Skip] {display} — no saliency computed")
            continue

        all_joint_imp[display] = joint_importance

        # Save plots for this model
        slug = model_key
        plot_joint_bar(
            joint_importance, display,
            os.path.join(plots_dir, f"saliency_joints_{slug}.png"),
        )
        plot_skeleton_overlay(
            joint_importance, mean_poses, display,
            os.path.join(plots_dir, f"saliency_skeleton_{slug}.png"),
        )
        plot_temporal_heatmap(
            temporal_sal, display,
            os.path.join(plots_dir, f"saliency_temporal_{slug}.png"),
        )

    # ── All-model comparison ──────────────────────────────────────────────────
    if len(all_joint_imp) >= 2:
        plot_all_models_comparison(
            all_joint_imp, label_names,
            os.path.join(plots_dir, "saliency_all_models.png"),
        )

    # ── Video frame overlay ───────────────────────────────────────────────────
    if args.video_dir:
        print(f"\n{'─'*55}")
        print("  Video frame saliency overlay")

        # Decide which filenames to process
        if args.all_videos:
            target_files = list(valid_files)
        else:
            seen, target_files = set(), []
            for lname in label_names:
                for idx in label_pos_indices[lname]:
                    fn = valid_files[idx]
                    if fn not in seen:
                        seen.add(fn)
                        target_files.append(fn)

        print(f"  Processing {len(target_files)} video(s) × "
              f"{len(loaded_models)} model(s)")

        for model_key, model in loaded_models.items():
            display     = MODEL_DISPLAY[model_key]
            avg_imp     = all_joint_imp.get(display, {})
            overlay_dir = os.path.join(plots_dir, "saliency_overlay", model_key)
            os.makedirs(overlay_dir, exist_ok=True)

            for fname in target_files:
                stem       = os.path.splitext(fname)[0]
                video_path = _find_video(args.video_dir, stem)
                if video_path is None:
                    print(f"  [Skip] No video file for {stem}")
                    continue

                frame_rgb, frame_idx = _extract_middle_frame(video_path)
                if frame_rgb is None:
                    print(f"  [Skip] Could not read frame: {stem}")
                    continue

                raw_kpts = _load_raw_kpts(args.pred_dir, stem, frame_idx)

                # Per-video saliency (all_videos) or averaged saliency (default)
                if args.all_videos:
                    fidx = valid_files.index(fname)
                    x_t, _, _ = ds[fidx]
                    imp_dict = {}
                    for li, lname in enumerate(label_names):
                        sal = compute_saliency(model, x_t, li, device)
                        imp_dict[lname] = sal.mean(axis=0)
                else:
                    imp_dict = avg_imp

                if not imp_dict:
                    continue

                safe = stem.replace(" ", "_").replace("(", "").replace(")", "")
                save_path = os.path.join(overlay_dir, f"{safe}.png")
                plot_frame_overlay(frame_rgb, raw_kpts, imp_dict,
                                   display, save_path)

            print(f"  [{display}] Overlays saved → {overlay_dir}/")

    print(f"\n[Done] Saliency plots saved to → {plots_dir}/")


if __name__ == "__main__":
    main()
