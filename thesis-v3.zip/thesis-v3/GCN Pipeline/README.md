# Skeleton-Based Running Gait Deviation Detection
## ST-GCN vs AGCN vs CTR-GCN — Comparative Study

---

## Project Structure

```
gait_gcn/
├── data/
│   ├── __init__.py
│   └── dataset.py          ← Dataset loader (GaitDataset + DataLoader factory)
│
├── models/
│   ├── __init__.py          ← MODEL_REGISTRY
│   ├── stgcn.py             ← ST-GCN implementation
│   ├── agcn.py              ← AGCN implementation
│   └── ctrgcn.py            ← CTR-GCN implementation
│
├── utils/
│   ├── __init__.py
│   ├── metrics.py           ← Precision, Recall, F1, AUC, confusion matrices
│   └── visualize.py         ← Loss curves, confusion matrix plots, comparison table
│
├── train.py                 ← Train one model
├── evaluate.py              ← Evaluate one model on the test set
├── compare.py               ← Compare all three models, generate final table
├── requirements.txt
└── README.md
```

### Where to put your data

```
gait_gcn/
├── normalized/              ← Put all .npy skeleton files here
│   ├── Runner01.npy
│   ├── Runner02.npy
│   └── ...
└── labels.csv               ← Put your CSV here
```

---

## Installation

### Step 1 — Create a virtual environment

```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 2 — Install PyTorch

Visit https://pytorch.org/get-started/locally/ and select your OS and whether you
have an NVIDIA GPU (CUDA) or not.

**No GPU (CPU only):**
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
```

**NVIDIA GPU (CUDA 12.1):**
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
```

### Step 3 — Install remaining dependencies

```bash
pip install -r requirements.txt
```

### Step 4 — Verify installation

```bash
python -c "import torch; print(torch.__version__); print('CUDA:', torch.cuda.is_available())"
```

---

## Preparing Your Labels CSV

Your CSV must have this exact format:

```csv
filename,elbow,forwardlean,kneelift,heelstrike,armswing,backkick
Runner01.npy,0,0,0,1,1,0
Runner02.npy,0,0,0,0,0,0
```

- The `filename` column must match the `.npy` filenames exactly (including `.npy`).
- Label columns must appear in this order: `elbow, forwardlean, kneelift, heelstrike, armswing, backkick`.
- Values are binary: `0` (no deviation) or `1` (deviation present).

---

## Running Each Step

### Step 1 — Sanity check the dataset loader

Before training anything, verify the loader reads your data correctly:

```bash
python data/dataset.py normalized/ labels.csv
```

Expected output:
```
[Data Split]  seed=42
  Train : 64 samples
  Val   : 14 samples
  Test  : 14 samples
  Total : 92 samples

[Class Weights]
  Heel Strike                     positives= 13  pos_weight=5.92
  Poor Arm Swing                  positives= 23  pos_weight=1.78
  Excessive Back Kick             positives=  4  pos_weight=15.00

Batch tensor shape : torch.Size([4, 3, 300, 17, 1])
Label tensor shape : torch.Size([4, 3])
```

### Step 2 — Train ST-GCN

```bash
python train.py --model stgcn --data_dir normalized/ --csv labels.csv
```

### Step 3 — Train AGCN

```bash
python train.py --model agcn --data_dir normalized/ --csv labels.csv
```

### Step 4 — Train CTR-GCN

```bash
python train.py --model ctrgcn --data_dir normalized/ --csv labels.csv
```

### Step 5 — Evaluate each model

```bash
python evaluate.py --model stgcn   --data_dir normalized/ --csv labels.csv
python evaluate.py --model agcn    --data_dir normalized/ --csv labels.csv
python evaluate.py --model ctrgcn  --data_dir normalized/ --csv labels.csv
```

### Step 6 — Generate the comparison table

```bash
python compare.py --data_dir normalized/ --csv labels.csv
```

This generates:
- `results/reports/model_comparison.csv`   ← Final comparison table
- `results/plots/model_comparison.png`     ← Bar chart
- `results/plots/<model>_loss.png`         ← Loss curves per model
- `results/plots/<model>_confusion.png`    ← Confusion matrices per model
- `results/reports/<model>_classification_report.txt`

---

## Training Hyperparameters (All Flags)

| Flag           | Default | Explanation                                    |
|----------------|---------|------------------------------------------------|
| `--epochs`     | 100     | Maximum training epochs                        |
| `--batch_size` | 8       | Samples per batch                              |
| `--lr`         | 0.001   | Initial learning rate (Adam)                   |
| `--weight_decay`| 0.0001 | L2 regularisation                              |
| `--dropout`    | 0.5     | Dropout rate inside GCN blocks                 |
| `--patience`   | 20      | Early stopping: epochs without val improvement |
| `--max_frames` | 300     | Fixed sequence length (pad/truncate)           |
| `--seed`       | 42      | Random seed for reproducibility                |
| `--out_dir`    | results | Directory for checkpoints and plots            |

Example with custom hyperparameters:
```bash
python train.py \
    --model stgcn \
    --data_dir normalized/ \
    --csv labels.csv \
    --epochs 150 \
    --lr 5e-4 \
    --batch_size 4 \
    --patience 30
```

---

## Understanding the Input Tensor Shape

All three models (ST-GCN, AGCN, CTR-GCN) expect input tensors of shape:

```
(N, C, T, V, M)
 │  │  │  │  └── M = number of people per video (1 for running)
 │  │  │  └───── V = number of joints (17 COCO keypoints)
 │  │  └──────── T = temporal frames (300 after padding/truncation)
 │  └─────────── C = channels (3: x, y, confidence)
 └────────────── N = batch size
```

Your `.npy` files have shape `(T, 17, 3)`. The dataset loader converts these to
`(3, 300, 17, 1)` automatically.

---

## The Zero-Label Problem (Critical for Your Dataset)

Three of your six labels currently have **zero positive samples**:

| Label                  | Positives |
|------------------------|-----------|
| Poor Elbow Flexion     | 0         |
| No Forward Lean        | 0         |
| Knee Lift (>70 degrees)| 0         |
| **Heel Strike**        | **13**    |
| **Poor Arm Swing**     | **23**    |
| **Excessive Back Kick**| **4**     |

### Why labels with zero positives MUST be excluded

1. **Training problem**: `BCEWithLogitsLoss` with all-zero targets for a label
   means the gradient for that label always pushes the model to predict 0. The
   model learns nothing about that label — it simply predicts "normal" always.

2. **Evaluation problem**: Precision, Recall, and F1 are all undefined (0/0)
   when there are no positive samples. Sklearn returns 0.0 with a warning.
   Including these labels in macro F1 artificially deflates scores and makes
   model comparison misleading.

3. **Practical problem**: It is statistically impossible to train a classifier
   for a class with no positive examples. The model has never seen what that
   deviation looks like.

### What this code does

The code **excludes the three zero-positive labels entirely** from both
training and evaluation. Only these three are used:
- Heel Strike (13 positives)
- Poor Arm Swing (23 positives)
- Excessive Back Kick (4 positives)

### Best practice recommendation

- **If collecting more data is possible**: Ensure each label has at least
  10–20 positive examples before including it. Aim for at least 5 positive
  examples per label to appear in every split.

- **If data collection is complete**: Report the three active labels only.
  Include a note in your thesis that the remaining three labels require
  additional data collection before they can be trained.

### How this affects model comparison fairness

All three models (ST-GCN, AGCN, CTR-GCN) use the same 3-label output head
and the same training/test split. The comparison remains **fully fair**
because all models face identical conditions.

---

## Dataset Size Warning (92 Samples)

Your dataset of 92 videos is very small for deep learning. Here is what to
expect and how to mitigate the limitations:

### Expected challenges

1. **High variance**: Results may vary significantly between runs even with a
   fixed seed, because 14 test samples is a very small test set.

2. **Overfitting risk**: All three models have hundreds of thousands of
   parameters, far more than your sample count. Dropout (0.5) and L2
   regularisation help but do not fully solve this.

3. **Class imbalance**: "Excessive Back Kick" has only 4 positives total.
   After the 70/15/15 split, roughly 2–3 of these appear in the test set.
   A single wrong prediction dramatically changes F1.

### Mitigation strategies already applied

- **Stratified splitting**: The split preserves the positive class ratio
  using Heel Strike (13 positives) as the stratification variable.
- **Class-weighted loss**: `pos_weight` in `BCEWithLogitsLoss` up-weights
  rare positive classes (e.g., Excessive Back Kick gets weight ≈15).
- **Dropout (0.5)**: Prevents co-adaptation of neurons, reducing overfitting.
- **Weight decay (1e-4)**: L2 regularisation penalises large weights.
- **Early stopping (patience=20)**: Stops training when validation loss
  stops improving, preventing overfitting to training data.
- **Cosine annealing scheduler**: Smooth learning rate decay prevents the
  model from getting stuck in sharp minima.
- **Gradient clipping (max_norm=1.0)**: Prevents exploding gradients.

### Additional strategies to consider for your thesis

- **Cross-validation**: Replace the single 70/15/15 split with 5-fold or
  10-fold cross-validation. Report mean ± std across folds. This gives a
  more reliable performance estimate with small datasets.
- **Data augmentation**: Add small Gaussian noise to joint coordinates,
  random temporal subsampling, mirroring left/right joints.

---

## Model Architecture Summary

| Property         | ST-GCN           | AGCN              | CTR-GCN               |
|------------------|------------------|-------------------|-----------------------|
| Graph topology   | Fixed (static)   | Learnable + fixed | Learnable (per-channel) |
| Adaptivity       | None             | Global + per-sample| Per-channel refinement |
| Key innovation   | Baseline GCN     | Adaptive adjacency | Channel-wise topology  |
| Complexity       | Lowest           | Medium            | Highest               |
| Best for         | Establishing baseline | Dynamic patterns | Fine-grained features |

---

## Output Files

After running all steps, your `results/` folder contains:

```
results/
├── checkpoints/
│   ├── stgcn/best_model.pt
│   ├── agcn/best_model.pt
│   └── ctrgcn/best_model.pt
│
├── plots/
│   ├── stgcn_loss.png
│   ├── agcn_loss.png
│   ├── ctrgcn_loss.png
│   ├── stgcn_confusion.png
│   ├── agcn_confusion.png
│   ├── ctrgcn_confusion.png
│   └── model_comparison.png
│
└── reports/
    ├── stgcn_classification_report.txt
    ├── stgcn_predictions.csv
    ├── agcn_classification_report.txt
    ├── agcn_predictions.csv
    ├── ctrgcn_classification_report.txt
    ├── ctrgcn_predictions.csv
    └── model_comparison.csv         ← Use this in your thesis
```

---

## Troubleshooting

**"No matching .npy file" warning**
→ The filename in your CSV doesn't match the actual file name.
  Check for typos, spaces, or wrong extensions.

**CUDA out of memory**
→ Reduce batch size: `--batch_size 4` or `--batch_size 2`

**Training loss doesn't decrease**
→ Try a higher learning rate: `--lr 5e-3`
→ Or reduce max_frames: `--max_frames 150`

**All predictions are 0 (no positive predictions)**
→ The threshold (0.5) may be too high for imbalanced classes.
  This is expected with very few positives — report it honestly in your thesis.
  Consider lowering the threshold (e.g., 0.3) for evaluation.

**"FileNotFoundError: Checkpoint not found"**
→ You must run `train.py` before `evaluate.py`.
