"""
Skeleton augmentations for training.

To disable an augmentation: set its USE_* flag to False,
or pass the corresponding kwarg to apply_augmentations().
"""

import numpy as np

# Set any flag to False to disable that augmentation.
USE_GAUSSIAN_NOISE = True
USE_TEMPORAL_CROP  = True
USE_MIRROR         = False

GAUSSIAN_SIGMA    = 0.01
TEMPORAL_CROP_PCT = 0.10


_LR_PAIRS = [
    (1,  2),   # L-Eye    ↔ R-Eye
    (3,  4),   # L-Ear    ↔ R-Ear
    (5,  6),   # L-Shoulder ↔ R-Shoulder
    (7,  8),   # L-Elbow  ↔ R-Elbow
    (9,  10),  # L-Wrist  ↔ R-Wrist
    (11, 12),  # L-Hip    ↔ R-Hip
    (13, 14),  # L-Knee   ↔ R-Knee
    (15, 16),  # L-Ankle  ↔ R-Ankle
]


def _build_lr_permutation():
    """Build the full 17-element joint permutation array for a mirror flip."""
    perm = list(range(17))
    for left, right in _LR_PAIRS:
        perm[left], perm[right] = right, left
    return perm


LR_PERMUTATION = _build_lr_permutation()


def add_gaussian_noise(skeleton, sigma=GAUSSIAN_SIGMA):
    """
    Add zero-mean Gaussian noise to x and y coordinates only.
    Confidence values (channel index 2) are NOT modified.

    Args:
        skeleton : numpy float32 array, shape (T, 17, 3)
        sigma    : noise standard deviation

    Returns:
        augmented array, shape (T, 17, 3)
    """
    out = skeleton.copy()
    noise = np.random.normal(0.0, sigma,
                             size=out[:, :, :2].shape).astype(np.float32)
    out[:, :, :2] += noise
    return out


def random_temporal_crop(skeleton, crop_pct=TEMPORAL_CROP_PCT, max_frames=300):
    """
    Remove up to crop_pct fraction of frames from the start and/or end,
    then re-pad to max_frames with zeros (same padding logic as dataset.py).

    Temporal order is always preserved.

    Args:
        skeleton   : numpy float32 array, shape (T, 17, 3)
                     T is expected to equal max_frames (already padded)
        crop_pct   : maximum fraction of frames to remove
        max_frames : target sequence length after re-padding

    Returns:
        augmented array, shape (max_frames, 17, 3)
    """
    T = skeleton.shape[0]
    max_remove = max(1, int(T * crop_pct))
    n_remove   = np.random.randint(1, max_remove + 1)

    # Split the removal between start and end
    n_start = np.random.randint(0, n_remove + 1)
    n_end   = n_remove - n_start
    end_idx = T - n_end if n_end > 0 else T

    cropped = skeleton[n_start:end_idx]       # (T', 17, 3)  T' < T
    T_new   = cropped.shape[0]

    # Re-pad at end to restore max_frames length
    if T_new < max_frames:
        pad = np.zeros(
            (max_frames - T_new, skeleton.shape[1], skeleton.shape[2]),
            dtype=np.float32,
        )
        cropped = np.concatenate([cropped, pad], axis=0)
    else:
        cropped = cropped[:max_frames]

    return cropped


def mirror_skeleton(skeleton):
    """
    Horizontally mirror the skeleton by:
      1. Reflecting x-coordinates around the mean x value.
      2. Swapping left and right joint indices (COCO 17-keypoint aware).

    Args:
        skeleton : numpy float32 array, shape (T, 17, 3)

    Returns:
        mirrored array, shape (T, 17, 3)
    """
    out = skeleton.copy()
    # Flip x around the sequence mean (handles any coordinate scale)
    mean_x = out[:, :, 0].mean()
    out[:, :, 0] = 2.0 * mean_x - out[:, :, 0]
    # Swap left ↔ right joints
    out = out[:, LR_PERMUTATION, :]
    return out


def apply_augmentations(skeleton, max_frames=300,
                        use_noise=USE_GAUSSIAN_NOISE,
                        use_crop=USE_TEMPORAL_CROP,
                        use_mirror=USE_MIRROR):
    """
    Apply the enabled augmentations sequentially to a training skeleton.

    Called ONLY for training samples.  Val/test datasets must pass augment=False
    to GaitDataset (which skips this function entirely).

    Args:
        skeleton   : numpy float32 array, shape (T, 17, 3) — already padded
        max_frames : sequence length, needed for crop re-padding
        use_noise  : apply Gaussian noise augmentation
        use_crop   : apply random temporal crop augmentation
        use_mirror : apply left-right mirror (applied with 50 % probability)

    Returns:
        augmented numpy float32 array, shape (T, 17, 3)
    """
    if use_noise:
        skeleton = add_gaussian_noise(skeleton)
    if use_crop:
        skeleton = random_temporal_crop(skeleton, max_frames=max_frames)
    if use_mirror and np.random.random() < 0.5:
        skeleton = mirror_skeleton(skeleton)
    return skeleton
