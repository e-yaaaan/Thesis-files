"""Evaluation metrics for multi-label posture deviation detection."""

import numpy as np
from itertools import combinations
from scipy.stats import chi2, binom
from sklearn.metrics import (
    precision_score, recall_score, f1_score,
    accuracy_score, classification_report,
    confusion_matrix, roc_auc_score, matthews_corrcoef,
)
from data.dataset import ACTIVE_LABEL_NAMES


THRESHOLD = 0.5   # sigmoid threshold for binary prediction


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def logits_to_pred(logits_array, threshold=THRESHOLD):
    """Convert raw logits (numpy) to binary predictions and probabilities."""
    probs = sigmoid(logits_array)
    return (probs >= threshold).astype(np.int32), probs


def compute_metrics(y_true, y_pred, y_prob=None,
                    label_names=None, threshold=THRESHOLD):
    """Compute per-label and aggregate metrics for one evaluation set."""
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    results = {}

    per_label = {}
    for i, name in enumerate(label_names):
        yt = y_true[:, i]
        yp = y_pred[:, i]
        support = int(yt.sum())

        if support == 0:
            per_label[name] = {
                "precision": float("nan"),
                "recall":    float("nan"),
                "f1":        float("nan"),
                "support":   0,
                "note":      "No positive samples in this split",
            }
            continue

        per_label[name] = {
            "precision": precision_score(yt, yp, zero_division=0),
            "recall":    recall_score(yt, yp, zero_division=0),
            "f1":        f1_score(yt, yp, zero_division=0),
            "mcc":       float(matthews_corrcoef(yt, yp)),
            "support":   support,
        }
        if y_prob is not None:
            yp_prob = y_prob[:, i]
            n_neg = int((1 - yt).sum())
            try:
                per_label[name]["auc"] = (
                    float(roc_auc_score(yt, yp_prob)) if n_neg > 0 else float("nan")
                )
            except ValueError:
                per_label[name]["auc"] = float("nan")

    results["per_label"] = per_label

    results["macro"] = {
        "precision": precision_score(y_true, y_pred, average="macro",  zero_division=0),
        "recall":    recall_score(   y_true, y_pred, average="macro",  zero_division=0),
        "f1":        f1_score(       y_true, y_pred, average="macro",  zero_division=0),
    }
    _mcc_vals = [per_label[n].get("mcc", float("nan")) for n in label_names
                 if per_label.get(n, {}).get("support", 0) > 0]
    results["macro"]["mcc"] = float(np.nanmean(_mcc_vals)) if _mcc_vals else float("nan")
    results["micro"] = {
        "precision": precision_score(y_true, y_pred, average="micro", zero_division=0),
        "recall":    recall_score(   y_true, y_pred, average="micro", zero_division=0),
        "f1":        f1_score(       y_true, y_pred, average="micro", zero_division=0),
    }
    results["weighted"] = {
        "precision": precision_score(y_true, y_pred, average="weighted", zero_division=0),
        "recall":    recall_score(   y_true, y_pred, average="weighted", zero_division=0),
        "f1":        f1_score(       y_true, y_pred, average="weighted", zero_division=0),
    }

    results["subset_acc"] = float(accuracy_score(y_true, y_pred))

    results["hamming_loss"] = float(
        (y_true != y_pred).sum() / (y_true.shape[0] * y_true.shape[1])
    )
    results["hamming_acc"] = 1.0 - results["hamming_loss"]

    if y_prob is not None:
        try:
            results["auc_macro"] = float(
                roc_auc_score(y_true, y_prob, average="macro")
            )
        except ValueError:
            results["auc_macro"] = float("nan")

    return results


def print_metrics(results, label_names=None):
    """Pretty-print the metrics dict."""
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    print("\n" + "="*60)
    print("EVALUATION RESULTS")
    print("="*60)

    print("\n[Per-Label Metrics]")
    print(f"{'Label':<35} {'Prec':>6} {'Rec':>6} {'F1':>6} {'MCC':>6} {'AUC':>6} {'Supp':>5}")
    print("-"*73)
    for name in label_names:
        m = results["per_label"].get(name, {})
        if m.get("support", 0) == 0:
            print(f"  {name:<33} {'N/A':>6} {'N/A':>6} {'N/A':>6} {'N/A':>6} {'N/A':>6} {'0':>5}")
        else:
            mcc_v = m.get("mcc", float("nan"))
            auc_v = m.get("auc", float("nan"))
            mcc_s = f"{mcc_v:>6.3f}" if not np.isnan(mcc_v) else f"{'N/A':>6}"
            auc_s = f"{auc_v:>6.3f}" if not np.isnan(auc_v) else f"{'N/A':>6}"
            print(f"  {name:<33} "
                  f"{m['precision']:>6.3f} {m['recall']:>6.3f} "
                  f"{m['f1']:>6.3f} {mcc_s} {auc_s} {m['support']:>5d}")

    print("-"*73)
    m = results["macro"]
    mcc_macro_v = m.get("mcc", float("nan"))
    mcc_macro_s = f"{mcc_macro_v:>6.3f}" if not np.isnan(mcc_macro_v) else f"{'N/A':>6}"
    print(f"  {'macro avg':<33} "
          f"{m['precision']:>6.3f} {m['recall']:>6.3f} {m['f1']:>6.3f} {mcc_macro_s}")
    m = results["micro"]
    print(f"  {'micro avg':<33} "
          f"{m['precision']:>6.3f} {m['recall']:>6.3f} {m['f1']:>6.3f}")
    m = results["weighted"]
    print(f"  {'weighted avg':<33} "
          f"{m['precision']:>6.3f} {m['recall']:>6.3f} {m['f1']:>6.3f}")

    print(f"\n  Subset Accuracy (exact match) : {results['subset_acc']:.4f}")
    print(f"  Hamming Loss                  : {results['hamming_loss']:.4f}")
    print(f"  Hamming Accuracy              : {results['hamming_acc']:.4f}")
    if "auc_macro" in results:
        print(f"  ROC-AUC (macro)               : {results['auc_macro']:.4f}")
    if not np.isnan(results["macro"].get("mcc", float("nan"))):
        print(f"  MCC (macro avg)               : {results['macro']['mcc']:.4f}")
    if "inference_time_ms" in results:
        print(f"  Inference time                : {results['inference_time_ms']:.2f} ms/sample")
    print("="*73)


def get_confusion_matrices(y_true, y_pred, label_names=None):
    """Return per-label 2×2 confusion matrices as a dict."""
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES
    cms = {}
    for i, name in enumerate(label_names):
        cms[name] = confusion_matrix(y_true[:, i], y_pred[:, i], labels=[0, 1])
    return cms


def get_classification_report(y_true, y_pred, label_names=None):
    """Return sklearn classification_report string per label."""
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES
    reports = {}
    for i, name in enumerate(label_names):
        reports[name] = classification_report(
            y_true[:, i], y_pred[:, i],
            target_names=["Normal", "Deviation"],
            zero_division=0,
        )
    return reports


def aggregate_fold_metrics(fold_metrics_list, label_names=None):
    """Compute mean and std across CV folds for all metrics."""
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    result = {}
    n_folds = len(fold_metrics_list)

    # ── Scalar top-level metrics ──────────────────────────────────────────
    for key in ("subset_acc", "hamming_acc", "hamming_loss", "auc_macro"):
        vals = np.array(
            [m.get(key, np.nan) for m in fold_metrics_list], dtype=float
        )
        result[key] = {
            "mean":   float(np.nanmean(vals)),
            "std":    float(np.nanstd(vals, ddof=0)),
            "values": vals.tolist(),
        }

    for avg_type in ("macro", "micro", "weighted"):
        result[avg_type] = {}
        for metric in ("precision", "recall", "f1"):
            vals = np.array(
                [m[avg_type][metric] for m in fold_metrics_list], dtype=float
            )
            result[avg_type][metric] = {
                "mean":   float(np.nanmean(vals)),
                "std":    float(np.nanstd(vals, ddof=0)),
                "values": vals.tolist(),
            }

    result["per_label"] = {}
    for name in label_names:
        result["per_label"][name] = {}
        for metric in ("precision", "recall", "f1", "mcc", "auc"):
            vals = np.array(
                [m["per_label"].get(name, {}).get(metric, np.nan)
                 for m in fold_metrics_list],
                dtype=float,
            )
            result["per_label"][name][metric] = {
                "mean":   float(np.nanmean(vals)),
                "std":    float(np.nanstd(vals, ddof=0)),
                "values": vals.tolist(),
            }
        result["per_label"][name]["support"] = int(
            sum(m["per_label"].get(name, {}).get("support", 0)
                for m in fold_metrics_list)
        )

    mcc_vals = np.array(
        [m.get("macro", {}).get("mcc", np.nan) for m in fold_metrics_list], dtype=float
    )
    result["macro"]["mcc"] = {
        "mean":   float(np.nanmean(mcc_vals)),
        "std":    float(np.nanstd(mcc_vals, ddof=0)),
        "values": mcc_vals.tolist(),
    }

    it_vals = np.array(
        [m.get("inference_time_ms", np.nan) for m in fold_metrics_list], dtype=float
    )
    result["inference_time_ms"] = {
        "mean":   float(np.nanmean(it_vals)),
        "std":    float(np.nanstd(it_vals, ddof=0)),
        "values": it_vals.tolist(),
    }

    result["n_folds"] = n_folds
    return result


def print_cv_metrics(agg_metrics, model_name="Model", label_names=None):
    """Pretty-print aggregated cross-validation metrics (mean ± std)."""
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    print(f"\n{'='*65}")
    print(f"  {model_name}  —  5-Fold Cross-Validation Results")
    print(f"{'='*65}")

    m = agg_metrics["macro"]
    mi = agg_metrics["micro"]
    print(f"\n  Aggregate Metrics (mean ± std over {agg_metrics['n_folds']} folds):")
    print(f"    Hamming Accuracy    : "
          f"{agg_metrics['hamming_acc']['mean']:.3f} ± "
          f"{agg_metrics['hamming_acc']['std']:.3f}")
    print(f"    Hamming Loss        : "
          f"{agg_metrics['hamming_loss']['mean']:.3f} ± "
          f"{agg_metrics['hamming_loss']['std']:.3f}")
    print(f"    Macro  Precision    : "
          f"{m['precision']['mean']:.3f} ± {m['precision']['std']:.3f}")
    print(f"    Macro  Recall       : "
          f"{m['recall']['mean']:.3f} ± {m['recall']['std']:.3f}")
    print(f"    Macro  F1           : "
          f"{m['f1']['mean']:.3f} ± {m['f1']['std']:.3f}")
    print(f"    Micro  Precision    : "
          f"{mi['precision']['mean']:.3f} ± {mi['precision']['std']:.3f}")
    print(f"    Micro  Recall       : "
          f"{mi['recall']['mean']:.3f} ± {mi['recall']['std']:.3f}")
    print(f"    Micro  F1           : "
          f"{mi['f1']['mean']:.3f} ± {mi['f1']['std']:.3f}")
    auc = agg_metrics.get("auc_macro", {})
    if isinstance(auc, dict) and not np.isnan(auc.get("mean", float("nan"))):
        print(f"    ROC-AUC             : "
              f"{auc['mean']:.3f} ± {auc['std']:.3f}")
    mcc_m = agg_metrics.get("macro", {}).get("mcc", {})
    if isinstance(mcc_m, dict) and not np.isnan(mcc_m.get("mean", float("nan"))):
        print(f"    MCC (macro avg)     : "
              f"{mcc_m['mean']:.3f} ± {mcc_m['std']:.3f}")
    it = agg_metrics.get("inference_time_ms", {})
    if isinstance(it, dict) and not np.isnan(it.get("mean", float("nan"))):
        print(f"    Inference time      : "
              f"{it['mean']:.2f} ± {it['std']:.2f} ms/sample")

    print(f"\n  Per-Label F1 / MCC (mean ± std):")
    for name in label_names:
        f1  = agg_metrics["per_label"][name]["f1"]
        mcc = agg_metrics["per_label"][name].get("mcc", {})
        mcc_s = (f"  MCC={mcc['mean']:.3f}±{mcc['std']:.3f}"
                 if isinstance(mcc, dict) and not np.isnan(mcc.get("mean", float("nan")))
                 else "")
        print(f"    {name:<30s} : "
              f"F1={f1['mean']:.3f}±{f1['std']:.3f}{mcc_s}")
    print(f"{'='*65}")


def mcnemar_pvalue(b, c):
    """McNemar's test p-value from discordant cell counts b and c."""
    n = b + c
    if n == 0:
        return 1.0

    if n < 25:
        p = float(2.0 * binom.cdf(min(b, c), n, 0.5))
        return min(1.0, p)
    else:
        stat = (abs(b - c) - 1.0) ** 2 / float(n)
        return float(chi2.sf(stat, df=1))


def run_mcnemar_tests(model_preds_dict, y_true, label_names=None):
    """Pairwise McNemar's tests across all model pairs using exact-match accuracy."""
    model_names = list(model_preds_dict.keys())
    results = []

    for name_a, name_b in combinations(model_names, 2):
        pred_a = model_preds_dict[name_a]
        pred_b = model_preds_dict[name_b]

        correct_a = (pred_a == y_true).all(axis=1)
        correct_b = (pred_b == y_true).all(axis=1)

        b = int((~correct_a & correct_b).sum())
        c = int((correct_a & ~correct_b).sum())

        p_val = mcnemar_pvalue(b, c)

        results.append({
            "model_a":       name_a,
            "model_b":       name_b,
            "b":             b,
            "c":             c,
            "n_discordant":  b + c,
            "p_value":       p_val,
            "significant":   p_val < 0.05,
        })

    return results


def print_mcnemar_results(mcnemar_results):
    """Print McNemar's test results as a formatted table."""
    print(f"\n{'='*60}")
    print("McNemar's Test — Pairwise Model Comparison")
    print("(exact binomial for n_discordant < 25, chi-sq otherwise)")
    print(f"{'='*60}")
    print(f"{'Comparison':<30}  {'b':>4}  {'c':>4}  {'n_disc':>6}  "
          f"{'p-value':>9}  {'Sig?':>5}")
    print(f"{'-'*60}")

    for r in mcnemar_results:
        comp    = f"{r['model_a']} vs {r['model_b']}"
        sig_str = "YES *" if r["significant"] else "no"
        print(f"  {comp:<28}  {r['b']:>4}  {r['c']:>4}  "
              f"{r['n_discordant']:>6}  {r['p_value']:>9.4f}  {sig_str:>5}")

    print(f"{'-'*60}")
    print("  p < 0.05 → statistically significant difference")
    print(f"{'='*60}")
