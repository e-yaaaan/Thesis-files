"""
Visualization utilities for gait GCN experiments.

Generates:
  - Training and validation loss curves
  - Per-label confusion matrices
  - Model comparison bar chart
  - Final comparison table (CSV + printed)
  - Cross-validation summary bar chart with error bars
  - Per-fold training curves overlay
  - McNemar's test results table (CSV + TXT)
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")   # non-interactive backend (works on headless servers)
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import seaborn as sns

from data.dataset import ACTIVE_LABEL_NAMES


RESULTS_DIR    = "results"
PLOTS_DIR      = os.path.join(RESULTS_DIR, "plots")
REPORTS_DIR    = os.path.join(RESULTS_DIR, "reports")
STATISTICS_DIR = os.path.join(RESULTS_DIR, "statistics")


# ─── Loss Curves ─────────────────────────────────────────────────────────────

def plot_loss_curves(train_losses, val_losses, model_name,
                     save_dir=PLOTS_DIR):
    """
    Plot training and validation loss curves.

    Args:
        train_losses : list of floats, one per epoch
        val_losses   : list of floats, one per epoch
        model_name   : e.g. "ST-GCN"
        save_dir     : directory to save the PNG
    """
    epochs = range(1, len(train_losses) + 1)

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(epochs, train_losses, "b-o", markersize=3, label="Train Loss")
    ax.plot(epochs, val_losses,   "r-o", markersize=3, label="Val Loss")

    best_epoch = int(np.argmin(val_losses)) + 1
    ax.axvline(best_epoch, color="gray", linestyle="--", alpha=0.7,
               label=f"Best val epoch ({best_epoch})")

    ax.set_title(f"{model_name} — BCE Loss Curves", fontsize=14)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("BCE Loss")
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    fname = os.path.join(save_dir,
                         f"{model_name.lower().replace(' ', '_')}_loss.png")
    fig.tight_layout()
    fig.savefig(fname, dpi=150)
    plt.close(fig)
    print(f"[Plot] Saved loss curve → {fname}")


# ─── Per-fold Training Curves Overlay ────────────────────────────────────────

def plot_fold_loss_curves(fold_histories, model_name, save_dir=PLOTS_DIR):
    """
    Plot val loss for all folds overlaid in one figure.

    Args:
        fold_histories : list of dicts {"train_loss": [...], "val_loss": [...]}
        model_name     : e.g. "ST-GCN"
        save_dir       : directory to save the PNG
    """
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    colors = plt.cm.tab10(np.linspace(0, 0.9, len(fold_histories)))

    for fold_idx, (hist, color) in enumerate(zip(fold_histories, colors)):
        epochs = range(1, len(hist["val_loss"]) + 1)
        axes[0].plot(epochs, hist["train_loss"], color=color,
                     alpha=0.8, label=f"Fold {fold_idx}")
        axes[1].plot(epochs, hist["val_loss"],   color=color,
                     alpha=0.8, label=f"Fold {fold_idx}")

    for ax, title in zip(axes, ["Train Loss", "Val Loss"]):
        ax.set_title(f"{model_name} — {title} per Fold", fontsize=12)
        ax.set_xlabel("Epoch")
        ax.set_ylabel("BCE Loss")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    fname = os.path.join(save_dir,
                         f"{model_name.lower().replace(' ', '_')}_fold_curves.png")
    fig.tight_layout()
    fig.savefig(fname, dpi=150)
    plt.close(fig)
    print(f"[Plot] Saved fold loss curves → {fname}")


# ─── Confusion Matrices ───────────────────────────────────────────────────────

def plot_confusion_matrices(cms_dict, model_name, save_dir=PLOTS_DIR):
    """
    Plot one confusion matrix per label.

    Args:
        cms_dict   : {label_name: 2×2 numpy array}
        model_name : e.g. "ST-GCN"
    """
    label_names = list(cms_dict.keys())
    n = len(label_names)
    ncols = min(n, 3)
    nrows = (n + ncols - 1) // ncols

    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4.5 * nrows))
    axes = np.array(axes).flatten()

    for i, (name, cm) in enumerate(cms_dict.items()):
        ax = axes[i]
        support = cm.sum()
        if support == 0:
            ax.text(0.5, 0.5, "No samples", ha="center", va="center",
                    fontsize=12, transform=ax.transAxes)
            ax.set_title(name, fontsize=11)
            ax.axis("off")
            continue

        cm_norm = cm.astype(float)
        row_sums = cm_norm.sum(axis=1, keepdims=True)
        row_sums[row_sums == 0] = 1
        cm_pct = cm_norm / row_sums

        sns.heatmap(
            cm_pct, annot=True, fmt=".2f", cmap="Blues",
            xticklabels=["Pred: Normal", "Pred: Deviation"],
            yticklabels=["True: Normal", "True: Deviation"],
            ax=ax, cbar=False, vmin=0, vmax=1,
            annot_kws={"size": 11},
        )
        for r in range(2):
            for c in range(2):
                ax.text(c + 0.5, r + 0.75, f"(n={cm[r,c]})",
                        ha="center", va="center",
                        fontsize=8, color="dimgray")

        ax.set_title(f"{name}\n(n={support})", fontsize=10)

    for j in range(i + 1, len(axes)):
        axes[j].axis("off")

    fig.suptitle(f"{model_name} — Confusion Matrices (row-normalised)",
                 fontsize=13, y=1.01)
    fig.tight_layout()

    fname = os.path.join(save_dir,
                         f"{model_name.lower().replace(' ', '_')}_confusion.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved confusion matrices → {fname}")


# ─── Comparison Bar Chart (single-run mode) ───────────────────────────────────

def plot_model_comparison(comparison_df, save_dir=PLOTS_DIR):
    """
    Bar chart comparing models across metrics (no error bars — single run).

    Args:
        comparison_df : pandas DataFrame with columns
                        [Model, Hamming_Acc, Macro_Prec, Macro_Rec, Macro_F1]
    """
    metrics = ["Hamming_Acc", "Macro_Prec", "Macro_Rec", "Macro_F1"]
    labels  = ["Accuracy", "Precision", "Recall", "F1-score"]
    models  = comparison_df["Model"].tolist()
    x       = np.arange(len(metrics))
    width   = 0.25

    fig, ax = plt.subplots(figsize=(11, 6))
    colors = ["#2196F3", "#4CAF50", "#FF9800"]

    for i, (model, color) in enumerate(zip(models, colors)):
        row    = comparison_df[comparison_df["Model"] == model].iloc[0]
        vals   = [row[m] for m in metrics]
        offset = (i - len(models) / 2 + 0.5) * width
        bars   = ax.bar(x + offset, vals, width, label=model,
                        color=color, alpha=0.85, edgecolor="white")
        for bar, v in zip(bars, vals):
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + 0.005,
                    f"{v:.3f}", ha="center", va="bottom", fontsize=8.5)

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=11)
    ax.set_ylim(0, 1.1)
    ax.set_ylabel("Score")
    ax.set_title("Model Comparison — Multi-Label Posture Deviation Detection",
                 fontsize=13)
    ax.legend(loc="upper right")
    ax.grid(axis="y", alpha=0.3)
    ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))

    fig.tight_layout()
    fname = os.path.join(save_dir, "model_comparison.png")
    fig.savefig(fname, dpi=150)
    plt.close(fig)
    print(f"[Plot] Saved model comparison → {fname}")


# ─── CV Summary Bar Chart with Error Bars ────────────────────────────────────

def plot_cv_summary(agg_results_dict, save_dir=PLOTS_DIR):
    """
    Bar chart with error bars comparing models across CV mean ± std metrics.

    Args:
        agg_results_dict : {model_name: agg_metrics_dict}
                           agg_metrics_dict is the output of aggregate_fold_metrics()
        save_dir         : directory to save PNG
    """
    metric_keys  = [
        ("hamming_loss",       "Hamming\nLoss"),
        ("macro.precision",    "Macro\nPrecision"),
        ("macro.recall",       "Macro\nRecall"),
        ("macro.f1",           "Macro\nF1"),
        ("micro.precision",    "Micro\nPrecision"),
        ("micro.recall",       "Micro\nRecall"),
        ("micro.f1",           "Micro\nF1"),
    ]
    # Add AUC and MCC if available
    sample_agg = next(iter(agg_results_dict.values()))
    auc_mean = sample_agg.get("auc_macro", {}).get("mean", float("nan"))
    if not np.isnan(auc_mean):
        metric_keys.append(("auc_macro", "ROC-AUC"))
    mcc_d = sample_agg.get("macro", {}).get("mcc", {})
    if isinstance(mcc_d, dict) and not np.isnan(mcc_d.get("mean", float("nan"))):
        metric_keys.append(("macro.mcc", "MCC"))

    model_names = list(agg_results_dict.keys())
    n_metrics   = len(metric_keys)
    x           = np.arange(n_metrics)
    width       = 0.20
    colors      = ["#2196F3", "#4CAF50", "#FF9800"]

    fig, ax = plt.subplots(figsize=(max(16, 2.0 * n_metrics), 6))

    def _get(agg, key):
        """Navigate dotted key e.g. 'macro.f1' → agg['macro']['f1']."""
        parts = key.split(".")
        obj = agg
        for p in parts:
            obj = obj[p]
        return obj

    for i, (model, color) in enumerate(zip(model_names, colors)):
        agg    = agg_results_dict[model]
        means  = [_get(agg, k)["mean"] for k, _ in metric_keys]
        stds   = [_get(agg, k)["std"]  for k, _ in metric_keys]
        offset = (i - len(model_names) / 2 + 0.5) * width

        bars = ax.bar(x + offset, means, width, yerr=stds,
                      label=model, color=color, alpha=0.85,
                      edgecolor="white", capsize=4,
                      error_kw={"elinewidth": 1.5, "ecolor": "black"})
        for bar, m, s in zip(bars, means, stds):
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + s + 0.008,
                    f"{m:.2f}", ha="center", va="bottom", fontsize=7.5)

    ax.set_xticks(x)
    ax.set_xticklabels([lbl for _, lbl in metric_keys], fontsize=11)
    ax.set_ylim(0, 1.15)
    ax.set_ylabel("Score")
    ax.set_title(
        "5-Fold CV Comparison — Multi-Label Posture Deviation Detection\n"
        "(bars = mean, error bars = ± std)",
        fontsize=12,
    )
    ax.legend(loc="upper right")
    ax.grid(axis="y", alpha=0.3)
    ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))

    fig.tight_layout()
    fname = os.path.join(save_dir, "cv_model_comparison.png")
    fig.savefig(fname, dpi=150)
    plt.close(fig)
    print(f"[Plot] Saved CV comparison → {fname}")


# ─── Individual per-metric bar charts ────────────────────────────────────────

def plot_cv_individual_metrics(agg_results_dict, save_dir=PLOTS_DIR):
    """
    For each metric:
      - One fold-by-fold bar chart per model  →  cv_<metric>_<modelslug>.png
      - One combined chart comparing all models  →  cv_<metric>.png

    The per-model charts show each fold's score as individual bars with a
    dashed mean line and ± std shaded band, making variance across folds clear.
    The combined chart shows mean ± std grouped bars for all models at once.
    """
    _LOWER_IS_BETTER = {"hamming_loss"}

    metric_keys = [
        ("hamming_loss",    "Hamming Loss"),
        ("macro.precision", "Macro Precision"),
        ("macro.recall",    "Macro Recall"),
        ("macro.f1",        "Macro F1"),
        ("micro.precision", "Micro Precision"),
        ("micro.recall",    "Micro Recall"),
        ("micro.f1",        "Micro F1"),
    ]
    sample_agg = next(iter(agg_results_dict.values()))
    auc_mean = sample_agg.get("auc_macro", {}).get("mean", float("nan"))
    if not np.isnan(auc_mean):
        metric_keys.append(("auc_macro", "ROC-AUC"))
    mcc_d = sample_agg.get("macro", {}).get("mcc", {})
    if isinstance(mcc_d, dict) and not np.isnan(mcc_d.get("mean", float("nan"))):
        metric_keys.append(("macro.mcc", "MCC_adj"))

    model_names = list(agg_results_dict.keys())
    colors      = ["#2196F3", "#4CAF50", "#FF9800"]

    def _get(agg, key):
        parts = key.split(".")
        obj = agg
        for p in parts:
            obj = obj[p]
        return obj

    def _model_slug(name):
        return name.lower().replace("-", "").replace(" ", "_")

    os.makedirs(save_dir, exist_ok=True)

    for metric_key, metric_label in metric_keys:
        slug = metric_key.replace(".", "_")
        note = "  (lower is better)" if metric_key in _LOWER_IS_BETTER else ""

        # ── Per-model fold-by-fold charts ─────────────────────────────────
        is_mcc = (metric_key == "macro.mcc")
        for model_name, color in zip(model_names, colors):
            d = _get(agg_results_dict[model_name], metric_key)
            fold_vals = [v for v in d.get("values", []) if v is not None]
            mean_val  = d["mean"]
            std_val   = d["std"]
            if is_mcc:
                fold_vals = [(v + 1) / 2 for v in fold_vals]
                mean_val  = (mean_val + 1) / 2
                std_val   = std_val / 2
            n_folds   = len(fold_vals)

            fig, ax = plt.subplots(figsize=(7, 5))
            xf = np.arange(n_folds)

            bars = ax.bar(xf, fold_vals, 0.55,
                          color=color, alpha=0.80, edgecolor="white")
            for bar, v in zip(bars, fold_vals):
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + 0.012,
                        f"{v:.3f}", ha="center", va="bottom", fontsize=10)

            ax.axhline(mean_val, color="black", linewidth=2,
                       linestyle="--", label=f"Mean = {mean_val:.3f}")
            ax.axhspan(mean_val - std_val, mean_val + std_val,
                       alpha=0.12, color="black",
                       label=f"± std ({std_val:.3f})")
            if is_mcc:
                ax.axhline(0.5, color="gray", linestyle=":", linewidth=1.5,
                           alpha=0.8, label="Random baseline = 0.5")

            ax.set_xticks(xf)
            ax.set_xticklabels([f"Fold {i}" for i in range(n_folds)],
                               fontsize=11)
            ax.set_ylim(0, 1.18)
            ax.set_ylabel("Score")
            ax.set_title(
                f"{model_name} — {metric_label}{note}\n"
                f"5-Fold CV — Posture Deviation Detection",
                fontsize=12,
            )
            ax.legend(fontsize=10)
            ax.grid(axis="y", alpha=0.3)
            ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))

            fig.tight_layout()
            mslug = _model_slug(model_name)
            fname = os.path.join(save_dir, f"cv_{slug}_{mslug}.png")
            fig.savefig(fname, dpi=150, bbox_inches="tight")
            plt.close(fig)
            print(f"[Plot] Saved per-model metric → {fname}")

        # ── Combined chart: all models ────────────────────────────────────
        x     = np.arange(len(model_names))
        width = 0.45
        fig, ax = plt.subplots(figsize=(7, 5))

        means = [_get(agg_results_dict[m], metric_key)["mean"] for m in model_names]
        stds  = [_get(agg_results_dict[m], metric_key)["std"]  for m in model_names]
        if is_mcc:
            means = [(m + 1) / 2 for m in means]
            stds  = [s / 2 for s in stds]

        bars = ax.bar(x, means, width,
                      yerr=stds,
                      color=colors[:len(model_names)],
                      alpha=0.85, edgecolor="white",
                      capsize=7,
                      error_kw={"elinewidth": 2, "ecolor": "black"})

        for bar, m, s in zip(bars, means, stds):
            ax.text(bar.get_x() + bar.get_width() / 2,
                    bar.get_height() + s + 0.013,
                    f"{m:.3f}", ha="center", va="bottom",
                    fontsize=11, fontweight="bold")

        if is_mcc:
            ax.axhline(0.5, color="gray", linestyle=":", linewidth=1.5,
                       alpha=0.8, label="Random baseline = 0.5")
            ax.legend(fontsize=10)

        ax.set_xticks(x)
        ax.set_xticklabels(model_names, fontsize=12)
        ax.set_ylim(0, 1.18)
        ax.set_ylabel("Score")
        ax.set_title(
            f"{metric_label}{note} — All Models\n"
            f"5-Fold CV — Posture Deviation Detection  (mean ± std)",
            fontsize=12,
        )
        ax.grid(axis="y", alpha=0.3)
        ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))

        fig.tight_layout()
        fname = os.path.join(save_dir, f"cv_{slug}.png")
        fig.savefig(fname, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"[Plot] Saved combined metric  → {fname}")


# ─── Comparison Table (single-run mode) ──────────────────────────────────────

def build_comparison_table(all_results, label_names=None):
    """
    Build a summary DataFrame from a dict of {model_name: metrics_dict}.
    Returns a pandas DataFrame ready to print and save.
    """
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    rows = []
    for model_name, res in all_results.items():
        row = {
            "Model":         model_name,
            "Hamming_Loss":  round(res.get("hamming_loss", float("nan")), 4),
            "Hamming_Acc":   round(res.get("hamming_acc",  float("nan")), 4),
            "Subset_Acc":    round(res.get("subset_acc",   float("nan")), 4),
            "Macro_Prec":    round(res["macro"]["precision"], 4),
            "Macro_Rec":     round(res["macro"]["recall"],    4),
            "Macro_F1":      round(res["macro"]["f1"],        4),
            "Micro_Prec":    round(res["micro"]["precision"], 4),
            "Micro_Rec":     round(res["micro"]["recall"],    4),
            "Micro_F1":      round(res["micro"]["f1"],        4),
            "Weighted_Prec": round(res["weighted"]["precision"], 4),
            "Weighted_Rec":  round(res["weighted"]["recall"],    4),
            "Weighted_F1":   round(res["weighted"]["f1"],        4),
        }
        if "auc_macro" in res:
            row["AUC_Macro"] = round(res["auc_macro"], 4)
        mcc_macro = res.get("macro", {}).get("mcc", float("nan"))
        if not np.isnan(mcc_macro):
            row["MCC_Macro"] = round(mcc_macro, 4)
        if "inference_time_ms" in res:
            row["Infer_ms"] = round(res["inference_time_ms"], 2)

        for name in label_names:
            f1 = res["per_label"].get(name, {}).get("f1", float("nan"))
            row[f"F1_{name[:12]}"] = round(f1, 4) if not np.isnan(f1) else float("nan")

        rows.append(row)

    return pd.DataFrame(rows)


def save_comparison_table(df, save_dir=REPORTS_DIR):
    """Save comparison table as CSV and print to console."""
    csv_path = os.path.join(save_dir, "model_comparison.csv")
    df.to_csv(csv_path, index=False)
    print(f"\n[Table] Saved comparison CSV → {csv_path}")

    print("\n" + "="*80)
    print("FINAL MODEL COMPARISON")
    print("="*80)
    cols_to_show = ["Model", "Hamming_Acc", "Macro_Prec", "Macro_Rec", "Macro_F1"]
    for extra in ("AUC_Macro", "MCC_Macro", "Infer_ms"):
        if extra in df.columns:
            cols_to_show.append(extra)
    print(df[cols_to_show].to_string(index=False))
    print("="*80)

    if not df["Macro_F1"].isna().all():
        best_idx   = df["Macro_F1"].idxmax()
        best_model = df.loc[best_idx, "Model"]
        best_f1    = df.loc[best_idx, "Macro_F1"]
        print(f"\n★  Best model by Macro F1: {best_model}  (F1 = {best_f1:.4f})")
    print("="*80)

    return csv_path


# ─── CV Summary Table ─────────────────────────────────────────────────────────

def save_cv_summary(agg_results_dict, save_dir=REPORTS_DIR,
                    label_names=None):
    """
    Save cross-validation summary as CSV and human-readable TXT.

    Args:
        agg_results_dict : {model_name: agg_metrics_dict}
        save_dir         : where to write the files
        label_names      : label names list

    Returns:
        (csv_path, txt_path)
    """
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    os.makedirs(save_dir, exist_ok=True)

    rows = []
    for model_name, agg in agg_results_dict.items():
        m   = agg["macro"]
        auc = agg.get("auc_macro", {"mean": float("nan"), "std": float("nan")})
        mcc_macro = m.get("mcc", {"mean": float("nan"), "std": float("nan")})
        it  = agg.get("inference_time_ms", {"mean": float("nan"), "std": float("nan")})
        mi = agg.get("micro", {})
        hl = agg.get("hamming_loss", {"mean": float("nan"), "std": float("nan")})
        row = {
            "Model":                model_name,
            "HammingLoss_Mean":     round(hl.get("mean", float("nan")), 4),
            "HammingLoss_Std":      round(hl.get("std",  float("nan")), 4),
            "Accuracy_Mean":        round(agg["hamming_acc"]["mean"], 4),
            "Accuracy_Std":         round(agg["hamming_acc"]["std"],  4),
            "MacroPrecision_Mean":  round(m["precision"]["mean"], 4),
            "MacroPrecision_Std":   round(m["precision"]["std"],  4),
            "MacroRecall_Mean":     round(m["recall"]["mean"], 4),
            "MacroRecall_Std":      round(m["recall"]["std"],  4),
            "MacroF1_Mean":         round(m["f1"]["mean"], 4),
            "MacroF1_Std":          round(m["f1"]["std"],  4),
            "MicroPrecision_Mean":  round(mi.get("precision", {}).get("mean", float("nan")), 4),
            "MicroPrecision_Std":   round(mi.get("precision", {}).get("std",  float("nan")), 4),
            "MicroRecall_Mean":     round(mi.get("recall",    {}).get("mean", float("nan")), 4),
            "MicroRecall_Std":      round(mi.get("recall",    {}).get("std",  float("nan")), 4),
            "MicroF1_Mean":         round(mi.get("f1",        {}).get("mean", float("nan")), 4),
            "MicroF1_Std":          round(mi.get("f1",        {}).get("std",  float("nan")), 4),
            "AUC_Mean":             round(auc.get("mean", float("nan")), 4),
            "AUC_Std":              round(auc.get("std",  float("nan")), 4),
            "MCC_Mean":             round(mcc_macro.get("mean", float("nan")), 4) if isinstance(mcc_macro, dict) else float("nan"),
            "MCC_Std":              round(mcc_macro.get("std",  float("nan")), 4) if isinstance(mcc_macro, dict) else float("nan"),
            "InferTime_Mean":       round(it.get("mean", float("nan")), 2),
            "InferTime_Std":        round(it.get("std",  float("nan")), 2),
        }
        for name in label_names:
            pl = agg["per_label"][name]["f1"]
            key = f"F1_{name[:8]}"
            row[f"{key}_Mean"] = round(pl["mean"], 4)
            row[f"{key}_Std"]  = round(pl["std"],  4)
        rows.append(row)

    df = pd.DataFrame(rows)

    csv_path = os.path.join(save_dir, "cross_validation_summary.csv")
    df.to_csv(csv_path, index=False)
    print(f"[CV Summary] Saved → {csv_path}")

    # ── Human-readable TXT ────────────────────────────────────────────────
    lines = []
    lines.append("=" * 65)
    lines.append("5-Fold Cross-Validation Summary")
    lines.append("=" * 65)
    for model_name, agg in agg_results_dict.items():
        m   = agg["macro"]
        mi  = agg.get("micro", {})
        auc = agg.get("auc_macro", {"mean": float("nan"), "std": float("nan")})
        mcc_macro = m.get("mcc", {"mean": float("nan"), "std": float("nan")})
        it  = agg.get("inference_time_ms", {"mean": float("nan"), "std": float("nan")})
        hl  = agg.get("hamming_loss", {"mean": float("nan"), "std": float("nan")})
        lines.append(f"\n{model_name}")
        lines.append(f"  Hamming Loss       : "
                     f"{hl.get('mean', float('nan')):.3f} ± "
                     f"{hl.get('std',  float('nan')):.3f}")
        lines.append(f"  Hamming Accuracy   : "
                     f"{agg['hamming_acc']['mean']:.3f} ± "
                     f"{agg['hamming_acc']['std']:.3f}")
        lines.append(f"  Macro  Precision   : "
                     f"{m['precision']['mean']:.3f} ± "
                     f"{m['precision']['std']:.3f}")
        lines.append(f"  Macro  Recall      : "
                     f"{m['recall']['mean']:.3f} ± "
                     f"{m['recall']['std']:.3f}")
        lines.append(f"  Macro  F1          : "
                     f"{m['f1']['mean']:.3f} ± "
                     f"{m['f1']['std']:.3f}")
        lines.append(f"  Micro  Precision   : "
                     f"{mi.get('precision', {}).get('mean', float('nan')):.3f} ± "
                     f"{mi.get('precision', {}).get('std',  float('nan')):.3f}")
        lines.append(f"  Micro  Recall      : "
                     f"{mi.get('recall', {}).get('mean', float('nan')):.3f} ± "
                     f"{mi.get('recall', {}).get('std',  float('nan')):.3f}")
        lines.append(f"  Micro  F1          : "
                     f"{mi.get('f1', {}).get('mean', float('nan')):.3f} ± "
                     f"{mi.get('f1', {}).get('std',  float('nan')):.3f}")
        if not np.isnan(auc.get("mean", float("nan"))):
            lines.append(f"  ROC-AUC   : "
                         f"{auc['mean']:.3f} ± "
                         f"{auc['std']:.3f}")
        if isinstance(mcc_macro, dict) and not np.isnan(mcc_macro.get("mean", float("nan"))):
            lines.append(f"  MCC       : "
                         f"{mcc_macro['mean']:.3f} ± "
                         f"{mcc_macro['std']:.3f}")
        if isinstance(it, dict) and not np.isnan(it.get("mean", float("nan"))):
            lines.append(f"  Infer(ms) : "
                         f"{it['mean']:.2f} ± "
                         f"{it['std']:.2f} ms/sample")
        lines.append(f"  Per-label F1 / MCC:")
        for name in label_names:
            pl  = agg["per_label"][name]["f1"]
            plm = agg["per_label"][name].get("mcc", {})
            mcc_s = (f"  MCC={plm['mean']:.3f}±{plm['std']:.3f}"
                     if isinstance(plm, dict) and not np.isnan(plm.get("mean", float("nan")))
                     else "")
            lines.append(f"    {name:<28}: "
                         f"F1={pl['mean']:.3f}±{pl['std']:.3f}{mcc_s}")
    lines.append("\n" + "=" * 65)

    txt_path = os.path.join(save_dir, "cross_validation_summary.txt")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"[CV Summary] Saved → {txt_path}")

    # ── Console table ─────────────────────────────────────────────────────
    print("\n" + "=" * 95)
    print("5-Fold Cross-Validation Summary  (mean ± std)")
    print("=" * 95)
    hdr = (f"{'Model':<12}  {'Ham.Loss':>12}  {'Macro P':>12}  {'Macro R':>12}  "
           f"{'Macro F1':>12}  {'Micro P':>12}  {'Micro R':>12}  {'Micro F1':>12}")
    print(hdr)
    print("-" * 95)
    for model_name, agg in agg_results_dict.items():
        m  = agg["macro"]
        mi = agg.get("micro", {})
        hl = agg.get("hamming_loss", {"mean": float("nan"), "std": float("nan")})
        def _f(d, k):
            v = d.get(k, {})
            return f"{v.get('mean', float('nan')):.3f}±{v.get('std', float('nan')):.3f}" if isinstance(v, dict) else "  N/A  "
        print(
            f"{model_name:<12}  "
            f"{hl.get('mean', float('nan')):.3f} ± {hl.get('std', float('nan')):.3f}  "
            f"{_f(m, 'precision')}  {_f(m, 'recall')}  {_f(m, 'f1')}  "
            f"{_f(mi, 'precision')}  {_f(mi, 'recall')}  {_f(mi, 'f1')}"
        )
    print("=" * 95)

    return csv_path, txt_path


# ─── McNemar's Table ──────────────────────────────────────────────────────────

def save_mcnemar_table(mcnemar_results, save_dir=STATISTICS_DIR):
    """
    Save McNemar's test results as CSV and TXT.

    Args:
        mcnemar_results : list of dicts from run_mcnemar_tests()
        save_dir        : directory to write files

    Returns:
        (csv_path, txt_path)
    """
    os.makedirs(save_dir, exist_ok=True)

    df = pd.DataFrame(mcnemar_results)

    csv_path = os.path.join(save_dir, "mcnemar_results.csv")
    df.to_csv(csv_path, index=False)
    print(f"[McNemar]  Saved CSV → {csv_path}")

    lines = []
    lines.append("=" * 60)
    lines.append("McNemar's Test — Pairwise Model Comparison")
    lines.append("(exact binomial when n_discordant < 25)")
    lines.append("=" * 60)
    lines.append(f"{'Comparison':<32}  {'p-value':>9}  {'Significant?':>12}")
    lines.append("-" * 60)
    for r in mcnemar_results:
        comp    = f"{r['model_a']} vs {r['model_b']}"
        sig_str = "YES (p<0.05)" if r["significant"] else "no"
        lines.append(f"  {comp:<30}  {r['p_value']:>9.4f}  {sig_str:>12}")
    lines.append("-" * 60)
    lines.append("p < 0.05 → statistically significant difference")
    lines.append("=" * 60)

    txt_path = os.path.join(save_dir, "mcnemar_results.txt")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"[McNemar]  Saved TXT → {txt_path}")

    return csv_path, txt_path


# ═══════════════════════════════════════════════════════════════════════════════
# Advanced Multi-Model Interpretation Plots
# ═══════════════════════════════════════════════════════════════════════════════

_MODEL_COLORS = ["#2196F3", "#4CAF50", "#FF9800"]   # blue / green / orange

# Per-model curve styles: different color + linestyle + marker so lines are
# visually distinct even when they overlap at the same values.
_CURVE_STYLES = [
    {"color": "#2196F3", "ls": "-",  "marker": "o"},  # blue, solid, circle
    {"color": "#4CAF50", "ls": "--", "marker": "s"},  # green, dashed, square
    {"color": "#FF9800", "ls": "-.", "marker": "^"},  # orange, dash-dot, triangle
]


def _scalar(v):
    """Return a plain float from either a raw value or an agg dict {"mean":…}."""
    if isinstance(v, dict):
        v = v.get("mean", float("nan"))
    try:
        return float(v)
    except (TypeError, ValueError):
        return float("nan")


# ─── ROC Curves ───────────────────────────────────────────────────────────────

def plot_roc_curves(model_probs_dict, y_true, label_names=None, save_dir=PLOTS_DIR):
    """
    Per-label ROC curves with all models overlaid on the same axes.

    Args:
        model_probs_dict : {model_name: y_prob ndarray (N, L)}
        y_true           : (N, L) binary ground truth
        label_names      : list of label strings
        save_dir         : output directory
    """
    from sklearn.metrics import roc_curve, auc as sk_auc

    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    n = len(label_names)
    fig, axes = plt.subplots(1, n, figsize=(6 * n, 5))
    if n == 1:
        axes = [axes]

    for col, (label, ax) in enumerate(zip(label_names, axes)):
        yt = y_true[:, col]
        if yt.sum() == 0 or (1 - yt).sum() == 0:
            ax.text(0.5, 0.5, "Insufficient class\nvariety for ROC",
                    ha="center", va="center", fontsize=10,
                    transform=ax.transAxes)
            ax.set_title(label, fontsize=11)
            continue

        for i, ((model, y_prob), sty) in enumerate(
                zip(model_probs_dict.items(), _CURVE_STYLES)):
            fpr, tpr, _ = roc_curve(yt, y_prob[:, col])
            roc_auc = sk_auc(fpr, tpr)
            n_pts = max(len(fpr), 1)
            step  = max(1, n_pts // 8)
            start = i * max(1, step // max(len(_CURVE_STYLES), 1))
            ax.plot(fpr, tpr,
                    color=sty["color"], linestyle=sty["ls"],
                    marker=sty["marker"], markevery=(start, step), markersize=6,
                    lw=2.0, label=f"{model}  (AUC={roc_auc:.3f})")

        ax.plot([0, 1], [0, 1], "k--", lw=1.2, alpha=0.45, label="Chance")
        ax.set_xlim([-0.01, 1.01])
        ax.set_ylim([-0.01, 1.05])
        ax.set_xlabel("False Positive Rate", fontsize=10)
        ax.set_ylabel("True Positive Rate", fontsize=10)
        ax.set_title(label, fontsize=11, fontweight="bold")
        ax.legend(loc="lower right", fontsize=9)
        ax.grid(alpha=0.25)

    fig.suptitle("ROC Curves — All Models", fontsize=14, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "roc_curves.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved ROC curves → {fname}")


# ─── Precision-Recall Curves ──────────────────────────────────────────────────

def plot_pr_curves(model_probs_dict, y_true, label_names=None, save_dir=PLOTS_DIR):
    """
    Per-label Precision-Recall curves — crucial for imbalanced classes.

    Args:
        model_probs_dict : {model_name: y_prob ndarray (N, L)}
        y_true           : (N, L) binary ground truth
    """
    from sklearn.metrics import precision_recall_curve, average_precision_score

    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    n = len(label_names)
    fig, axes = plt.subplots(1, n, figsize=(6 * n, 5))
    if n == 1:
        axes = [axes]

    for col, (label, ax) in enumerate(zip(label_names, axes)):
        yt = y_true[:, col]
        prevalence = float(yt.mean())

        if yt.sum() == 0:
            ax.text(0.5, 0.5, "No positive samples",
                    ha="center", va="center", fontsize=10,
                    transform=ax.transAxes)
            ax.set_title(label, fontsize=11)
            continue

        for i, ((model, y_prob), sty) in enumerate(
                zip(model_probs_dict.items(), _CURVE_STYLES)):
            prec, rec, _ = precision_recall_curve(yt, y_prob[:, col])
            ap = average_precision_score(yt, y_prob[:, col])
            n_pts = max(len(rec), 1)
            step  = max(1, n_pts // 8)
            start = i * max(1, step // max(len(_CURVE_STYLES), 1))
            ax.plot(rec, prec,
                    color=sty["color"], linestyle=sty["ls"],
                    marker=sty["marker"], markevery=(start, step), markersize=6,
                    lw=2.0, label=f"{model}  (AP={ap:.3f})")

        ax.axhline(prevalence, color="gray", linestyle="--", lw=1.2,
                   label=f"No-skill ({prevalence:.2f})")
        ax.set_xlim([0, 1.01])
        ax.set_ylim([0, 1.05])
        ax.set_xlabel("Recall", fontsize=10)
        ax.set_ylabel("Precision", fontsize=10)
        ax.set_title(label, fontsize=11, fontweight="bold")
        ax.legend(loc="upper right", fontsize=9)
        ax.grid(alpha=0.25)

    fig.suptitle(
        "Precision-Recall Curves — All Models\n"
        "(dashed = no-skill baseline at class prevalence)",
        fontsize=13, fontweight="bold",
    )
    fig.tight_layout(rect=[0, 0, 1, 0.91])
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "pr_curves.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved PR curves → {fname}")


# ─── Per-label F1 / MCC Heatmap ──────────────────────────────────────────────

def plot_label_metric_heatmap(model_metrics_dict, label_names=None, save_dir=PLOTS_DIR):
    """
    Heatmap grid: rows = models, cols = labels, twin panels for F1 and MCC.
    Accepts both raw single-run metrics and aggregated CV metrics.

    Args:
        model_metrics_dict : {model_name: metrics_dict}
    """
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    models = list(model_metrics_dict.keys())
    short_labels = [n[:18] for n in label_names]

    def _grid(key):
        arr = np.zeros((len(models), len(label_names)))
        for i, m in enumerate(model_metrics_dict.values()):
            for j, lbl in enumerate(label_names):
                arr[i, j] = max(
                    _scalar(m["per_label"].get(lbl, {}).get(key, float("nan"))),
                    0.0,
                )
        return arr

    f1_data  = _grid("f1")
    mcc_data = _grid("mcc")
    # MCC can be negative; keep raw values for display, floor at -1
    mcc_raw  = np.array([
        [_scalar(m["per_label"].get(lbl, {}).get("mcc", float("nan")))
         for lbl in label_names]
        for m in model_metrics_dict.values()
    ])

    fig, axes = plt.subplots(
        1, 2,
        figsize=(max(10, 3.2 * len(label_names)), max(3, 1.5 * len(models))),
    )

    for ax, data, raw, title, cmap, vmin in zip(
        axes,
        [f1_data,  mcc_raw],
        [f1_data,  mcc_raw],
        ["F1-score", "MCC"],
        ["YlOrRd",  "RdYlGn"],
        [0,         -1],
    ):
        im = ax.imshow(data, cmap=cmap, vmin=vmin, vmax=1, aspect="auto")
        plt.colorbar(im, ax=ax, shrink=0.85)
        ax.set_xticks(range(len(label_names)))
        ax.set_xticklabels(short_labels, rotation=22, ha="right", fontsize=10)
        ax.set_yticks(range(len(models)))
        ax.set_yticklabels(models, fontsize=11)
        ax.set_title(title, fontsize=12, fontweight="bold", pad=10)

        for r in range(len(models)):
            for c in range(len(label_names)):
                v = float(raw[r, c])
                txt = f"{v:.2f}" if not np.isnan(v) else "N/A"
                dark = (title == "F1-score" and v > 0.55) or (title == "MCC" and v > 0.45)
                ax.text(c, r, txt, ha="center", va="center",
                        fontsize=11, fontweight="bold",
                        color="white" if dark else "black")

    fig.suptitle("Per-Label Performance Heatmap — Model Comparison",
                 fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "label_metric_heatmap.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved label metric heatmap → {fname}")


# ─── Radar / Spider Chart ─────────────────────────────────────────────────────

def plot_radar_chart(model_metrics_dict, save_dir=PLOTS_DIR):
    """
    Spider / radar chart comparing all models across six summary metrics.
    MCC is rescaled from [-1, 1] to [0, 1] for display uniformity.

    Args:
        model_metrics_dict : {model_name: metrics_dict}
                             Values may be raw scalars or aggregated dicts.
    """
    axis_labels = [
        "Accuracy\n(Hamming)", "Macro\nPrecision", "Macro\nRecall",
        "Macro F1", "ROC-AUC", "MCC*\n(adj.)",
    ]

    def _extract(metrics):
        mcc_raw = _scalar(metrics.get("macro", {}).get("mcc", float("nan")))
        mcc_adj = (mcc_raw + 1) / 2 if not np.isnan(mcc_raw) else 0.0
        return [
            max(0.0, _scalar(metrics.get("hamming_acc",              float("nan")))),
            max(0.0, _scalar(metrics.get("macro", {}).get("precision", float("nan")))),
            max(0.0, _scalar(metrics.get("macro", {}).get("recall",    float("nan")))),
            max(0.0, _scalar(metrics.get("macro", {}).get("f1",        float("nan")))),
            max(0.0, _scalar(metrics.get("auc_macro",                 float("nan")))),
            max(0.0, mcc_adj),
        ]

    n_axes = len(axis_labels)
    angles = np.linspace(0, 2 * np.pi, n_axes, endpoint=False).tolist()
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(7, 7), subplot_kw={"polar": True})

    for (model, metrics), color in zip(model_metrics_dict.items(), _MODEL_COLORS):
        vals = _extract(metrics)
        vals += vals[:1]
        ax.plot(angles, vals, "o-", lw=2.5, color=color,
                label=model, markersize=6)
        ax.fill(angles, vals, alpha=0.09, color=color)

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(axis_labels, fontsize=10)
    ax.set_ylim(0, 1)
    ax.set_yticks([0.25, 0.50, 0.75, 1.00])
    ax.set_yticklabels(["0.25", "0.50", "0.75", "1.00"],
                       fontsize=8, color="gray")
    ax.grid(color="gray", alpha=0.3)
    ax.set_title(
        "Model Performance — Radar Chart\n"
        "(*MCC rescaled to [0,1]: adj = (MCC+1)/2)",
        fontsize=12, fontweight="bold", pad=22,
    )
    ax.legend(loc="upper right", bbox_to_anchor=(1.32, 1.18), fontsize=11)

    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "radar_chart.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved radar chart → {fname}")


# ─── Predicted Probability Distributions ─────────────────────────────────────

def plot_probability_distributions(model_probs_dict, y_true,
                                   label_names=None, save_dir=PLOTS_DIR):
    """
    Histograms of predicted probabilities split by true class (positive / negative).
    Reveals how confidently each model separates the two classes per label.

    Args:
        model_probs_dict : {model_name: y_prob ndarray (N, L)}
        y_true           : (N, L) binary ground truth
    """
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    n_models = len(model_probs_dict)
    n_labels = len(label_names)
    dark_colors = ["#1565C0", "#2E7D32", "#BF360C"]
    light_colors = ["#90CAF9", "#A5D6A7", "#FFCCBC"]

    fig, axes = plt.subplots(
        n_labels, n_models,
        figsize=(5 * n_models, 3.8 * n_labels),
        squeeze=False,
    )

    bins = np.linspace(0, 1, 21)

    for j, (model, y_prob) in enumerate(model_probs_dict.items()):
        for i, label in enumerate(label_names):
            ax  = axes[i][j]
            yt  = y_true[:, i]
            yp  = y_prob[:, i]
            neg = yp[yt == 0]
            pos = yp[yt == 1]

            if len(neg) > 0:
                ax.hist(neg, bins=bins, alpha=0.65, color=light_colors[j],
                        label=f"True Neg (n={len(neg)})", edgecolor="white")
            if len(pos) > 0:
                ax.hist(pos, bins=bins, alpha=0.88, color=dark_colors[j],
                        label=f"True Pos (n={len(pos)})", edgecolor="white")

            ax.axvline(0.5, color="crimson", linestyle="--",
                       lw=1.5, alpha=0.8, label="Threshold=0.5")
            ax.set_xlim(0, 1)
            ax.set_xlabel("Predicted Probability", fontsize=9)
            ax.set_ylabel("Count", fontsize=9)
            ax.set_title(f"{model} — {label[:22]}", fontsize=10, fontweight="bold")
            ax.legend(fontsize=8)
            ax.grid(alpha=0.22)

    fig.suptitle(
        "Predicted Probability Distributions by True Class",
        fontsize=13, fontweight="bold",
    )
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "probability_distributions.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved probability distributions → {fname}")


# ─── Per-label CM Comparison (all models side-by-side) ───────────────────────

def plot_comparison_confusion_matrices(model_cms_dict, label_names=None,
                                       save_dir=PLOTS_DIR):
    """
    For each label: one row of confusion matrices, one column per model.
    Enables direct model-to-model comparison for each deviation type.

    Args:
        model_cms_dict : {model_name: {label_name: 2×2 ndarray}}
        label_names    : list of label strings
    """
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    model_names = list(model_cms_dict.keys())
    n_models    = len(model_names)
    n_labels    = len(label_names)

    fig, axes = plt.subplots(
        n_labels, n_models,
        figsize=(4.5 * n_models, 4.2 * n_labels),
        squeeze=False,
    )

    for row, label in enumerate(label_names):
        for col, model in enumerate(model_names):
            ax = axes[row][col]
            cm = model_cms_dict[model].get(label, np.zeros((2, 2), dtype=int))
            support = int(cm.sum())

            if support == 0:
                ax.text(0.5, 0.5, "No samples",
                        ha="center", va="center", transform=ax.transAxes)
                ax.axis("off")
            else:
                row_sums = cm.sum(axis=1, keepdims=True)
                row_sums[row_sums == 0] = 1
                cm_pct = cm.astype(float) / row_sums

                sns.heatmap(
                    cm_pct, annot=True, fmt=".2f", cmap="Blues",
                    xticklabels=["Normal", "Deviation"],
                    yticklabels=["Normal", "Deviation"],
                    ax=ax, cbar=False, vmin=0, vmax=1,
                    annot_kws={"size": 13},
                )
                for r in range(2):
                    for c in range(2):
                        ax.text(c + 0.5, r + 0.76, f"(n={cm[r, c]})",
                                ha="center", va="center",
                                fontsize=9, color="dimgray")

            ax.set_title(model, fontsize=12, fontweight="bold")
            if col == 0:
                ax.set_ylabel(label, fontsize=11)
            else:
                ax.set_ylabel("")
            ax.set_xlabel("Predicted", fontsize=9)

    fig.suptitle(
        "Confusion Matrix Comparison — All Models × All Labels\n"
        "(row-normalised; raw counts in parentheses)",
        fontsize=13, fontweight="bold",
    )
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "confusion_matrix_comparison.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved CM comparison → {fname}")


# ─── Simple CM Summary: Sensitivity & Specificity bars ───────────────────────

def plot_cm_summary(model_cms_dict, label_names=None, save_dir=PLOTS_DIR):
    """
    Compact confusion-matrix summary: two grouped bar charts showing
    Sensitivity (TPR — how well deviations are caught) and
    Specificity (TNR — how well normal gait is recognised).

    Much more readable than showing all 9 individual matrices.

    Args:
        model_cms_dict : {model_name: {label_name: 2×2 ndarray}}
        label_names    : list of label strings
        save_dir       : output directory
    """
    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    model_names = list(model_cms_dict.keys())
    n_models    = len(model_names)
    n_labels    = len(label_names)
    x           = np.arange(n_labels)
    width       = 0.22
    short        = [n[:18] for n in label_names]

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    panels = [
        ("Sensitivity (TPR)\n— how well deviations are detected", "TPR",
         lambda cm: cm[1, 1] / max(cm[1, :].sum(), 1)),
        ("Specificity (TNR)\n— how well normal gait is recognised", "TNR",
         lambda cm: cm[0, 0] / max(cm[0, :].sum(), 1)),
    ]

    for ax, (title, ylabel, rate_fn) in zip(axes, panels):
        for i, (model, color) in enumerate(zip(model_names, _MODEL_COLORS)):
            vals = [
                rate_fn(model_cms_dict[model].get(lbl, np.zeros((2, 2), int)))
                for lbl in label_names
            ]
            offset = (i - n_models / 2 + 0.5) * width
            bars = ax.bar(x + offset, vals, width,
                          label=model, color=color, alpha=0.85, edgecolor="white")
            for bar, v in zip(bars, vals):
                ax.text(bar.get_x() + bar.get_width() / 2,
                        bar.get_height() + 0.012,
                        f"{v:.2f}", ha="center", va="bottom", fontsize=9.5)

        ax.set_xticks(x)
        ax.set_xticklabels(short, fontsize=10)
        ax.set_ylim(0, 1.18)
        ax.set_ylabel(ylabel, fontsize=11)
        ax.set_title(title, fontsize=11, fontweight="bold")
        ax.legend(loc="upper right", fontsize=10)
        ax.grid(axis="y", alpha=0.3)
        ax.yaxis.set_major_formatter(ticker.FormatStrFormatter("%.2f"))

    fig.suptitle("Confusion Matrix Summary — All Models",
                 fontsize=13, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "confusion_matrix_summary.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved CM summary → {fname}")


# ─── McNemar's Test Visual Table ──────────────────────────────────────────────

def plot_mcnemar_table(mcnemar_results, save_dir=PLOTS_DIR):
    """
    Simple plain-number table of McNemar's pairwise test results.
    Columns: Comparison | b | c | p-value | Significant

    Args:
        mcnemar_results : list of dicts from run_mcnemar_tests()
        save_dir        : output directory
    """
    if not mcnemar_results:
        return

    col_labels = ["Comparison", "1st wrong\n2nd correct", "1st correct\n2nd wrong", "p-value", "Significant?"]
    rows = []
    for r in mcnemar_results:
        sig = "Yes *" if r["significant"] else "No"
        rows.append([
            f"{r['model_a']} vs {r['model_b']}",
            str(r["b"]),
            str(r["c"]),
            f"{r['p_value']:.4f}",
            sig,
        ])

    n_rows = len(rows)
    fig, ax = plt.subplots(figsize=(8, 1.0 + 0.55 * n_rows))
    ax.axis("off")

    tbl = ax.table(
        cellText=rows,
        colLabels=col_labels,
        cellLoc="center",
        loc="center",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(11)
    tbl.scale(1, 1.8)

    # Header row styling
    for col in range(len(col_labels)):
        cell = tbl[0, col]
        cell.set_facecolor("#37474F")
        cell.set_text_props(color="white", fontweight="bold")

    # Data rows — alternate light grey / white
    for row in range(1, n_rows + 1):
        bg = "#F5F5F5" if row % 2 == 0 else "white"
        for col in range(len(col_labels)):
            tbl[row, col].set_facecolor(bg)
        # Bold the significance column
        tbl[row, 4].set_text_props(fontweight="bold")

    ax.set_title(
        "McNemar's Test — Pairwise Model Comparison\n"
        "Counts reflect samples where only one model was correct  |  "
        "1st and 2nd refer to the order listed in the Comparison column\n"
        "p < 0.05 indicates a statistically significant difference in error patterns",
        fontsize=10, pad=12,
    )

    fig.tight_layout()
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "mcnemar_table.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved McNemar table → {fname}")


# ── Curve-padding helper ──────────────────────────────────────────────────────

def _pad_curves(curves, max_len):
    """Return (n_curves, max_len) float array padded with NaN."""
    arr = np.full((len(curves), max_len), np.nan)
    for i, c in enumerate(curves):
        n = min(len(c), max_len)
        arr[i, :n] = c[:n]
    return arr


# ─── Individual model training curves (all folds + mean) ─────────────────────

def plot_training_curves_individual(fold_histories, model_name,
                                    save_dir=PLOTS_DIR):
    """
    Per-model training curves: Loss, Accuracy, LR subplots.
    Thin translucent lines = individual folds; thick = mean across folds;
    dotted vertical lines = best-checkpoint epoch per fold.
    Gracefully skips Accuracy / LR panels when those keys are absent.

    Args:
        fold_histories : list of history dicts (from train_one_fold / train.py).
                         Expected keys: train_loss, val_loss; optionally
                         train_acc, val_acc, lrs, best_epoch.
        model_name     : display name, e.g. "ST-GCN"
        save_dir       : output directory
    """
    has_acc = any("val_acc" in h for h in fold_histories)
    has_lr  = any("lrs"     in h for h in fold_histories)

    n_panels = 1 + int(has_acc) + int(has_lr)
    fig, axes = plt.subplots(1, n_panels, figsize=(6 * n_panels, 5))
    axes = np.atleast_1d(axes)

    fold_colors = plt.cm.tab10(np.linspace(0, 0.9, max(len(fold_histories), 1)))
    best_epochs = [h.get("best_epoch") for h in fold_histories]

    def _draw(ax, curves_a, label_a, color_a,
              curves_b=None, label_b=None, color_b=None,
              title="", ylabel="", ylim=None):
        all_c = [c for c in (curves_a + (curves_b or [])) if c]
        max_len = max((len(c) for c in all_c), default=0)
        if max_len == 0:
            ax.text(0.5, 0.5, "No data", ha="center", va="center",
                    transform=ax.transAxes)
            ax.set_title(f"{model_name} — {title}", fontsize=12)
            return

        for fi, fc in enumerate(fold_colors[:len(fold_histories)]):
            ca = curves_a[fi] if fi < len(curves_a) else []
            if ca:
                ax.plot(range(1, len(ca) + 1), ca,
                        color=fc, alpha=0.28, lw=1.0)
            if curves_b is not None:
                cb = curves_b[fi] if fi < len(curves_b) else []
                if cb:
                    ax.plot(range(1, len(cb) + 1), cb,
                            color=fc, alpha=0.28, lw=1.0, linestyle="--")
            be = best_epochs[fi] if fi < len(best_epochs) else None
            if be:
                ax.axvline(be, color=fc, alpha=0.30, linestyle=":", lw=0.9)

        valid_a = [c for c in curves_a if c]
        if valid_a:
            ml = max(len(c) for c in valid_a)
            arr = _pad_curves(valid_a, ml)
            ax.plot(range(1, ml + 1), np.nanmean(arr, axis=0),
                    color=color_a, lw=2.5, label=label_a, zorder=5)

        if curves_b is not None:
            valid_b = [c for c in curves_b if c]
            if valid_b:
                ml = max(len(c) for c in valid_b)
                arr = _pad_curves(valid_b, ml)
                ax.plot(range(1, ml + 1), np.nanmean(arr, axis=0),
                        color=color_b, lw=2.5, linestyle="--",
                        label=label_b, zorder=5)

        ax.set_title(f"{model_name} — {title}", fontsize=12)
        ax.set_xlabel("Epoch")
        ax.set_ylabel(ylabel)
        if ylim:
            ax.set_ylim(*ylim)
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    panel = 0
    _draw(axes[panel],
          [h.get("train_loss", []) for h in fold_histories],
          "Train Loss (mean)", "steelblue",
          [h.get("val_loss",   []) for h in fold_histories],
          "Val Loss (mean)",   "tomato",
          title="Loss", ylabel="BCE Loss")
    panel += 1

    if has_acc:
        _draw(axes[panel],
              [h.get("train_acc", []) for h in fold_histories],
              "Train Acc (mean)", "steelblue",
              [h.get("val_acc",   []) for h in fold_histories],
              "Val Acc (mean)",   "tomato",
              title="Accuracy", ylabel="Accuracy", ylim=(0, 1.05))
        panel += 1

    if has_lr:
        _draw(axes[panel],
              [h.get("lrs", []) for h in fold_histories],
              "LR (mean)", "dimgray",
              title="Learning Rate", ylabel="LR")
        axes[panel].ticklabel_format(axis="y", style="sci", scilimits=(-4, -3))
        panel += 1

    from matplotlib.lines import Line2D
    fig.legend(
        handles=[
            Line2D([0], [0], color="gray", alpha=0.4, lw=1.0,
                   label="Individual folds  (solid=train / dashed=val)"),
            Line2D([0], [0], color="black", lw=2.5, label="Mean"),
            Line2D([0], [0], color="gray", alpha=0.4, lw=0.9, linestyle=":",
                   label="Best checkpoint epoch"),
        ],
        loc="upper center", ncol=3, fontsize=8,
        bbox_to_anchor=(0.5, 1.06),
    )

    slug = model_name.lower().replace(" ", "_").replace("-", "")
    fig.suptitle(f"{model_name} — Training Curves",
                 fontsize=14, fontweight="bold", y=1.09)
    fig.tight_layout()
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, f"{slug}_training_curves.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved training curves → {fname}")


# ─── Combined training curves — all models, mean ± std ───────────────────────

def plot_training_curves_combined(all_fold_histories, save_dir=PLOTS_DIR):
    """
    One figure with mean ± std shaded bands per model.
    Subplots: Train Loss, Val Loss, Val Accuracy (if any), LR (if any).

    Args:
        all_fold_histories : {model_display_name: [fold_history_dict, ...]}
        save_dir           : output directory
    """
    all_hists = list(all_fold_histories.values())
    has_acc   = any(any("val_acc" in h for h in hists) for hists in all_hists)
    has_lr    = any(any("lrs"     in h for h in hists) for hists in all_hists)

    panel_keys    = ["train_loss", "val_loss"]
    panel_titles  = ["Train Loss", "Val Loss"]
    panel_ylabels = ["BCE Loss",   "BCE Loss"]
    if has_acc:
        panel_keys.append("val_acc");    panel_titles.append("Val Accuracy")
        panel_ylabels.append("Accuracy")
    if has_lr:
        panel_keys.append("lrs");        panel_titles.append("Learning Rate")
        panel_ylabels.append("LR")

    n_panels = len(panel_keys)
    fig, axes = plt.subplots(1, n_panels, figsize=(6 * n_panels, 5))
    axes = np.atleast_1d(axes)

    for (model_name, fold_hists), color in zip(
            all_fold_histories.items(), _MODEL_COLORS):
        for ax, key in zip(axes, panel_keys):
            curves = [h.get(key, []) for h in fold_hists]
            curves = [c for c in curves if c]
            if not curves:
                continue
            max_len = max(len(c) for c in curves)
            arr     = _pad_curves(curves, max_len)
            ep      = np.arange(1, max_len + 1)
            mean    = np.nanmean(arr, axis=0)
            std     = np.nanstd(arr,  axis=0)
            ax.plot(ep, mean, color=color, lw=2.0, label=model_name)
            ax.fill_between(ep, mean - std, mean + std,
                            color=color, alpha=0.15)

    for ax, title, ylabel, key in zip(
            axes, panel_titles, panel_ylabels, panel_keys):
        ax.set_title(title, fontsize=12, fontweight="bold")
        ax.set_xlabel("Epoch")
        ax.set_ylabel(ylabel)
        if key == "val_acc":
            ax.set_ylim(0, 1.05)
        if key == "lrs":
            ax.ticklabel_format(axis="y", style="sci", scilimits=(-4, -3))
        ax.legend(fontsize=9)
        ax.grid(True, alpha=0.3)
        ax.xaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    fig.suptitle(
        "All Models — Training Curves  (mean ± std across folds)",
        fontsize=13, fontweight="bold",
    )
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    os.makedirs(save_dir, exist_ok=True)
    fname = os.path.join(save_dir, "all_models_training_curves.png")
    fig.savefig(fname, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[Plot] Saved combined training curves → {fname}")


# ─── Per-model ROC curves (one figure per model) ─────────────────────────────

def plot_roc_per_model(model_probs_dict, y_true,
                       label_names=None, save_dir=PLOTS_DIR):
    """
    Saves one ROC figure per model; each subplot = one label.
    Companion to plot_roc_curves() which overlays all models on shared axes.
    Works for binary (L=1) and multi-label (L>1).

    Args:
        model_probs_dict : {model_name: y_prob ndarray (N, L)}
        y_true           : (N, L) binary ground truth
        label_names      : list of label strings
        save_dir         : output directory
    """
    from sklearn.metrics import roc_curve, auc as sk_auc

    if label_names is None:
        label_names = ACTIVE_LABEL_NAMES

    n = len(label_names)
    os.makedirs(save_dir, exist_ok=True)

    for (model_name, y_prob), sty in zip(model_probs_dict.items(), _CURVE_STYLES):
        fig, axes = plt.subplots(1, n, figsize=(6 * n, 5))
        if n == 1:
            axes = [axes]

        for col, (label, ax) in enumerate(zip(label_names, axes)):
            yt = y_true[:, col]
            if yt.sum() == 0 or (1 - yt).sum() == 0:
                ax.text(0.5, 0.5, "Insufficient class\nvariety for ROC",
                        ha="center", va="center", fontsize=10,
                        transform=ax.transAxes)
                ax.set_title(label, fontsize=11)
                ax.axis("off")
                continue

            fpr, tpr, _ = roc_curve(yt, y_prob[:, col])
            roc_auc = sk_auc(fpr, tpr)
            n_pts = max(len(fpr), 1)
            step  = max(1, n_pts // 8)
            ax.plot(fpr, tpr,
                    color=sty["color"], linestyle=sty["ls"],
                    marker=sty["marker"], markevery=(0, step), markersize=6,
                    lw=2.0, label=f"AUC = {roc_auc:.3f}")
            ax.plot([0, 1], [0, 1], "k--", lw=1.2, alpha=0.45, label="Chance")

            ax.set_xlim([-0.01, 1.01])
            ax.set_ylim([-0.01, 1.05])
            ax.set_xlabel("False Positive Rate", fontsize=10)
            ax.set_ylabel("True Positive Rate", fontsize=10)
            ax.set_title(label, fontsize=11, fontweight="bold")
            ax.legend(loc="lower right", fontsize=9)
            ax.grid(alpha=0.25)

        fig.suptitle(f"ROC Curves — {model_name}",
                     fontsize=14, fontweight="bold")
        fig.tight_layout(rect=[0, 0, 1, 0.94])
        slug = model_name.lower().replace(" ", "_").replace("-", "")
        fname = os.path.join(save_dir, f"roc_{slug}.png")
        fig.savefig(fname, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"[Plot] Saved per-model ROC → {fname}")
