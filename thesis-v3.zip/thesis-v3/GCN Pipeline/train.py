"""
train.py — Train a single GCN model (ST-GCN, AGCN, or CTR-GCN).

Usage:
    python train.py --model stgcn  --data_dir data/normalized --csv data/labels.csv
    python train.py --model agcn   --data_dir data/normalized --csv data/labels.csv
    python train.py --model ctrgcn --data_dir data/normalized --csv data/labels.csv

Augmentation flags (all disabled by default):
    --aug_noise     Enable Gaussian noise on x,y coordinates
    --aug_crop      Enable random temporal frame cropping
    --aug_mirror    Enable left-right skeleton mirroring
    --aug_sigma     Gaussian noise std dev (default 0.01)
    --aug_crop_pct  Max temporal crop fraction (default 0.10)
"""

import os
import sys
import json
import time
import argparse
import random
import numpy as np
import torch
import torch.nn as nn
from torch.optim import Adam
from torch.optim.lr_scheduler import CosineAnnealingLR

from data.dataset    import (get_dataloaders, ACTIVE_LABEL_NAMES,
                             BINARY_LABEL_NAMES, BINARY_CSV_COLUMNS)
from models          import MODEL_REGISTRY
from utils.metrics   import compute_metrics, print_metrics, logits_to_pred
from utils.visualize import plot_loss_curves, plot_training_curves_individual


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark     = False


def parse_args():
    p = argparse.ArgumentParser(description="Train a single GCN model")

    p.add_argument("--model",    choices=["stgcn", "agcn", "ctrgcn"], required=True)
    p.add_argument("--data_dir", type=str, required=True,
                   help="Path to normalized/ folder containing .npy files")
    p.add_argument("--csv",      type=str, required=True,
                   help="Path to labels CSV file")
    p.add_argument("--max_frames",  type=int, default=300,
                   help="Fixed sequence length (pad/truncate). Default: 300")
    p.add_argument("--seed",        type=int, default=42)
    p.add_argument("--epochs",      type=int,   default=100)
    p.add_argument("--batch_size",  type=int,   default=8)
    p.add_argument("--lr",          type=float, default=1e-3)
    p.add_argument("--weight_decay",type=float, default=1e-4)
    p.add_argument("--dropout",     type=float, default=0.5)
    p.add_argument("--patience",    type=int,   default=20,
                   help="Early stopping patience (epochs without val improvement)")
    p.add_argument("--aug_noise",    action="store_true",
                   help="Enable Gaussian noise on x,y coordinates (training only)")
    p.add_argument("--aug_crop",     action="store_true",
                   help="Enable random temporal frame cropping (training only)")
    p.add_argument("--aug_mirror",   action="store_true",
                   help="Enable left-right skeleton mirroring (training only)")
    p.add_argument("--aug_sigma",    type=float, default=0.01,
                   help="Gaussian noise std dev (default 0.01)")
    p.add_argument("--aug_crop_pct", type=float, default=0.10,
                   help="Max temporal crop fraction (default 0.10)")
    p.add_argument("--binary", action="store_true",
                   help="Binary mode: good posture vs bad posture (uses binary_labels.csv)")
    p.add_argument("--out_dir", type=str, default="results",
                   help="Root directory for saving checkpoints and logs")

    return p.parse_args()


def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    total_loss = 0.0
    all_preds, all_labels = [], []

    for batch_x, batch_y, _ in loader:
        batch_x = batch_x.to(device, non_blocking=True)
        batch_y = batch_y.to(device, non_blocking=True)

        optimizer.zero_grad()
        logits = model(batch_x)
        loss   = criterion(logits, batch_y)
        loss.backward()

        nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

        optimizer.step()
        total_loss += loss.item() * batch_x.size(0)
        preds = (torch.sigmoid(logits) > 0.5).float()
        all_preds.append(preds.detach().cpu().numpy())
        all_labels.append(batch_y.detach().cpu().numpy())

    all_preds  = np.concatenate(all_preds,  axis=0)
    all_labels = np.concatenate(all_labels, axis=0)
    train_acc  = float((all_preds == all_labels).mean())
    return total_loss / len(loader.dataset), train_acc


@torch.no_grad()
def evaluate(model, loader, criterion, device, label_names=None):
    model.eval()
    total_loss = 0.0
    all_logits, all_labels = [], []

    for batch_x, batch_y, _ in loader:
        batch_x = batch_x.to(device, non_blocking=True)
        batch_y = batch_y.to(device, non_blocking=True)

        logits = model(batch_x)
        loss   = criterion(logits, batch_y)

        total_loss += loss.item() * batch_x.size(0)
        all_logits.append(logits.cpu().numpy())
        all_labels.append(batch_y.cpu().numpy())

    avg_loss   = total_loss / len(loader.dataset)
    all_logits = np.concatenate(all_logits, axis=0)
    all_labels = np.concatenate(all_labels, axis=0)

    y_pred, y_prob = logits_to_pred(all_logits)
    metrics = compute_metrics(all_labels, y_pred, y_prob, label_names)

    return avg_loss, metrics, all_logits, all_labels


def main():
    args = parse_args()
    set_seed(args.seed)

    ckpt_dir = os.path.join(args.out_dir, "checkpoints", args.model)
    os.makedirs(ckpt_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\n[Device] Using: {device}")

    any_aug = args.aug_noise or args.aug_crop or args.aug_mirror
    aug_config = {}
    if any_aug:
        aug_config = {
            "use_noise":  args.aug_noise,
            "use_crop":   args.aug_crop,
            "use_mirror": args.aug_mirror,
        }
        if args.aug_noise or args.aug_crop:
            import utils.augmentations as _aug
            _aug.GAUSSIAN_SIGMA    = args.aug_sigma
            _aug.TEMPORAL_CROP_PCT = args.aug_crop_pct

        print(f"\n[Augmentation] noise={args.aug_noise}  "
              f"crop={args.aug_crop}  mirror={args.aug_mirror}")
    else:
        print("\n[Augmentation] Disabled (use --aug_noise / --aug_crop / --aug_mirror)")

    if args.binary:
        label_names  = BINARY_LABEL_NAMES
        label_cols   = BINARY_CSV_COLUMNS
        strat_col    = "bad_posture"
        print("[Mode] Binary classification: Good Posture vs Bad Posture")
    else:
        label_names  = ACTIVE_LABEL_NAMES
        label_cols   = None
        strat_col    = "heelstrike"

    train_loader, val_loader, test_loader, pos_weights = get_dataloaders(
        data_dir      = args.data_dir,
        csv_path      = args.csv,
        max_frames    = args.max_frames,
        batch_size    = args.batch_size,
        seed          = args.seed,
        augment       = any_aug,
        aug_config    = aug_config if any_aug else None,
        label_columns = label_cols,
        strat_column  = strat_col,
    )
    pos_weights = pos_weights.to(device)
    num_classes = len(label_names)

    ModelClass = MODEL_REGISTRY[args.model]
    model = ModelClass(num_classes=num_classes, dropout=args.dropout).to(device)
    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"\n[Model] {args.model.upper()}  |  {n_params:,} trainable parameters")

    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weights)
    optimizer = Adam(model.parameters(), lr=args.lr,
                     weight_decay=args.weight_decay)
    scheduler = CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=1e-6)

    train_losses, val_losses = [], []
    train_accs, val_accs, val_f1s, lrs = [], [], [], []
    best_val_loss  = float("inf")
    best_val_f1    = 0.0
    best_epoch     = 1
    patience_count = 0
    best_ckpt_path = os.path.join(ckpt_dir, "best_model.pt")

    print(f"\n[Train] Starting training for {args.epochs} epochs "
          f"(patience={args.patience})\n")
    print(f"{'Epoch':>5}  {'Train Loss':>11}  {'Val Loss':>9}  "
          f"{'Val MacroF1':>11}  {'LR':>8}")
    print("-" * 55)

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()

        train_loss, train_acc = train_one_epoch(model, train_loader, criterion,
                                                optimizer, device)
        val_loss, val_metrics, _, _ = evaluate(model, val_loader, criterion, device, label_names)

        scheduler.step()
        current_lr = optimizer.param_groups[0]["lr"]

        train_losses.append(train_loss)
        val_losses.append(val_loss)
        train_accs.append(train_acc)
        val_accs.append(float(val_metrics.get("hamming_acc", float("nan"))))
        val_f1  = val_metrics["macro"]["f1"]
        val_f1s.append(float(val_f1))
        lrs.append(current_lr)

        elapsed = time.time() - t0

        print(f"{epoch:>5}  {train_loss:>11.5f}  {val_loss:>9.5f}  "
              f"{val_f1:>11.4f}  {current_lr:>8.2e}  ({elapsed:.1f}s)")

        if val_loss < best_val_loss:
            best_val_loss  = val_loss
            best_val_f1    = val_f1
            best_epoch     = epoch
            patience_count = 0
            torch.save({
                "epoch":                epoch,
                "model_state_dict":     model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "val_loss":             val_loss,
                "val_f1":               val_f1,
                "args":                 vars(args),
            }, best_ckpt_path)
        else:
            patience_count += 1

        if patience_count >= args.patience:
            print(f"\n[EarlyStopping] No improvement for {args.patience} epochs. "
                  f"Stopping at epoch {epoch}.")
            break

    print(f"\n[Best] Val Loss={best_val_loss:.5f}  Val MacroF1={best_val_f1:.4f}")
    print(f"[Checkpoint] Saved → {best_ckpt_path}")

    history = {
        "train_loss": train_losses,
        "val_loss":   val_losses,
        "train_acc":  train_accs,
        "val_acc":    val_accs,
        "val_f1":     val_f1s,
        "lrs":        lrs,
        "best_epoch": best_epoch,
    }
    plots_dir = os.path.join(args.out_dir, "plots")
    plot_loss_curves(train_losses, val_losses, args.model.upper(),
                     save_dir=plots_dir)
    plot_training_curves_individual([history], args.model.upper(),
                                    save_dir=plots_dir)

    hist_path = os.path.join(ckpt_dir, "history.json")
    with open(hist_path, "w") as f:
        json.dump(history, f, indent=2)
    print(f"[History] Saved → {hist_path}")

    print(f"\n[Done] Run evaluation with:")
    print(f"  python evaluate.py --model {args.model} "
          f"--data_dir {args.data_dir} --csv {args.csv}")


if __name__ == "__main__":
    main()
