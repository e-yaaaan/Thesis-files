"""AGCN: Adaptive Graph Convolutional Network."""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from models.stgcn import build_adjacency, COCO_PAIRS, NUM_NODES


class AdaptiveGraphConv(nn.Module):
    """Spatial graph convolution with adaptive adjacency."""

    def __init__(self, in_channels, out_channels, num_nodes=NUM_NODES,
                 num_partitions=3):
        super().__init__()
        self.num_partitions = num_partitions
        self.out_channels   = out_channels

        A_base = self._build_partitioned_adj(num_nodes)
        self.register_buffer("A_base", A_base)

        self.B = nn.Parameter(
            torch.zeros(num_partitions, num_nodes, num_nodes)
        )

        self.theta = nn.Conv2d(in_channels, out_channels // num_partitions,
                               kernel_size=1)
        self.phi   = nn.Conv2d(in_channels, out_channels // num_partitions,
                               kernel_size=1)

        self.W = nn.ModuleList([
            nn.Conv2d(in_channels, out_channels, kernel_size=1)
            for _ in range(num_partitions)
        ])

    @staticmethod
    def _build_partitioned_adj(num_nodes):
        """Build three-partition adjacency matrix."""
        A = build_adjacency(num_nodes).unsqueeze(0)       # (1, V, V)
        eye = torch.eye(num_nodes).unsqueeze(0)           # (1, V, V)
        # 3 partitions: A, identity, A - identity
        A_diff = A - eye
        return torch.cat([eye, A_diff.clamp(min=0), A], dim=0)  # (3, V, V)

    def forward(self, x):
        N, C, T, V = x.shape

        theta = self.theta(x)
        phi   = self.phi(x).permute(0, 1, 3, 2)
        theta_mean = theta.mean(dim=2)
        phi_mean   = phi.mean(dim=3)
        C_adapt = F.softmax(
            torch.bmm(theta_mean.permute(0, 2, 1), phi_mean),
            dim=-1
        )

        out = 0
        for k in range(self.num_partitions):
            A_k = self.A_base[k] + self.B[k] + C_adapt
            if A_k.dim() == 2:
                x_k = torch.einsum("nctv,vw->nctw", x, A_k)
            else:
                x_k = torch.einsum("nctv,nvw->nctw", x, A_k)
            out = out + self.W[k](x_k)

        return out


class AGCNBlock(nn.Module):
    """One AGCN block: adaptive graph conv + temporal conv + residual."""

    def __init__(self, in_channels, out_channels, num_nodes=NUM_NODES,
                 stride=1, residual=True, dropout=0.0):
        super().__init__()

        self.agc = AdaptiveGraphConv(in_channels, out_channels, num_nodes)
        self.bn_agc = nn.BatchNorm2d(out_channels)

        self.tcn = nn.Sequential(
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels,
                      kernel_size=(9, 1), padding=(4, 0), stride=(stride, 1)),
            nn.BatchNorm2d(out_channels),
            nn.Dropout(dropout, inplace=True),
        )

        if residual:
            if in_channels == out_channels and stride == 1:
                self.residual = nn.Identity()
            else:
                self.residual = nn.Sequential(
                    nn.Conv2d(in_channels, out_channels,
                              kernel_size=1, stride=(stride, 1)),
                    nn.BatchNorm2d(out_channels),
                )
        else:
            self.residual = None

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        res = self.residual(x) if self.residual is not None else 0
        x = self.relu(self.tcn(self.agc(x)) + res)
        return x


class AGCN(nn.Module):
    """AGCN for multi-label posture deviation classification."""

    def __init__(self, num_classes=3, in_channels=3, dropout=0.5,
                 num_nodes=NUM_NODES):
        super().__init__()

        self.data_bn = nn.BatchNorm1d(in_channels * num_nodes)

        self.layers = nn.ModuleList([
            AGCNBlock(in_channels,  64,  num_nodes, residual=False, dropout=dropout),
            AGCNBlock(64,           64,  num_nodes, dropout=dropout),
            AGCNBlock(64,           64,  num_nodes, dropout=dropout),
            AGCNBlock(64,           64,  num_nodes, dropout=dropout),
            AGCNBlock(64,           128, num_nodes, stride=2, dropout=dropout),
            AGCNBlock(128,          128, num_nodes, dropout=dropout),
            AGCNBlock(128,          128, num_nodes, dropout=dropout),
            AGCNBlock(128,          256, num_nodes, stride=2, dropout=dropout),
            AGCNBlock(256,          256, num_nodes, dropout=dropout),
        ])

        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc   = nn.Linear(256, num_classes)

    def forward(self, x):
        N, C, T, V, M = x.shape

        x = x.permute(0, 4, 3, 1, 2).contiguous()
        x = x.view(N * M, V * C, T)
        x = self.data_bn(x)
        x = x.view(N, M, V, C, T)
        x = x.permute(0, 1, 3, 4, 2).contiguous()
        x = x.view(N * M, C, T, V)

        for layer in self.layers:
            x = layer(x)

        x = self.pool(x).view(N * M, -1)
        x = x.view(N, M, -1).mean(dim=1)
        x = self.fc(x)
        return x


if __name__ == "__main__":
    model = AGCN(num_classes=3)
    dummy = torch.randn(4, 3, 300, 17, 1)
    out   = model(dummy)
    print(f"AGCN output shape : {out.shape}")   # (4, 3)
    print(f"Parameters: {sum(p.numel() for p in model.parameters()):,}")
