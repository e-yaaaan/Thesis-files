"""CTR-GCN: Channel-wise Topology Refinement Graph Convolutional Network."""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from models.stgcn import build_adjacency, COCO_PAIRS, NUM_NODES


class CTRGraphConv(nn.Module):
    """Channel-wise Topology Refinement GCN layer."""

    def __init__(self, in_channels, out_channels, num_nodes=NUM_NODES,
                 num_groups=8):
        super().__init__()
        self.num_nodes  = num_nodes
        self.num_groups = num_groups
        assert out_channels % num_groups == 0, \
            "out_channels must be divisible by num_groups"

        A = build_adjacency(num_nodes)
        self.register_buffer("A_base", A)

        self.delta_A = nn.Parameter(
            torch.zeros(num_groups, num_nodes, num_nodes)
        )
        self.alpha = nn.Parameter(torch.ones(1))

        self.node_emb = nn.Linear(in_channels, num_nodes)

        self.W = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.bn = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        N, C, T, V = x.shape
        G = self.num_groups
        C_out = self.W.out_channels
        C_per_group = C_out // G

        A_refined = self.A_base.unsqueeze(0) + \
                    self.alpha * torch.tanh(self.delta_A)

        feat = self.W(x)
        feat = feat.view(N, G, C_per_group, T, V)

        out = torch.einsum("gcpTV,gVW->gcpTW",
                           feat.permute(1, 0, 2, 3, 4),
                           A_refined
                           ).permute(1, 0, 2, 3, 4)

        out = out.contiguous().view(N, C_out, T, V)
        out = self.bn(out)
        return out


class CTRGCNBlock(nn.Module):

    def __init__(self, in_channels, out_channels, num_nodes=NUM_NODES,
                 stride=1, residual=True, dropout=0.0, num_groups=8):
        super().__init__()

        g = num_groups if out_channels % num_groups == 0 else 4

        self.ctr_gcn = CTRGraphConv(in_channels, out_channels, num_nodes,
                                    num_groups=g)
        self.relu1   = nn.ReLU(inplace=True)

        self.tcn = nn.Sequential(
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels,
                      kernel_size=(9, 1), padding=(4, 0), stride=(stride, 1)),
            nn.BatchNorm2d(out_channels),
            nn.Dropout(dropout, inplace=True),
        )

        if residual:
            if in_channels == out_channels and stride == 1:
                self.residual = nn.Identity()
            else:
                self.residual = nn.Sequential(
                    nn.Conv2d(in_channels, out_channels,
                              kernel_size=1, stride=(stride, 1)),
                    nn.BatchNorm2d(out_channels),
                )
        else:
            self.residual = None

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        res = self.residual(x) if self.residual is not None else 0
        x = self.relu1(self.ctr_gcn(x))
        x = self.relu(self.tcn(x) + res)
        return x


class CTRGCN(nn.Module):
    """CTR-GCN for multi-label posture deviation classification."""

    def __init__(self, num_classes=3, in_channels=3, dropout=0.5,
                 num_nodes=NUM_NODES, num_groups=8):
        super().__init__()

        self.data_bn = nn.BatchNorm1d(in_channels * num_nodes)

        self.layers = nn.ModuleList([
            CTRGCNBlock(in_channels,  64,  num_nodes, residual=False, dropout=dropout, num_groups=4),
            CTRGCNBlock(64,           64,  num_nodes, dropout=dropout, num_groups=4),
            CTRGCNBlock(64,           64,  num_nodes, dropout=dropout, num_groups=4),
            CTRGCNBlock(64,           64,  num_nodes, dropout=dropout, num_groups=4),
            CTRGCNBlock(64,           128, num_nodes, stride=2, dropout=dropout, num_groups=4),
            CTRGCNBlock(128,          128, num_nodes, dropout=dropout, num_groups=num_groups),
            CTRGCNBlock(128,          128, num_nodes, dropout=dropout, num_groups=num_groups),
            CTRGCNBlock(128,          256, num_nodes, stride=2, dropout=dropout, num_groups=num_groups),
            CTRGCNBlock(256,          256, num_nodes, dropout=dropout, num_groups=num_groups),
        ])

        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc   = nn.Linear(256, num_classes)

    def forward(self, x):
        N, C, T, V, M = x.shape

        x = x.permute(0, 4, 3, 1, 2).contiguous()
        x = x.view(N * M, V * C, T)
        x = self.data_bn(x)
        x = x.view(N, M, V, C, T)
        x = x.permute(0, 1, 3, 4, 2).contiguous()
        x = x.view(N * M, C, T, V)

        for layer in self.layers:
            x = layer(x)

        x = self.pool(x).view(N * M, -1)
        x = x.view(N, M, -1).mean(dim=1)
        x = self.fc(x)
        return x


if __name__ == "__main__":
    model = CTRGCN(num_classes=3)
    dummy = torch.randn(4, 3, 300, 17, 1)
    out   = model(dummy)
    print(f"CTR-GCN output shape : {out.shape}")   # (4, 3)
    print(f"Parameters: {sum(p.numel() for p in model.parameters()):,}")
