from models.stgcn   import STGCN
from models.agcn    import AGCN
from models.ctrgcn  import CTRGCN

MODEL_REGISTRY = {
    "stgcn":   STGCN,
    "agcn":    AGCN,
    "ctrgcn":  CTRGCN,
}
