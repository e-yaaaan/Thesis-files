"""ST-GCN: Spatial Temporal Graph Convolutional Network."""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


COCO_PAIRS = [
    (0, 1), (0, 2), (1, 3), (2, 4),            # Head
    (5, 6), (5, 7), (7, 9), (6, 8), (8, 10),   # Arms
    (5, 11), (6, 12), (11, 12),                 # Torso
    (11, 13), (13, 15), (12, 14), (14, 16),     # Legs
]

NUM_NODES = 17


def build_adjacency(num_nodes=NUM_NODES, edges=COCO_PAIRS):
    """
    Returns a normalised adjacency matrix A of shape (num_nodes, num_nodes).
    Self-loops are included. Normalisation: D^{-1/2} A D^{-1/2}.
    """
    A = np.zeros((num_nodes, num_nodes), dtype=np.float32)
    for i, j in edges:
        A[i, j] = 1
        A[j, i] = 1
    A += np.eye(num_nodes, dtype=np.float32)   # self-loop

    # Symmetric normalisation
    D = np.diag(A.sum(axis=1) ** -0.5)
    A_norm = D @ A @ D
    return torch.from_numpy(A_norm)


class GraphConv(nn.Module):
    """Single-partition spatial graph convolution."""

    def __init__(self, in_channels, out_channels, A):
        super().__init__()
        self.register_buffer("A", A)
        self.fc = nn.Conv2d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        x = torch.einsum("nctv,vw->nctw", x, self.A)
        x = self.fc(x)
        return x


class STGCNBlock(nn.Module):

    def __init__(self, in_channels, out_channels, A,
                 stride=1, residual=True, dropout=0.0):
        super().__init__()

        self.gcn = GraphConv(in_channels, out_channels, A)
        self.bn_gcn = nn.BatchNorm2d(out_channels)

        self.tcn = nn.Sequential(
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels,
                      kernel_size=(9, 1), padding=(4, 0), stride=(stride, 1)),
            nn.BatchNorm2d(out_channels),
            nn.Dropout(dropout, inplace=True),
        )

        if residual:
            if in_channels == out_channels and stride == 1:
                self.residual = nn.Identity()
            else:
                self.residual = nn.Sequential(
                    nn.Conv2d(in_channels, out_channels,
                              kernel_size=1, stride=(stride, 1)),
                    nn.BatchNorm2d(out_channels),
                )
        else:
            self.residual = None

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        # x: (N, C, T, V)
        res = self.residual(x) if self.residual is not None else 0
        x = self.relu(self.tcn(self.gcn(x)) + res)
        return x


class STGCN(nn.Module):
    """ST-GCN for multi-label posture deviation classification."""

    def __init__(self, num_classes=3, in_channels=3, dropout=0.5,
                 num_nodes=NUM_NODES, edges=COCO_PAIRS):
        super().__init__()

        A = build_adjacency(num_nodes, edges)

        self.data_bn = nn.BatchNorm1d(in_channels * num_nodes)

        self.layers = nn.ModuleList([
            STGCNBlock(in_channels,  64,  A, residual=False, dropout=dropout),
            STGCNBlock(64,           64,  A, dropout=dropout),
            STGCNBlock(64,           64,  A, dropout=dropout),
            STGCNBlock(64,           64,  A, dropout=dropout),
            STGCNBlock(64,           128, A, stride=2, dropout=dropout),
            STGCNBlock(128,          128, A, dropout=dropout),
            STGCNBlock(128,          128, A, dropout=dropout),
            STGCNBlock(128,          256, A, stride=2, dropout=dropout),
            STGCNBlock(256,          256, A, dropout=dropout),
        ])

        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc   = nn.Linear(256, num_classes)

    def forward(self, x):
        N, C, T, V, M = x.shape

        x = x.permute(0, 4, 3, 1, 2).contiguous()  # (N, M, V, C, T)
        x = x.view(N * M, V * C, T)
        x = self.data_bn(x)
        x = x.view(N, M, V, C, T)
        x = x.permute(0, 1, 3, 4, 2).contiguous()  # (N, M, C, T, V)
        x = x.view(N * M, C, T, V)

        for layer in self.layers:
            x = layer(x)

        x = self.pool(x).view(N * M, -1)
        x = x.view(N, M, -1).mean(dim=1)
        x = self.fc(x)
        return x



if __name__ == "__main__":
    model = STGCN(num_classes=3)
    dummy = torch.randn(4, 3, 300, 17, 1)
    out   = model(dummy)
    print(f"ST-GCN output shape: {out.shape}")   # (4, 3)
    print(f"Parameters: {sum(p.numel() for p in model.parameters()):,}")
