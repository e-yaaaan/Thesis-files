"""
prototype.py — Running Posture Analysis Prototype
Full pipeline: video → HRNet pose extraction → normalization → GCN inference → results

Usage:
    python prototype.py

Then open the Gradio link shown in your terminal.

Requirements:
    pip install gradio
    (mmpose, torch, etc. already installed in pose_env)

Config:
    Set MMPOSE_CONFIG and MMPOSE_CHECKPOINT below if your HRNet files are
    in a different location than this script.
"""

import os
import sys
import json
import tempfile
import numpy as np
import torch
import gradio as gr

# ── Path setup ────────────────────────────────────────────────────────────────
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
GCN_DIR  = os.path.join(ROOT_DIR, "GCN Pipeline")
sys.path.insert(0, GCN_DIR)

# ── MMPose config — edit paths here if needed ─────────────────────────────────
MMPOSE_CONFIG     = os.path.join(ROOT_DIR, "td-hm_hrnet-w48_8xb32-210e_coco-256x192.py")
MMPOSE_CHECKPOINT = os.path.join(ROOT_DIR, "td-hm_hrnet-w48_8xb32-210e_coco-256x192-0e67c616_20220913.pth")
MMPOSE_DEVICE     = "cuda:0"

# ── GCN imports ───────────────────────────────────────────────────────────────
from models        import MODEL_REGISTRY
from data.dataset  import ACTIVE_LABEL_NAMES
from utils.metrics import logits_to_pred

# ── Skeleton imports (reuse existing scripts — no modifications) ───────────────
from normalize_skeleton import load_video_json, normalize_skeleton

MAX_FRAMES    = 300
MODEL_KEY_MAP = {"ST-GCN": "stgcn", "AGCN": "agcn", "CTR-GCN": "ctrgcn"}

# ── MMPose model cache (loaded once, reused across calls) ─────────────────────
_pose_model = None

def get_pose_model():
    global _pose_model
    if _pose_model is None:
        from mmpose.apis import init_model
        print("[Prototype] Loading HRNet pose model (first run only)...")
        _pose_model = init_model(MMPOSE_CONFIG, MMPOSE_CHECKPOINT, device=MMPOSE_DEVICE)
        print("[Prototype] Pose model ready.")
    return _pose_model


# ── Step 1: Pose extraction ───────────────────────────────────────────────────

def extract_pose(video_path):
    """Run HRNet on every frame. Returns (predictions list, total_frames)."""
    import cv2
    import mmcv
    from mmpose.apis       import inference_topdown
    from mmpose.structures import merge_data_samples

    pose_model   = get_pose_model()
    cap          = cv2.VideoCapture(video_path)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    predictions  = []
    frame_idx    = 0

    while cap.isOpened():
        ret, frame_bgr = cap.read()
        if not ret:
            break

        frame_rgb    = mmcv.bgr2rgb(frame_bgr)
        batch_result = inference_topdown(pose_model, frame_rgb)
        result       = merge_data_samples(batch_result)

        if (result.pred_instances is not None
                and len(result.pred_instances.keypoints) > 0):
            frame_pred = {
                "frame_id":        frame_idx,
                "keypoints":       result.pred_instances.keypoints.tolist(),
                "keypoint_scores": result.pred_instances.keypoint_scores.tolist(),
            }
        else:
            frame_pred = {
                "frame_id": frame_idx, "keypoints": [], "keypoint_scores": [],
            }

        predictions.append(frame_pred)
        frame_idx += 1

    cap.release()
    return predictions, total_frames


# ── Step 2: Normalize skeleton ────────────────────────────────────────────────

def preprocess(predictions):
    """Hip-center + torso-scale, then reshape to (1, 3, 300, 17, 1) tensor."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(predictions, f)
        tmp = f.name
    try:
        keypoints, scores = load_video_json(tmp)
    finally:
        os.unlink(tmp)

    skeleton = normalize_skeleton(keypoints, scores)          # (T, 17, 3)
    skeleton = skeleton.transpose(2, 0, 1)[:, :, :, np.newaxis]  # (3, T, 17, 1)

    T = skeleton.shape[1]
    if T >= MAX_FRAMES:
        skeleton = skeleton[:, :MAX_FRAMES, :, :]
    else:
        pad = np.zeros((3, MAX_FRAMES - T, 17, 1), dtype=np.float32)
        skeleton = np.concatenate([skeleton, pad], axis=1)

    return torch.from_numpy(skeleton).unsqueeze(0)            # (1, 3, 300, 17, 1)


# ── Step 3: Load GCN checkpoint ───────────────────────────────────────────────

def load_model(model_display, aug_version, device):
    model_key   = MODEL_KEY_MAP[model_display]
    num_classes = len(ACTIVE_LABEL_NAMES)
    ckpt_path   = os.path.join(GCN_DIR, f"results_{aug_version}",
                               "checkpoints", model_key, "best_model.pt")

    if not os.path.isfile(ckpt_path):
        raise FileNotFoundError(
            f"Checkpoint not found:\n  {ckpt_path}\n\n"
            "Run train.py for this model/version first."
        )

    ModelClass = MODEL_REGISTRY[model_key]
    model      = ModelClass(num_classes=num_classes, dropout=0.0).to(device)
    ckpt       = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    return model


# ── Full pipeline ─────────────────────────────────────────────────────────────

BORDERLINE_LOW = 0.40

# ── Colors matching labeler.py ─────────────────────────────────────────────────
_BG       = '#141414'
_BG_CARD  = '#2a2a2a'
_BORDER   = '#2d2d2d'
_ACCENT   = '#3b82f6'
_GREEN    = '#22c55e'
_RED      = '#ef4444'
_AMBER    = '#f59e0b'
_TEXT_PRI = '#f1f5f9'
_TEXT_SEC = '#94a3b8'
_TEXT_DIM = '#475569'


def classify_prob(prob, threshold):
    if prob >= threshold:
        return "detected"
    if prob >= BORDERLINE_LOW:
        return "possible"
    return "not detected"


def run_pipeline(video_path, model_display, aug_version, threshold):
    if video_path is None:
        return "<p style='color:#475569;font-size:14px;padding:8px'>Upload a video first.</p>"

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    try:
        predictions, total_frames = extract_pose(video_path)
        tensor = preprocess(predictions)
        model  = load_model(model_display, aug_version, device)

        with torch.no_grad():
            logits = model(tensor.to(device))

        _, y_prob = logits_to_pred(logits.cpu().numpy())
        prob_row  = y_prob[0]

        confirmed = []
        possible  = []
        rows_html = []

        for name, prob in zip(ACTIVE_LABEL_NAMES, prob_row):
            zone = classify_prob(float(prob), threshold)
            pct  = float(prob) * 100

            if zone == "detected":
                confirmed.append((name, prob))
                dot   = f"<span style='color:{_RED}'>●</span>"
                badge = (f"<span style='background:#3d1515;color:{_RED};"
                         f"padding:2px 10px;border-radius:4px;font-size:12px;"
                         f"font-weight:700;letter-spacing:.5px'>DETECTED</span>")
            elif zone == "possible":
                possible.append((name, prob))
                dot   = f"<span style='color:{_AMBER}'>◐</span>"
                badge = (f"<span style='background:#2d2010;color:{_AMBER};"
                         f"padding:2px 10px;border-radius:4px;font-size:12px;"
                         f"font-weight:600'>possible</span>")
            else:
                dot   = f"<span style='color:{_GREEN}'>○</span>"
                badge = (f"<span style='background:#0f2d1a;color:{_GREEN};"
                         f"padding:2px 10px;border-radius:4px;font-size:12px'>"
                         f"not detected</span>")

            rows_html.append(
                f"<div style='display:flex;align-items:center;padding:9px 0;"
                f"border-bottom:1px solid {_BORDER}'>"
                f"  <span style='width:22px;font-size:15px'>{dot}</span>"
                f"  <span style='flex:1;color:{_TEXT_PRI}'>{name}</span>"
                f"  <span style='color:{_TEXT_DIM};margin-right:14px;font-size:13px'>{pct:.1f}%</span>"
                f"  {badge}"
                f"</div>"
            )

        if confirmed:
            detail = ", ".join(n for n, _ in confirmed)
            if possible:
                detail += f"<br><span style='color:{_AMBER}'>Possible: " + ", ".join(n for n, _ in possible) + "</span>"
            verdict_html = (
                f"<div style='background:#2d1515;border:1px solid {_RED};"
                f"border-radius:6px;padding:14px 16px;margin-top:14px'>"
                f"  <p style='font-weight:700;color:{_RED};margin:0 0 4px 0;font-size:15px'>BAD POSTURE</p>"
                f"  <p style='color:{_TEXT_SEC};margin:0;font-size:13px'>{detail}</p>"
                f"</div>"
            )
        elif possible:
            detail = ", ".join(n for n, _ in possible)
            verdict_html = (
                f"<div style='background:#2d2010;border:1px solid {_AMBER};"
                f"border-radius:6px;padding:14px 16px;margin-top:14px'>"
                f"  <p style='font-weight:700;color:{_AMBER};margin:0 0 4px 0;font-size:15px'>POSSIBLE DEVIATION</p>"
                f"  <p style='color:{_TEXT_SEC};margin:0;font-size:13px'>{detail}</p>"
                f"</div>"
            )
        else:
            verdict_html = (
                f"<div style='background:#0f2d1a;border:1px solid {_GREEN};"
                f"border-radius:6px;padding:14px 16px;margin-top:14px'>"
                f"  <p style='font-weight:700;color:{_GREEN};margin:0 0 4px 0;font-size:15px'>GOOD POSTURE</p>"
                f"  <p style='color:{_TEXT_SEC};margin:0;font-size:13px'>No significant gait deviations detected.</p>"
                f"</div>"
            )

        meta = (
            f"<p style='color:{_TEXT_DIM};font-size:12px;margin:0 0 12px 0'>"
            f"{model_display} &nbsp;·&nbsp; "
            f"{'Augmented' if aug_version == 'aug' else 'No augmentation'} &nbsp;·&nbsp; "
            f"Threshold {threshold:.0%} &nbsp;·&nbsp; "
            f"{total_frames} frames"
            f"</p>"
        )

        breakdown_html = (
            f"<p style='font-weight:600;color:{_TEXT_SEC};font-size:12px;"
            f"letter-spacing:.5px;margin:0 0 6px 0'>DEVIATION BREAKDOWN</p>"
            + "".join(rows_html)
        )

        return (
            f"<div style='font-family:\"Segoe UI\",system-ui,sans-serif;"
            f"padding:4px;color:{_TEXT_PRI}'>"
            f"{meta}{breakdown_html}{verdict_html}</div>"
        )

    except FileNotFoundError as e:
        return f"<p style='color:{_RED}'><strong>Error:</strong> {e}</p>"
    except Exception as e:
        import traceback
        tb = traceback.format_exc().replace("\n", "<br>")
        return f"<p style='color:{_RED}'><strong>Error:</strong> {e}<br><pre>{tb}</pre></p>"


# ── Gradio UI ─────────────────────────────────────────────────────────────────

CSS = f"""
footer {{ display: none !important; }}

body, .gradio-container {{
    background-color: {_BG} !important;
}}
.block, .form, .panel, .gap, .wrap {{
    background-color: #1e1e1e !important;
    border-color: {_BORDER} !important;
}}
.label-wrap span, label span, .svelte-1b6s6s {{
    color: {_TEXT_SEC} !important;
}}
input, select, textarea, .wrap-inner, .input {{
    background-color: {_BG_CARD} !important;
    color: {_TEXT_PRI} !important;
    border-color: {_BORDER} !important;
}}
.prose, .prose p, p, span {{
    color: {_TEXT_PRI};
}}
.gr-button-primary, button.primary {{
    background-color: {_ACCENT} !important;
    color: white !important;
    border: none !important;
    border-radius: 6px !important;
}}
.gr-button-primary:hover, button.primary:hover {{
    background-color: #2563eb !important;
}}
.svelte-1ipelgc, .dropdown, .choices {{
    background-color: {_BG_CARD} !important;
    border-color: {_BORDER} !important;
    color: {_TEXT_PRI} !important;
}}
input[type=range] {{
    accent-color: {_ACCENT};
}}
video {{
    background-color: #0a0a0a !important;
}}
::-webkit-scrollbar {{ width: 5px; background: {_BG}; }}
::-webkit-scrollbar-thumb {{ background: {_BORDER}; border-radius: 3px; }}
"""


def build_ui():
    with gr.Blocks(title="Gait Analysis", theme=gr.themes.Base(), css=CSS) as demo:

        gr.Markdown(
            f"<p style='color:{_TEXT_SEC};font-size:12px;letter-spacing:.5px;"
            f"margin:0 0 2px 0'>RUNNING POSTURE</p>"
            f"<p style='color:{_TEXT_PRI};font-size:20px;font-weight:700;margin:0'>Posture Analysis</p>"
        )

        with gr.Row(equal_height=False):
            with gr.Column(scale=1, min_width=260):
                video_input = gr.Video(label="Video", sources=["upload"])
                model_choice = gr.Dropdown(
                    choices=["ST-GCN", "AGCN", "CTR-GCN"],
                    value="CTR-GCN",
                    label="Model",
                )
                aug_choice = gr.Dropdown(
                    choices=[("Augmented", "aug"), ("No Augmentation", "no_aug")],
                    value="aug",
                    label="Training",
                )
                threshold_slider = gr.Slider(
                    minimum=0.50,
                    maximum=0.90,
                    value=0.65,
                    step=0.05,
                    label="Detection Threshold",
                )
                run_btn = gr.Button("Analyze", variant="primary")

            with gr.Column(scale=1, min_width=320):
                output_html = gr.HTML(
                    value=f"<p style='color:{_TEXT_DIM};font-size:14px;padding:8px'>"
                          f"Results will appear here.</p>"
                )

        run_btn.click(
            fn=run_pipeline,
            inputs=[video_input, model_choice, aug_choice, threshold_slider],
            outputs=output_html,
        )

    return demo


if __name__ == "__main__":
    demo = build_ui()
    demo.launch(share=False)
