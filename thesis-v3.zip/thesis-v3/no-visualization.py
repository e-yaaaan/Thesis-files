import os
import json
import cv2
import mmcv
from mmpose.apis import inference_topdown, init_model
from mmpose.structures import merge_data_samples

# ── CONFIG ──────────────────────────────────────────────────────────────────
CONFIG     = 'td-hm_hrnet-w48_8xb32-210e_coco-256x192.py'
CHECKPOINT = 'td-hm_hrnet-w48_8xb32-210e_coco-256x192-0e67c616_20220913.pth'
DEVICE     = 'cuda:0'
VIDEO_DIR  = 'videos_norm/'
PRED_DIR   = 'predictions/'
KPT_THR    = 0.3

# How often (frames) to save partial progress to disk.
# If the script is cancelled, at most SAVE_EVERY frames are lost.
SAVE_EVERY = 100
# ────────────────────────────────────────────────────────────────────────────

os.makedirs(PRED_DIR, exist_ok=True)

# Build model — no visualizer needed
model = init_model(CONFIG, CHECKPOINT, device=DEVICE)

video_files = sorted(f for f in os.listdir(VIDEO_DIR)
                     if f.lower().endswith('.mov'))

print(f'Found {len(video_files)} videos to process')

# Count how many are already done
done   = sum(1 for f in video_files
             if os.path.isfile(os.path.join(PRED_DIR,
                                            os.path.splitext(f)[0] + '.json')))
print(f'Already completed: {done} / {len(video_files)}')

total_start = cv2.getTickCount()

for video_name in video_files:
    video_path   = os.path.join(VIDEO_DIR, video_name)
    base_name    = os.path.splitext(video_name)[0]
    out_json     = os.path.join(PRED_DIR, base_name + '.json')
    partial_json = os.path.join(PRED_DIR, base_name + '.partial.json')

    # ── Already fully processed — skip ───────────────────────────────────────
    if os.path.isfile(out_json):
        print(f'\n[SKIP] Already done: {video_name}')
        continue

    # ── Resume from partial progress if available ─────────────────────────────
    if os.path.isfile(partial_json):
        with open(partial_json, 'r') as f:
            all_predictions = json.load(f)
        resume_frame = len(all_predictions)
        print(f'\n[RESUME] {video_name} — continuing from frame {resume_frame}')
    else:
        all_predictions = []
        resume_frame    = 0
        print(f'\n[START]  {video_name}')

    cap          = cv2.VideoCapture(video_path)
    fps          = cap.get(cv2.CAP_PROP_FPS)
    width        = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height       = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    print(f'  FPS: {fps} | Resolution: {width}x{height} | '
          f'Frames: {total_frames}')

    # Seek to the first unprocessed frame
    if resume_frame > 0:
        cap.set(cv2.CAP_PROP_POS_FRAMES, resume_frame)
        print(f'  Resuming at frame {resume_frame}/{total_frames} '
              f'({resume_frame/total_frames*100:.1f}% already done)')

    frame_idx   = resume_frame
    video_start = cv2.getTickCount()

    while cap.isOpened():
        ret, frame_bgr = cap.read()
        if not ret:
            break

        frame_rgb = mmcv.bgr2rgb(frame_bgr)

        # Inference only — no visualization
        batch_results = inference_topdown(model, frame_rgb)
        results       = merge_data_samples(batch_results)

        if results.pred_instances is not None:
            keypoints = results.pred_instances.keypoints
            scores    = results.pred_instances.keypoint_scores
            frame_pred = {
                'frame_id':        frame_idx,
                'keypoints':       keypoints.tolist(),
                'keypoint_scores': scores.tolist(),
            }
        else:
            frame_pred = {
                'frame_id':        frame_idx,
                'keypoints':       [],
                'keypoint_scores': [],
            }
        all_predictions.append(frame_pred)
        frame_idx += 1

        # ── Periodic progress print + partial save ────────────────────────────
        if frame_idx % SAVE_EVERY == 0:
            elapsed      = (cv2.getTickCount() - video_start) / cv2.getTickFrequency()
            frames_done  = frame_idx - resume_frame          # frames processed this session
            frames_left  = total_frames - frame_idx
            eta          = (elapsed / max(frames_done, 1)) * frames_left

            print(f'  Frame {frame_idx}/{total_frames} | '
                  f'Elapsed: {elapsed/60:.1f}min | '
                  f'ETA: {eta/60:.1f}min')

            # Save partial progress (compact JSON — fast write)
            with open(partial_json, 'w') as f:
                json.dump(all_predictions, f)

    cap.release()

    # ── Video complete — write final JSON, remove partial ─────────────────────
    with open(out_json, 'w') as f:
        json.dump(all_predictions, f, indent=2)

    if os.path.isfile(partial_json):
        os.remove(partial_json)

    video_elapsed = (cv2.getTickCount() - video_start) / cv2.getTickFrequency()
    print(f'  Done in {video_elapsed/60:.1f} min → {out_json}')

total_elapsed = (cv2.getTickCount() - total_start) / cv2.getTickFrequency()
print(f'\nAll videos processed in {total_elapsed/60:.1f} minutes')
