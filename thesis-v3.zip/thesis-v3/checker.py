import os

LABEL_NAMES = [
    'Poor Elbow Flexion',
    'No Forward Lean',
    'Knee Lift (>70 degrees)',
    'Heel Strike',
    'Poor Arm Swing',
    'Excessive Back Kick'
]

counts = [0] * len(LABEL_NAMES)
total = 0

for fname in os.listdir("labels"):
    if not fname.endswith(".txt"):
        continue

    with open(os.path.join("labels", fname)) as f:
        values = [int(line.strip()) for line in f if line.strip()]

    if len(values) != len(LABEL_NAMES):
        print(
            f"Skipping {fname} "
            f"(found {len(values)} labels, expected {len(LABEL_NAMES)})"
        )
        continue

    for i in range(len(LABEL_NAMES)):
        counts[i] += values[i]

    total += 1

print(f"\nTotal videos: {total}\n")

for name, count in zip(LABEL_NAMES, counts):
    percentage = (100 * count / total) if total > 0 else 0
    print(f"{name}: {count}/{total} ({percentage:.1f}%)")